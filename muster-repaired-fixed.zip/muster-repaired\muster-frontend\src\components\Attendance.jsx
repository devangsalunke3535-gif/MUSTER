import { useEffect, useState, useCallback } from 'react';
import { getWorkers, markAttendanceBulk, getAttendance, describeError, todayISO, SHIFT_LABEL } from '../api';
import { Calendar as CalendarIcon, CheckCircle2, XCircle, AlertCircle, Save, MinusCircle, Filter } from 'lucide-react';
import { useToast } from './Toast';

const STATUS_MAP_OUT = { present: 'PRESENT', absent: 'ABSENT', half: 'HALF_DAY' };
const STATUS_MAP_IN = { PRESENT: 'present', ABSENT: 'absent', HALF_DAY: 'half' };

export default function Attendance() {
  const [workers, setWorkers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const today = todayISO();
  const [date, setDate] = useState(today);
  const [attendanceState, setAttendanceState] = useState({});
  const [saving, setSaving] = useState(false);
  const [shiftFilter, setShiftFilter] = useState('all');
  const { addToast } = useToast();

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [{ data: workersData }, attendanceData] = await Promise.all([getWorkers('active'), getAttendance(date)]);
      setWorkers(workersData);
      const existingState = {};
      attendanceData.forEach(att => {
        if (STATUS_MAP_IN[att.status]) existingState[att.employee_id] = STATUS_MAP_IN[att.status];
      });
      setAttendanceState(existingState);
    } catch (err) {
      setError(describeError(err, 'Failed to load attendance'));
    }
    setLoading(false);
  }, [date]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleStatusChange = (workerId, status) => {
    setAttendanceState(prev => ({ ...prev, [workerId]: status }));
  };

  const filteredWorkers = shiftFilter === 'all' ? workers : workers.filter(w => w.shift_type === shiftFilter);

  const handleBulkMark = (status) => {
    const newState = { ...attendanceState };
    filteredWorkers.forEach(w => { newState[w.id] = status; });
    setAttendanceState(newState);
    addToast('All ' + (shiftFilter === 'all' ? '' : SHIFT_LABEL[shiftFilter] + ' shift ') + 'workers marked as ' + status, 'info');
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const entries = workers
        .filter(w => attendanceState[w.id])
        .map(w => ({ employee_id: w.id, status: STATUS_MAP_OUT[attendanceState[w.id]] }));
      if (entries.length === 0) { setSaving(false); return; }
      await markAttendanceBulk(date, entries);
      addToast(`Attendance saved for ${entries.length} worker(s) on ${date}`, 'success');
      await loadData();
    } catch (err) {
      addToast(describeError(err, 'Failed to save attendance'), 'error');
    }
    setSaving(false);
  };

  const markedCount = Object.keys(attendanceState).filter(id => workers.some(w => w.id === id)).length;
  const totalCount = workers.length;
  const presentCount = workers.filter(w => attendanceState[w.id] === 'present').length;
  const absentCount = workers.filter(w => attendanceState[w.id] === 'absent').length;
  const halfCount = workers.filter(w => attendanceState[w.id] === 'half').length;
  const progressPercent = totalCount > 0 ? Math.round((markedCount / totalCount) * 100) : 0;

  const btnClass = (workerId, value, activeClasses) => {
    const isActive = attendanceState[workerId] === value;
    const base = "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 cursor-pointer select-none";
    if (isActive) return base + " bg-white shadow-md ring-1 ring-black/5 " + activeClasses;
    return base + " text-slate-400 hover:text-slate-600 hover:bg-white/50";
  };
  const iconCls = (workerId, value, activeColor) => attendanceState[workerId] === value ? "transition-all duration-200 " + activeColor : "transition-all duration-200 opacity-30";

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Attendance</h1>
          <p className="text-slate-400 text-sm mt-1">Mark daily attendance for all active workers</p>
        </div>
        <div className="flex items-center gap-3 bg-white px-4 py-2.5 rounded-xl border border-slate-200 shadow-soft">
          <CalendarIcon size={16} className="text-primary-500" />
          <input type="date" value={date} max={today} onChange={e => setDate(e.target.value)}
            className="bg-transparent text-sm font-medium text-slate-700 outline-none cursor-pointer" />
        </div>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-soft">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-semibold text-slate-700">Marking Progress</span>
          <span className="text-sm font-bold text-primary-600">{progressPercent}%</span>
        </div>
        <div className="w-full bg-slate-100 rounded-full h-2">
          <div className="bg-gradient-to-r from-primary-500 to-primary-600 h-full rounded-full transition-all duration-500" style={{ width: progressPercent + '%' }} />
        </div>
        <div className="flex flex-wrap gap-3 mt-3">
          <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-600"><CheckCircle2 size={13} /> {presentCount} Present</span>
          <span className="flex items-center gap-1.5 text-xs font-medium text-rose-600"><XCircle size={13} /> {absentCount} Absent</span>
          <span className="flex items-center gap-1.5 text-xs font-medium text-amber-600"><AlertCircle size={13} /> {halfCount} Half Day</span>
          <span className="flex items-center gap-1.5 text-xs font-medium text-slate-400"><MinusCircle size={13} /> {totalCount - markedCount} Not Marked</span>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-100 shadow-soft">
          <Filter size={14} className="text-slate-400 ml-2 mr-1" />
          {['all', 'DAY', 'NIGHT'].map(s => (
            <button key={s} onClick={() => setShiftFilter(s)}
              className={shiftFilter === s
                ? "px-3 py-1.5 rounded-lg text-xs font-semibold bg-primary-600 text-white shadow-sm transition-all"
                : "px-3 py-1.5 rounded-lg text-xs font-medium text-slate-500 hover:bg-slate-50 transition-all"
              }>{s === 'all' ? 'All Shifts' : SHIFT_LABEL[s] + ' Shift'}</button>
          ))}
        </div>

        <div className="flex gap-2">
          <button onClick={() => handleBulkMark('present')} className="px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors">
            ✓ Mark All Present
          </button>
          <button onClick={() => handleBulkMark('absent')} className="px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg hover:bg-rose-100 transition-colors">
            ✗ Mark All Absent
          </button>
        </div>
      </div>

      {loading ? (
        <div className="bg-white p-16 rounded-2xl shadow-soft text-center">
          <div className="h-8 w-8 border-2 border-slate-200 border-t-primary-500 rounded-full animate-spin mx-auto mb-3" />
          <span className="text-sm text-slate-400">Loading roster...</span>
        </div>
      ) : filteredWorkers.length === 0 ? (
        <div className="bg-white p-16 rounded-2xl shadow-soft text-center text-sm text-slate-400">No workers in this shift.</div>
      ) : (
        <div className="bg-white rounded-2xl shadow-soft overflow-hidden border border-slate-100">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 text-slate-400 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-100">
                  <th className="px-6 py-3.5">Worker</th>
                  <th className="px-6 py-3.5">Shift</th>
                  <th className="px-6 py-3.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredWorkers.map(w => {
                  const status = attendanceState[w.id];
                  return (
                    <tr key={w.id} className="hover:bg-primary-50/20 transition-colors">
                      <td className="px-6 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center text-primary-700 font-bold text-xs">
                            {(w.full_name || 'U').trim().split(/\s+/).map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-800 text-sm">{w.full_name}</div>
                            <div className="text-[11px] text-slate-400">{w.emp_id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-3">
                        <span className={w.shift_type === 'NIGHT'
                          ? "text-xs font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100"
                          : w.shift_type === 'DAY'
                            ? "text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-100"
                            : "text-xs font-semibold text-slate-500 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200"}>
                          {SHIFT_LABEL[w.shift_type] || 'Unassigned'}
                        </span>
                      </td>
                      <td className="px-6 py-3">
                        <div className="flex items-center gap-2">
                          {!status && <span className="text-[10px] text-slate-300 italic mr-1">—</span>}
                          <div className="flex bg-slate-100/80 p-0.5 rounded-lg border border-slate-200/60">
                            <button type="button" onClick={() => handleStatusChange(w.id, 'present')} className={btnClass(w.id, 'present', 'text-emerald-600')}>
                              <CheckCircle2 size={14} className={iconCls(w.id, 'present', 'text-emerald-500')} /> Present
                            </button>
                            <button type="button" onClick={() => handleStatusChange(w.id, 'absent')} className={btnClass(w.id, 'absent', 'text-rose-600')}>
                              <XCircle size={14} className={iconCls(w.id, 'absent', 'text-rose-500')} /> Absent
                            </button>
                            <button type="button" onClick={() => handleStatusChange(w.id, 'half')} className={btnClass(w.id, 'half', 'text-amber-600')}>
                              <AlertCircle size={14} className={iconCls(w.id, 'half', 'text-amber-500')} /> Half Day
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="sticky bottom-0 bg-white/95 backdrop-blur-sm border-t border-slate-100 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={"w-2 h-2 rounded-full " + (markedCount > 0 ? "bg-primary-400 animate-pulse" : "bg-slate-300")} />
              <p className="text-sm text-slate-500">
                <span className="font-bold text-slate-700">{markedCount}</span> of <span className="font-bold text-slate-700">{totalCount}</span> marked
              </p>
            </div>
            <button type="button" onClick={handleSave} disabled={saving || markedCount === 0}
              className={saving || markedCount === 0
                ? "flex items-center gap-2 bg-slate-200 text-slate-400 px-6 py-2.5 rounded-xl font-semibold cursor-not-allowed text-sm"
                : "flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-6 py-2.5 rounded-xl font-semibold transition-all shadow-lg shadow-primary-600/20 active:scale-95 text-sm"}>
              <Save size={16} /> {saving ? 'Saving...' : 'Save Attendance'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
