import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './components/Toast';

import Layout from './components/Layout';
import ProtectedRoute, { RequirePermission } from './components/ProtectedRoute';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import WorkerHome from './components/WorkerHome';
import WorkerMySalary from './components/WorkerMySalary';
import WorkerMyAttendance from './components/WorkerMyAttendance';
import WorkerMyLeave from './components/WorkerMyLeave';
import WorkerMyAdvances from './components/WorkerMyAdvances';
import Workers from './components/Workers';
import Attendance from './components/Attendance';
import Reports from './components/Reports';
import Settings from './components/Settings';
import PayrollAdmin from './components/PayrollAdmin';
import SalaryConfig from './components/SalaryConfig';
import LeaveAdmin from './components/LeaveAdmin';
import AdvancesAdmin from './components/AdvancesAdmin';
import Approvals from './components/Approvals';
import ErrorBoundary from './components/ErrorBoundary';

const queryClient = new QueryClient();

function IndexRedirect() {
  const { isWorker } = useAuth();
  return <Navigate to={isWorker ? '/home' : '/dashboard'} replace />;
}

const guard = (perm, el) => <RequirePermission perm={perm}>{el}</RequirePermission>;
const self = (el) => <RequirePermission workerOnly>{el}</RequirePermission>;

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ToastProvider>
          <ErrorBoundary>
            <BrowserRouter>
              <Routes>
                <Route path="/login" element={<Login />} />

                <Route element={<ProtectedRoute />}>
                  <Route element={<Layout />}>
                    <Route path="/" element={<IndexRedirect />} />

                    {/* Admin / manager */}
                    <Route path="/dashboard" element={guard('employee:view', <Dashboard />)} />
                    <Route path="/directory" element={guard('employee:view', <Workers />)} />
                    <Route path="/workers" element={<Navigate to="/directory" replace />} />
                    <Route path="/attendance" element={guard('attendance:manage', <Attendance />)} />
                    <Route path="/leave" element={guard('leave:approve', <LeaveAdmin />)} />
                    <Route path="/approvals" element={guard(['leave:approve', 'loan:manage'], <Approvals />)} />
                    <Route path="/payroll" element={guard('payroll:view', <PayrollAdmin />)} />
                    <Route path="/salary" element={guard('salary:manage', <SalaryConfig />)} />
                    <Route path="/salary-config" element={<Navigate to="/salary" replace />} />
                    <Route path="/advances" element={guard('loan:manage', <AdvancesAdmin />)} />
                    <Route path="/loans" element={<Navigate to="/advances" replace />} />
                    <Route path="/reports" element={guard('employee:view', <Reports />)} />
                    <Route path="/settings" element={<Settings />} />

                    {/* Self-service (any user with an employee profile) */}
                    <Route path="/home" element={self(<WorkerHome />)} />
                    <Route path="/my-attendance" element={self(<WorkerMyAttendance />)} />
                    <Route path="/my-leave" element={self(<WorkerMyLeave />)} />
                    <Route path="/my-salary" element={self(<WorkerMySalary />)} />
                    <Route path="/my-advances" element={self(<WorkerMyAdvances />)} />
                  </Route>
                </Route>

                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BrowserRouter>
          </ErrorBoundary>
        </ToastProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
