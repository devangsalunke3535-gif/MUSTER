import { useState, useEffect } from 'react';
import api, { approveLoan, rejectLoan, describeError, inr } from '../api';
import { CheckCircle, XCircle, Search, Filter, IndianRupee, AlertCircle, Lock } from 'lucide-react';
import { useToast } from './Toast';

export default function AdvancesAdmin() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const { addToast } = useToast();

  const [error, setError] = useState(null);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const res = await api.get('/loans');
      const data = res.data?.data || [];
      const mapped = data.map(l => ({
        id: l.id,
        worker_name: `${l.employee?.first_name || ''} ${l.employee?.last_name || ''}`.trim() || 'Worker',
        amount: l.amount,
        requested_on: l.disbursed_date || l.created_at,
        status: l.status,
        reason: l.reason || 'Salary Advance',
        can_decide: l.can_decide,
      }));
      setRequests(mapped);
      setError(null);
    } catch (err) {
      setError(describeError(err, 'Failed to load advance requests'));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { fetchRequests(); }, []);

  const handleAction = async (id, action) => {
    try {
      if (action === 'ACTIVE') { // ACTIVE means approved in this context
        await approveLoan(id);
        addToast('Loan approved successfully', 'success');
      } else if (action === 'REJECTED') {
        await rejectLoan(id);
        addToast('Loan rejected successfully', 'success');
      }
      await fetchRequests();
    } catch (e) {
      addToast(describeError(e, 'Failed to update loan status'), 'error');
    }
  };

  const getStatusBadge = (status) => {
    const maps = {
      ACTIVE: 'bg-indigo-100 text-indigo-700 border-indigo-200',
      SETTLED: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      PENDING: 'bg-amber-100 text-amber-700 border-amber-200',
      REJECTED: 'bg-rose-100 text-rose-700 border-rose-200',
    };
    return `px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${maps[status] || maps.PENDING}`;
  };

  return (
    <div className="p-8 font-sans max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 tracking-tight">Salary Advances</h1>
          <p className="text-slate-500 mt-1">Review and manage worker loan requests.</p>
        </div>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm mb-6">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between gap-4 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input type="text" placeholder="Search by worker name..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20" />
        </div>
        <button className="p-2 border border-slate-200 rounded-xl text-slate-500 hover:bg-slate-50 transition-colors">
          <Filter size={18} />
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-sm font-semibold text-slate-600">
              <th className="p-5">Worker</th>
              <th className="p-5">Amount</th>
              <th className="p-5">Details</th>
              <th className="p-5">Status</th>
              <th className="p-5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading ? (
              [1, 2, 3].map(i => (
                <tr key={i}>
                  <td colSpan="5" className="p-5">
                    <div className="h-12 bg-slate-100 rounded-xl animate-pulse"></div>
                  </td>
                </tr>
              ))
            ) : requests.map(req => (
              <tr key={req.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="p-5 font-semibold text-slate-800">{req.worker_name}</td>
                <td className="p-5">
                  <p className="text-lg font-bold text-slate-800 flex items-center"><IndianRupee size={16}/>{req.amount.toLocaleString()}</p>
                </td>
                <td className="p-5">
                  <p className="text-sm font-medium text-slate-700">{req.reason}</p>
                  <p className="text-xs text-slate-500">{new Date(req.requested_on).toLocaleDateString()}</p>
                </td>
                <td className="p-5">
                  <span className={getStatusBadge(req.status)}>{req.status}</span>
                </td>
                <td className="p-5 flex justify-end gap-2">
                  {req.status !== 'PENDING' ? (
                    <span className="text-xs font-semibold text-slate-400 py-2">Processed</span>
                  ) : req.can_decide ? (
                    <>
                      <button onClick={() => handleAction(req.id, 'ACTIVE')} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors" title="Approve">
                        <CheckCircle size={20} />
                      </button>
                      <button onClick={() => handleAction(req.id, 'REJECTED')} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors" title="Reject">
                        <XCircle size={20} />
                      </button>
                    </>
                  ) : (
                    <span className="flex items-center justify-end gap-1 text-xs text-slate-400 py-2"><Lock size={12} /> Not your step</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
