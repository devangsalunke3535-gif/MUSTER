import request from 'supertest';
import app from '../server';
import { prisma } from '../config/db';
import * as argon2 from 'argon2';

describe('Phase 4 Integration Tests (Leave & Holidays)', () => {
  let csrfToken: string;
  let csrfCookie: string;
  let authCookieOrgA: string;
  let authCookieOrgB: string;
  let authCookieMgrA: string; // separate approver: self-approval is intentionally blocked
  
  let orgAId: string;
  let orgBId: string;
  let empAId: string;
  
  let leaveTypeAId: string;
  let leaveRequestAId: string;
  let holidayAId: string;

  beforeAll(async () => {
    // Teardown
    await prisma.leaveRequest.deleteMany();
    await prisma.leaveBalance.deleteMany();
    await prisma.leaveType.deleteMany();
    await prisma.holiday.deleteMany();
    
    await prisma.approvalAction.deleteMany();
    await prisma.approvalStep.deleteMany();
    await prisma.approvalRequest.deleteMany();

    await prisma.employment.deleteMany();
    await prisma.employee.deleteMany();
    await prisma.userRole.deleteMany();
    await prisma.rolePermission.deleteMany();
    await prisma.permission.deleteMany();
    await prisma.role.deleteMany();
    await prisma.shift.deleteMany();
    await prisma.user.deleteMany();
    await prisma.organization.deleteMany();

    // Create Organizations
    const orgA = await prisma.organization.create({ data: { name: 'Org A', code: 'ORGA', legal_name: 'Org A Ltd' } });
    const orgB = await prisma.organization.create({ data: { name: 'Org B', code: 'ORGB', legal_name: 'Org B Ltd' } });
    orgAId = orgA.id;
    orgBId = orgB.id;

    // Create Permissions
    const p1 = await prisma.permission.create({ data: { module: 'leave', action: 'manage', code: 'leave:manage' } });
    const p2 = await prisma.permission.create({ data: { module: 'leave_type', action: 'create', code: 'leave_type:create' } });
    const p3 = await prisma.permission.create({ data: { module: 'leave', action: 'create', code: 'leave:create' } });
    const p4 = await prisma.permission.create({ data: { module: 'leave', action: 'approve', code: 'leave:approve' } });
    const p5 = await prisma.permission.create({ data: { module: 'leave', action: 'cancel', code: 'leave:cancel' } });
    const p6 = await prisma.permission.create({ data: { module: 'holiday', action: 'create', code: 'holiday:create' } });
    
    const roleA = await prisma.role.create({ data: { organization_id: orgA.id, name: 'HR', code: 'HR' } });
    const roleB = await prisma.role.create({ data: { organization_id: orgB.id, name: 'HR', code: 'HR' } });
    
    await prisma.rolePermission.createMany({
      data: [p1, p2, p3, p4, p5, p6].map(p => ({ role_id: roleA.id, permission_id: p.id }))
    });
    await prisma.rolePermission.createMany({
      data: [p1, p2, p3, p4, p5, p6].map(p => ({ role_id: roleB.id, permission_id: p.id }))
    });

    // Create Admins
    const hash = await argon2.hash('testpass123');
    const adminA = await prisma.user.create({ data: { organization_id: orgA.id, email: 'adminA@test.com', password_hash: hash, is_active: true } });
    const adminB = await prisma.user.create({ data: { organization_id: orgB.id, email: 'adminB@test.com', password_hash: hash, is_active: true } });
    
    await prisma.userRole.create({ data: { user_id: adminA.id, role_id: roleA.id, scope_organization_id: orgA.id } });
    await prisma.userRole.create({ data: { user_id: adminB.id, role_id: roleB.id, scope_organization_id: orgB.id } });

    // Create Employee A linked to Admin A
    const emp = await prisma.employee.create({
      data: {
        organization_id: orgA.id,
        user_id: adminA.id,
        emp_id: 'E01',
        first_name: 'Admin',
        last_name: 'A'
      }
    });
    empAId = emp.id;
    
    // Approver: a DIFFERENT employee in the same org (self-approval is blocked by design).
    const mgrUser = await prisma.user.create({ data: { organization_id: orgA.id, email: 'mgrA@test.com', password_hash: hash, is_active: true } });
    await prisma.userRole.create({ data: { user_id: mgrUser.id, role_id: roleA.id, scope_organization_id: orgA.id } });
    const mgrEmp = await prisma.employee.create({ data: { organization_id: orgA.id, user_id: mgrUser.id, emp_id: 'M01', first_name: 'Manager', last_name: 'A' } });
    await prisma.employment.create({ data: { employee_id: mgrEmp.id, joining_date: new Date(), status: 'ACTIVE' } });

    await prisma.employment.create({
      data: {
        employee_id: emp.id,
        joining_date: new Date(),
        status: 'ACTIVE',
        manager_id: mgrEmp.id
      }
    });
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('1. Setup Auth & CSRF', async () => {
    const res = await request(app).get('/api/v1/auth/csrf');
    csrfToken = res.body.csrfToken;
    csrfCookie = res.headers['set-cookie'][0];

    const loginA = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'adminA@test.com', password: 'testpass123' });
    const cookiesA = Array.isArray(loginA.headers['set-cookie']) ? loginA.headers['set-cookie'] : [loginA.headers['set-cookie']];
    authCookieOrgA = cookiesA.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];

    const loginB = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'adminB@test.com', password: 'testpass123' });
    const cookiesB = Array.isArray(loginB.headers['set-cookie']) ? loginB.headers['set-cookie'] : [loginB.headers['set-cookie']];
    authCookieOrgB = cookiesB.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];

    const loginM = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'mgrA@test.com', password: 'testpass123' });
    const cookiesM = Array.isArray(loginM.headers['set-cookie']) ? loginM.headers['set-cookie'] : [loginM.headers['set-cookie']];
    authCookieMgrA = cookiesM.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];
  });

  it('2. Create Leave Type (Org A)', async () => {
    const res = await request(app)
      .post('/api/v1/leaves/types')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        name: 'Annual Leave',
        code: 'AL',
        is_paid: true,
        annual_quota: 20
      });
    
    expect(res.status).toBe(200);
    expect(res.body.data.id).toBeDefined();
    leaveTypeAId = res.body.data.id;
  });

  it('3. Allocate Leave Balance', async () => {
    const year = new Date().getFullYear();
    const res = await request(app)
      .post('/api/v1/leaves/balances/allocate')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        employee_id: empAId,
        leave_type_id: leaveTypeAId,
        year,
        allocated_balance: 5 // Granting 5 days
      });
    
    expect(res.status).toBe(200);
    expect(res.body.data.remaining_balance).toBe(5);
  });

  it('4. Create Holiday (Org A)', async () => {
    const res = await request(app)
      .post('/api/v1/holidays')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        name: 'National Holiday',
        date: new Date(new Date().getFullYear(), 0, 1).toISOString() // Jan 1st
      });
    
    expect(res.status).toBe(200);
    expect(res.body.data.id).toBeDefined();
    holidayAId = res.body.data.id;
  });

  it('5. Leave Request Creation (Deducts properly across dates)', async () => {
    const now = new Date();
    const res = await request(app)
      .post('/api/v1/leaves/requests')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        leave_type_id: leaveTypeAId,
        start_date: new Date(now.getFullYear(), now.getMonth(), 10).toISOString(),
        end_date: new Date(now.getFullYear(), now.getMonth(), 12).toISOString(), // 3 days
        reason: 'Vacation'
      });
    
    expect(res.status).toBe(200);
    expect(res.body.data.duration_days).toBe(3);
    leaveRequestAId = res.body.data.id;
  });

  it('6. Leave Overdraft Prevention', async () => {
    const now = new Date();
    const res = await request(app)
      .post('/api/v1/leaves/requests')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        leave_type_id: leaveTypeAId,
        start_date: new Date(now.getFullYear(), now.getMonth(), 20).toISOString(),
        end_date: new Date(now.getFullYear(), now.getMonth(), 25).toISOString(), // 6 days
        reason: 'Too long'
      });
    
    expect(res.status).toBe(400); // 6 > 5 remaining
    expect(res.body.error).toBe('Insufficient leave balance');
  });

  it('7. Leave Approval (Deducts Balance Transactionally)', async () => {
    const res = await request(app)
      .post(`/api/v1/leaves/requests/${leaveRequestAId}/approve`)
      .set('Cookie', [`${csrfCookie}`, `${authCookieMgrA}`])
      .set('CSRF-Token', csrfToken);
    
    expect(res.status).toBe(200);

    // Verify Balance was deducted
    const year = new Date().getFullYear();
    const balance = await prisma.leaveBalance.findUnique({
      where: { employee_id_leave_type_id_leave_year: { employee_id: empAId, leave_type_id: leaveTypeAId, leave_year: year } }
    });
    
    expect(balance?.remaining_balance).toBe(2); // 5 - 3
    expect(balance?.used_balance).toBe(3);
  });

  it('8. Leave Cancellation (Restores Balance)', async () => {
    const res = await request(app)
      .post(`/api/v1/leaves/requests/${leaveRequestAId}/cancel`)
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken);
    
    expect(res.status).toBe(200);

    // Verify Balance was restored
    const year = new Date().getFullYear();
    const balance = await prisma.leaveBalance.findUnique({
      where: { employee_id_leave_type_id_leave_year: { employee_id: empAId, leave_type_id: leaveTypeAId, leave_year: year } }
    });
    
    expect(balance?.remaining_balance).toBe(5);
    expect(balance?.used_balance).toBe(0);
  });

  it('9. Concurrent Leave Approval Prevention (Race Condition)', async () => {
    // Create two separate requests that sum to > 5 days (e.g. 3 days each)
    const now = new Date();
    
    // Req 1 (3 days)
    const req1 = await request(app).post('/api/v1/leaves/requests')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({ leave_type_id: leaveTypeAId, start_date: new Date(now.getFullYear(), 5, 1).toISOString(), end_date: new Date(now.getFullYear(), 5, 3).toISOString(), reason: 'R1' });
      
    // Req 2 (3 days)
    const req2 = await request(app).post('/api/v1/leaves/requests')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({ leave_type_id: leaveTypeAId, start_date: new Date(now.getFullYear(), 6, 1).toISOString(), end_date: new Date(now.getFullYear(), 6, 3).toISOString(), reason: 'R2' });

    // Approve concurrently
    const [res1, res2] = await Promise.all([
      request(app).post(`/api/v1/leaves/requests/${req1.body.data.id}/approve`).set('Cookie', [`${csrfCookie}`, `${authCookieMgrA}`]).set('CSRF-Token', csrfToken),
      request(app).post(`/api/v1/leaves/requests/${req2.body.data.id}/approve`).set('Cookie', [`${csrfCookie}`, `${authCookieMgrA}`]).set('CSRF-Token', csrfToken)
    ]);

    // Prove that one succeeded and one failed
    const successCount = [res1.status, res2.status].filter(s => s === 200).length;
    const failCount = [res1.status, res2.status].filter(s => s === 400).length;
    
    expect(successCount).toBe(1);
    expect(failCount).toBe(1);

    // Verify final balance is 2 (5 - 3 = 2, and the second 3-day request failed)
    const balance = await prisma.leaveBalance.findUnique({
      where: { employee_id_leave_type_id_leave_year: { employee_id: empAId, leave_type_id: leaveTypeAId, leave_year: now.getFullYear() } }
    });
    
    expect(balance?.remaining_balance).toBe(2);
    expect(balance?.used_balance).toBe(3);
  });
});
