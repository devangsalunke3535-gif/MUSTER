import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { auditLog } from '../middleware/audit.middleware';
import { openApproval, recordDecision, Decision } from '../services/approval.service';
import { sendError, badRequest, conflict, parseDateOnly, parsePositiveNumber, optionalString, todayIST, isUuid, round2 } from '../utils/http';
import { getSelfEmployee, isSuperAdmin, getScopedBranchIds, branchScopeWhere, getEmployeeInScope, getNumericSetting } from '../utils/access';
import { ACTIVE_EMPLOYMENT_STATUSES } from '../services/employee.service';

const router = Router();

/** Default cap on a single self-service advance request; override with OrganizationSetting payroll.max_advance_amount. */
export const DEFAULT_MAX_ADVANCE = 10000;

const employeeSelect = { select: { id: true, emp_id: true, first_name: true, last_name: true } };

function withRepaid(loan: any) {
  const repaid = round2((loan.repayments || []).reduce((s: number, r: any) => s + r.amount, 0));
  const last = (loan.repayments || []).slice().sort((a: any, b: any) => +new Date(b.repayment_date) - +new Date(a.repayment_date))[0];
  const { repayments, ...rest } = loan;
  return { ...rest, repaid_amount: repaid, repayment_count: (loan.repayments || []).length, last_repayment: last ? { amount: last.amount, date: last.repayment_date } : null };
}

// GET /loans/settings — the limits the UI should display (values come from the server, not hardcoded).
router.get('/settings', async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    res.json({
      data: {
        max_advance_amount: await getNumericSetting(orgId, 'payroll', 'max_advance_amount', DEFAULT_MAX_ADVANCE),
        max_loan_deduction_pct: await getNumericSetting(orgId, 'payroll', 'max_loan_deduction_pct', 10),
      }
    });
  } catch (e) {
    sendError(res, e, 'Loan settings');
  }
});

// Admin-issued advance (already approved, disbursed immediately).
router.post('/', requirePermission('loan:manage'), auditLog('CREATE', 'Loan'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const { employee_id } = req.body || {};
    if (!isUuid(employee_id)) return res.status(404).json({ error: 'Employee not found' });
    await getEmployeeInScope(req.authContext!.userId, orgId, employee_id);
    const amount = round2(parsePositiveNumber(req.body?.amount, 'amount', { max: 10_000_000 }));
    const disbursed = req.body?.disbursed_date ? parseDateOnly(req.body.disbursed_date, 'disbursed_date') : todayIST();
    const reason = optionalString(req.body?.reason, 'reason', 2000) || null;

    const loan = await prisma.loan.create({
      data: { organization_id: orgId, employee_id, amount, remaining_balance: amount, disbursed_date: disbursed, status: 'ACTIVE', reason }
    });
    res.json({ data: loan });
  } catch (error) {
    sendError(res, error, 'Create loan');
  }
});

router.get('/my-advances', async (req: Request, res: Response) => {
  try {
    const employee = await getSelfEmployee(req.authContext!.userId, req.authContext!.organizationId);
    if (!employee) return res.json({ data: [] });
    const loans = await prisma.loan.findMany({
      where: { employee_id: employee.id, organization_id: req.authContext!.organizationId },
      include: { repayments: true },
      orderBy: { created_at: 'desc' }
    });
    res.json({ data: loans.map(withRepaid) });
  } catch (error) {
    sendError(res, error, 'My advances');
  }
});

// GET /loans?status=PENDING
router.get('/', requirePermission('loan:manage'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const branchIds = await getScopedBranchIds(userId, orgId);
    const where: any = { organization_id: orgId, employee: branchScopeWhere(branchIds) };
    if (req.query.status) where.status = String(req.query.status).toUpperCase();

    const [loans, actor, superAdmin] = await Promise.all([
      prisma.loan.findMany({ where, include: { employee: employeeSelect, repayments: true }, orderBy: { created_at: 'desc' } }),
      getSelfEmployee(userId, orgId),
      isSuperAdmin(userId, orgId),
    ]);

    const approvals = await prisma.approvalRequest.findMany({
      where: { organization_id: orgId, entity_type: 'Loan', entity_id: { in: loans.map((l: any) => l.id) } },
      include: { steps: true }
    });
    const byLoan = new Map(approvals.map((a: any) => [a.entity_id, a]));

    res.json({
      data: loans.map((l: any) => {
        const steps = (byLoan.get(l.id) as any)?.steps || [];
        const assigned = steps.some((s: any) => s.status === 'PENDING' && s.approver_user_id === actor?.id);
        const can_decide = l.status === 'PENDING' && !!actor && l.employee_id !== actor.id && (superAdmin || steps.length === 0 || assigned);
        return { ...withRepaid(l), can_decide };
      })
    });
  } catch (error) {
    sendError(res, error, 'List loans');
  }
});

// Worker self-service advance request.
router.post('/request', requirePermission('loan:request'), auditLog('CREATE', 'Loan'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employee = await prisma.employee.findFirst({
      where: { user_id: req.authContext!.userId, organization_id: orgId }, include: { employment: true }
    });
    if (!employee) return res.status(404).json({ error: 'Employee not found' });
    if (!employee.employment || !ACTIVE_EMPLOYMENT_STATUSES.includes(employee.employment.status)) {
      throw badRequest('Your employment is not active');
    }

    const max = await getNumericSetting(orgId, 'payroll', 'max_advance_amount', DEFAULT_MAX_ADVANCE);
    const amount = round2(parsePositiveNumber(req.body?.amount, 'amount', { max }));
    const reason = optionalString(req.body?.reason, 'reason', 2000) || null;

    const result = await prisma.$transaction(async (tx: any) => {
      const pending = await tx.loan.findFirst({ where: { employee_id: employee.id, status: 'PENDING' } });
      if (pending) throw conflict('You already have an advance request awaiting approval');

      const loan = await tx.loan.create({
        data: {
          organization_id: orgId, employee_id: employee.id, amount, remaining_balance: amount,
          status: 'PENDING', reason,
          disbursed_date: todayIST() // overwritten with the actual date on approval
        }
      });
      await openApproval(tx, { orgId, requesterEmployeeId: employee.id, entityType: 'Loan', entityId: loan.id });
      return loan;
    });
    res.json({ data: result });
  } catch (error) {
    sendError(res, error, 'Request advance');
  }
});

/**
 * PENDING → ACTIVE (approved) or PENDING → REJECTED. The transition is claimed
 * with a conditional UPDATE in the same transaction as the approval records,
 * so repeated/concurrent decisions fail cleanly and nothing is half-written.
 */
async function decideLoan(req: Request, res: Response, decision: Decision) {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const loanId = String(req.params.id);
    if (!isUuid(loanId)) return res.status(404).json({ error: 'Loan not found' });

    const loan = await prisma.loan.findFirst({ where: { id: loanId, organization_id: orgId } });
    if (!loan) return res.status(404).json({ error: 'Loan not found' });
    await getEmployeeInScope(userId, orgId, loan.employee_id); // branch scope
    if (loan.status !== 'PENDING') return res.status(400).json({ error: 'Loan is not pending' });

    const actor = await getSelfEmployee(userId, orgId);
    const superAdmin = await isSuperAdmin(userId, orgId);
    const comments = optionalString(req.body?.comments, 'comments', 2000) || null;

    await prisma.$transaction(async (tx: any) => {
      const claimed = await tx.loan.updateMany({
        where: { id: loan.id, status: 'PENDING' },
        data: decision === 'APPROVED' ? { status: 'ACTIVE', disbursed_date: todayIST() } : { status: 'REJECTED' }
      });
      if (claimed.count !== 1) throw conflict('Loan is not pending');

      await recordDecision(tx, {
        orgId, approvalRequestId: null, entityType: 'Loan', entityId: loan.id,
        requesterEmployeeId: loan.employee_id, actorEmployeeId: actor?.id ?? null, actorIsSuperAdmin: superAdmin,
        decision, comments
      });
    });

    res.json({ message: decision === 'APPROVED' ? 'Loan approved' : 'Loan rejected' });
  } catch (error) {
    sendError(res, error, 'Decide loan');
  }
}

router.post('/:id/approve', requirePermission('loan:manage'), auditLog('UPDATE', 'Loan'), (req: Request, res: Response) => decideLoan(req, res, 'APPROVED'));
router.post('/:id/reject', requirePermission('loan:manage'), auditLog('UPDATE', 'Loan'), (req: Request, res: Response) => decideLoan(req, res, 'REJECTED'));

export default router;
