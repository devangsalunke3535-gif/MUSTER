import { Prisma } from '@prisma/client';
import { prisma } from '../config/db';
import { round2, toDateKey, addDaysUTC } from '../utils/http';
import { getNumericSetting } from '../utils/access';
import { ACTIVE_EMPLOYMENT_STATUSES } from './employee.service';

/** An employee excluded from, or adjusted in, a payroll run — surfaced to the admin, never silent. */
export interface PayrollCalculationWarning {
  employee_id: string;
  emp_id: string;
  name: string;
  reason: string;
}

export interface PayrollRunTotals {
  employees: number;
  gross: number;
  deductions: number;
  net: number;
  loan_recovery: number;
}

export const DEFAULT_LOAN_DEDUCTION_PCT = 10;
const DEFAULT_DAY_HOURS = 8;

/**
 * Payroll calculation.
 *
 * IDEMPOTENCY: recalculating the same run first reverses everything the
 * previous calculation of *this run* did (loan repayments are credited back to
 * the loans, then repayments/items/components are deleted), and then computes
 * from scratch — all in ONE transaction. Same inputs therefore always produce
 * the same final state; a loan can never be decremented twice by the same run.
 *
 * CONCURRENCY:
 *  - the route claims the run with a conditional status UPDATE (DRAFT/REVIEW →
 *    PROCESSING), so two calculate calls on the same run cannot both proceed;
 *  - inside the transaction the run row and every loan row of the organization
 *    are locked FOR UPDATE, so two *different* runs that touch the same loans
 *    are serialised and cannot both read the same remaining balance.
 *
 * FINALIZED runs are rejected by the route before this is ever called, and
 * this function re-checks the status under the row lock as well.
 */
export class PayrollService {
  static async calculatePayrollRun(runId: string, orgId: string, periodStart: Date, periodEnd: Date): Promise<{ warnings: PayrollCalculationWarning[]; totals: PayrollRunTotals }> {
    const warnings: PayrollCalculationWarning[] = [];
    const loanPct = await getNumericSetting(orgId, 'payroll', 'max_loan_deduction_pct', DEFAULT_LOAN_DEDUCTION_PCT);

    const totals = await prisma.$transaction(async (tx: any) => {
      const locked: any[] = await tx.$queryRaw`SELECT status FROM "PayrollRun" WHERE id = ${runId}::uuid AND organization_id = ${orgId}::uuid FOR UPDATE`;
      if (locked.length === 0) throw new Error('Run not found');
      if (['FINALIZED', 'DISBURSED', 'LOCKED'].includes(locked[0].status)) throw new Error('Run is finalized and cannot be recalculated');
      await tx.$queryRaw`SELECT id FROM "Loan" WHERE organization_id = ${orgId}::uuid ORDER BY id FOR UPDATE`;

      // 1. Reverse this run's previous calculation.
      const previousItems = await tx.payrollItem.findMany({ where: { payroll_run_id: runId }, select: { id: true } });
      const itemIds = previousItems.map((i: any) => i.id);
      if (itemIds.length > 0) {
        const repayments = await tx.loanRepayment.findMany({ where: { payroll_item_id: { in: itemIds } } });
        for (const rep of repayments) {
          await tx.loan.update({
            where: { id: rep.loan_id },
            data: { remaining_balance: { increment: rep.amount }, status: 'ACTIVE' }
          });
        }
        await tx.loanRepayment.deleteMany({ where: { payroll_item_id: { in: itemIds } } });
        await tx.payrollItemComponent.deleteMany({ where: { payroll_item_id: { in: itemIds } } });
        await tx.payrollItem.deleteMany({ where: { payroll_run_id: runId } });
      }
      // Normalise float drift left by increments/decrements.
      await tx.$executeRaw`UPDATE "Loan" SET remaining_balance = ROUND(remaining_balance::numeric, 2)::float8 WHERE organization_id = ${orgId}::uuid`;

      // 2. Eligible employees: currently active, or with attendance in the period
      //    (someone deactivated mid-month is still owed for the days they worked).
      const employees = await tx.employee.findMany({
        where: {
          organization_id: orgId,
          employment: { isNot: null },
          OR: [
            { employment: { status: { in: ACTIVE_EMPLOYMENT_STATUSES } } },
            { attendances: { some: { date: { gte: periodStart, lte: periodEnd } } } }
          ]
        },
        include: {
          employment: true,
          defaultShift: true,
          assignmentHistory: { where: { effective_to: null }, take: 1 }
        },
        orderBy: { emp_id: 'asc' }
      });

      // Holidays are loaded once for the whole run.
      const holidays = await tx.holiday.findMany({
        where: { organization_id: orgId, is_active: true, date: { gte: periodStart, lte: periodEnd } }
      });

      const t: PayrollRunTotals = { employees: 0, gross: 0, deductions: 0, net: 0, loan_recovery: 0 };
      for (const emp of employees) {
        const r = await this.calculateEmployeePayroll(tx, runId, emp, periodStart, periodEnd, holidays, loanPct, warnings);
        if (r) {
          t.employees += 1; t.gross += r.gross; t.deductions += r.deductions; t.net += r.net; t.loan_recovery += r.loan;
        }
      }

      await tx.payrollRun.update({ where: { id: runId }, data: { status: 'REVIEW' } });
      return { employees: t.employees, gross: round2(t.gross), deductions: round2(t.deductions), net: round2(t.net), loan_recovery: round2(t.loan_recovery) };
    }, { timeout: 60000 });

    return { warnings, totals };
  }

  static async calculateEmployeePayroll(
    tx: Prisma.TransactionClient,
    runId: string,
    emp: any,
    periodStart: Date,
    periodEnd: Date,
    holidays: any[],
    loanPct: number,
    warnings: PayrollCalculationWarning[]
  ): Promise<{ gross: number; deductions: number; net: number; loan: number } | null> {
    const name = `${emp.first_name} ${emp.last_name}`.trim();
    const warn = (reason: string) => warnings.push({ employee_id: emp.id, emp_id: emp.emp_id, name, reason });

    // A. Salary structure
    const structure = await tx.salaryStructure.findFirst({
      where: { employee_id: emp.id, status: 'ACTIVE' },
      orderBy: { effective_from: 'desc' },
      include: { items: { include: { component: true } } }
    });
    if (!structure) {
      warn('No active salary structure found. Employee excluded from this payroll run.');
      return null;
    }
    const inactiveComponents = structure.items.filter((i: any) => !i.component.is_active);
    if (inactiveComponents.length) {
      warn(`Inactive salary components ignored: ${inactiveComponents.map((i: any) => i.component.name).join(', ')}`);
    }
    const items = structure.items.filter((i: any) => i.component.is_active);

    const dayHours = emp.defaultShift?.full_day_mins ? emp.defaultShift.full_day_mins / 60 : DEFAULT_DAY_HOURS;
    const joining: Date | null = emp.employment?.joining_date ? new Date(emp.employment.joining_date) : null;
    const branchId: string | null = emp.assignmentHistory?.[0]?.branch_id ?? null;

    // B. Payable units from attendance
    const attendances = await tx.attendance.findMany({
      where: { employee_id: emp.id, date: { gte: periodStart, lte: periodEnd } }
    });
    let payableDays = 0;
    let payableHours = 0;
    const attendanceDates = new Set<string>();
    for (const att of attendances) {
      attendanceDates.add(toDateKey(att.date));
      if (att.status === 'PRESENT') { payableDays += 1; payableHours += att.total_worked_mins / 60; }
      else if (att.status === 'HALF_DAY') { payableDays += 0.5; payableHours += att.total_worked_mins / 60; }
      else if (att.status === 'LEAVE') { payableDays += 1; payableHours += dayHours; }
    }

    // Holidays applicable to this employee (org-wide or their branch, on/after joining).
    const holidayDates = new Set<string>();
    for (const h of holidays) {
      if (h.branch_id && h.branch_id !== branchId) continue;
      if (joining && h.date < joining) continue;
      holidayDates.add(toDateKey(h.date));
    }

    // C. Approved PAID leave. Attendance on a date takes precedence (they
    //    worked, or were explicitly marked); holidays are never double-counted.
    const leaves = await tx.leaveRequest.findMany({
      where: {
        employee_id: emp.id, status: 'APPROVED',
        start_date: { lte: periodEnd }, end_date: { gte: periodStart },
        leaveType: { is_paid: true }
      }
    });
    const paidLeaveDates = new Set<string>();
    for (const l of leaves) {
      let d = l.start_date > periodStart ? new Date(l.start_date) : new Date(periodStart);
      const end = l.end_date < periodEnd ? new Date(l.end_date) : new Date(periodEnd);
      while (d <= end) {
        const k = toDateKey(d);
        if (!attendanceDates.has(k) && !holidayDates.has(k)) paidLeaveDates.add(k);
        d = addDaysUTC(d, 1);
      }
    }
    payableDays += paidLeaveDates.size;
    payableHours += paidLeaveDates.size * dayHours;

    // D. Paid holidays for DAILY/HOURLY workers on days with no attendance.
    //    MONTHLY salary already covers holidays — adding them would double-pay.
    if (structure.wage_basis === 'DAILY' || structure.wage_basis === 'HOURLY') {
      for (const k of holidayDates) {
        if (!attendanceDates.has(k)) { payableDays += 1; payableHours += dayHours; }
      }
    }
    payableHours = round2(payableHours);

    // E. Earnings
    const periodDays = Math.round((periodEnd.getTime() - periodStart.getTime()) / 86400000) + 1;
    const components: { salary_component_id: string; amount: number }[] = [];
    let gross = 0;
    for (const item of items) {
      if (item.component.type !== 'EARNING') continue;
      let amt = 0;
      if (structure.wage_basis === 'DAILY') amt = item.amount * payableDays;
      else if (structure.wage_basis === 'HOURLY') amt = item.amount * payableHours;
      else amt = (item.amount / periodDays) * payableDays; // MONTHLY, prorated on actual calendar days
      amt = round2(amt);
      gross += amt;
      components.push({ salary_component_id: item.component.id, amount: amt });
    }
    if (items.some((i: any) => i.component.type === 'OVERTIME')) {
      for (const item of items.filter((i: any) => i.component.type === 'OVERTIME')) {
        components.push({ salary_component_id: item.component.id, amount: 0 });
      }
      warn('Overtime components are configured but overtime hours are not tracked yet; overtime paid as ₹0.');
    }
    gross = round2(gross);

    // F. Fixed deductions (DEDUCTION / STATUTORY). They may never push net pay
    //    below zero; any shortfall is capped and reported.
    let deductions = 0;
    for (const item of items) {
      if (item.component.type !== 'DEDUCTION' && item.component.type !== 'STATUTORY') continue;
      const available = round2(gross - deductions);
      const amt = round2(Math.min(item.amount, Math.max(0, available)));
      if (amt < item.amount) warn(`${item.component.name} reduced from ₹${item.amount} to ₹${amt} because earnings were insufficient.`);
      deductions += amt;
      components.push({ salary_component_id: item.component.id, amount: amt });
    }
    deductions = round2(deductions);

    // G. Loan recovery. The cap applies to the TOTAL across all of the
    //    employee's loans (not per loan): min(loanPct% of gross, what's left
    //    after fixed deductions). Oldest loan is recovered first.
    const loans = await tx.loan.findMany({
      where: { employee_id: emp.id, status: 'ACTIVE', remaining_balance: { gt: 0 }, disbursed_date: { lte: periodEnd } },
      orderBy: [{ disbursed_date: 'asc' }, { created_at: 'asc' }]
    });
    let loanCapLeft = round2(Math.min(gross * (loanPct / 100), Math.max(0, gross - deductions)));
    const repayments: { loan_id: string; amount: number; remaining: number }[] = [];
    for (const loan of loans) {
      if (loanCapLeft <= 0) break;
      const amt = round2(Math.min(loan.remaining_balance, loanCapLeft));
      if (amt <= 0) continue;
      repayments.push({ loan_id: loan.id, amount: amt, remaining: loan.remaining_balance });
      loanCapLeft = round2(loanCapLeft - amt);
    }
    const loanTotal = round2(repayments.reduce((s, r) => s + r.amount, 0));
    const totalDeductions = round2(deductions + loanTotal);
    const net = round2(gross - totalDeductions); // guaranteed ≥ 0 by the caps above

    // H. Persist the snapshot
    const pItem = await tx.payrollItem.create({
      data: {
        payroll_run_id: runId,
        employee_id: emp.id,
        payable_days: payableDays,
        payable_hours: payableHours,
        gross_earnings: gross,
        total_deductions: totalDeductions,
        net_pay: net,
        components: { create: components }
      }
    });
    for (const rep of repayments) {
      await tx.loanRepayment.create({
        data: { loan_id: rep.loan_id, payroll_item_id: pItem.id, amount: rep.amount, repayment_date: periodEnd }
      });
      const newRemaining = round2(rep.remaining - rep.amount);
      await tx.loan.update({
        where: { id: rep.loan_id },
        data: { remaining_balance: newRemaining, status: newRemaining <= 0 ? 'CLEARED' : 'ACTIVE' }
      });
    }

    return { gross, deductions: totalDeductions, net, loan: loanTotal };
  }
}
