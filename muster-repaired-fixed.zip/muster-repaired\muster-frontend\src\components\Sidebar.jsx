import { LayoutDashboard, Users, Calendar, Settings, LogOut, ChevronLeft, ChevronRight, FileBarChart, Wallet, ClipboardCheck } from 'lucide-react';
import { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const { user, logout, hasPermission, isWorker, displayName, roleLabel } = useAuth();

  const navItems = [];
  if (!isWorker) {
    navItems.push({ id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard });
    if (hasPermission('employee:view')) navItems.push({ id: 'directory', label: 'Directory', icon: Users });
    if (hasPermission('attendance:manage')) navItems.push({ id: 'attendance', label: 'Attendance', icon: Calendar });
    if (hasPermission('leave:approve') || hasPermission('loan:manage')) navItems.push({ id: 'approvals', label: 'Approvals', icon: ClipboardCheck });
    if (hasPermission('payroll:view')) navItems.push({ id: 'payroll', label: 'Payroll', icon: Wallet });
    if (hasPermission('salary:manage')) navItems.push({ id: 'salary', label: 'Salary Config', icon: Settings });
    if (hasPermission('employee:view')) navItems.push({ id: 'reports', label: 'Reports', icon: FileBarChart });
    if (user?.is_super_admin) navItems.push({ id: 'settings', label: 'Settings', icon: Settings });
  } else {
    navItems.push({ id: 'home', label: 'Home', icon: LayoutDashboard });
    navItems.push({ id: 'my-attendance', label: 'My Attendance', icon: Calendar });
    navItems.push({ id: 'my-leave', label: 'My Leave', icon: FileBarChart });
    navItems.push({ id: 'my-advances', label: 'My Advances', icon: Wallet });
    navItems.push({ id: 'my-salary', label: 'My Salary', icon: FileBarChart });
  }

  const sidebarWidth = collapsed ? 'w-[72px]' : 'w-[260px]';

  return (
    <aside className={sidebarWidth + " bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white transition-all duration-300 flex flex-col relative"}>
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-primary-600/10 to-transparent pointer-events-none" />

      <div className="h-16 flex items-center px-4 border-b border-white/5 relative z-10">
        {!collapsed ? (
          <Link to={isWorker ? '/home' : '/dashboard'} className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
            <div className="w-9 h-9 bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl flex items-center justify-center font-bold text-lg shadow-lg shadow-primary-500/30">M</div>
            <div>
              <span className="font-bold text-lg tracking-tight text-white">Muster</span>
              <span className="text-[10px] ml-1.5 bg-primary-500/20 text-primary-300 px-1.5 py-0.5 rounded-full font-semibold">PRO</span>
            </div>
          </Link>
        ) : (
          <Link to={isWorker ? '/home' : '/dashboard'} className="block hover:opacity-80 transition-opacity">
            <div className="w-9 h-9 mx-auto bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl flex items-center justify-center font-bold shadow-lg shadow-primary-500/30">M</div>
          </Link>
        )}
      </div>

      {!collapsed && (
        <div className="px-5 pt-6 pb-2">
          <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-slate-500">Main Menu</p>
        </div>
      )}

      <div className={"flex-1 px-3 space-y-1" + (collapsed ? " pt-6" : "")}>
        {navItems.map(item => {
          const Icon = item.icon;
          const base = "w-full flex items-center px-3 py-2.5 rounded-xl transition-all duration-200 group relative";
          return (
            <NavLink key={item.id} to={`/${item.id}`}
              className={({ isActive }) => (isActive ? base + " bg-primary-600/15 text-white" : base + " text-slate-400 hover:bg-white/5 hover:text-white")}>
              {({ isActive }) => (
                <>
                  {isActive && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 bg-primary-400 rounded-r-full" />}
                  <Icon size={18} className={(isActive ? "text-primary-400" : "text-slate-500 group-hover:text-slate-300") + (collapsed ? " mx-auto" : " mr-3")} />
                  {!collapsed && <span className="font-medium text-sm">{item.label}</span>}
                </>
              )}
            </NavLink>
          );
        })}
      </div>

      <div className="p-3 border-t border-white/5 space-y-2">
        {!collapsed && user && (
          <div className="px-3 py-2 mb-1">
            <p className="text-sm font-semibold text-white truncate">{displayName}</p>
            <p className="text-[11px] text-slate-500 truncate">{roleLabel}</p>
          </div>
        )}
        <button onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center px-3 py-2 rounded-xl text-slate-500 hover:bg-white/5 hover:text-white transition-colors">
          {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </button>
        <button onClick={logout} className="w-full flex items-center px-3 py-2 rounded-xl text-slate-500 hover:bg-red-500/10 hover:text-red-400 transition-colors group">
          <LogOut size={18} className={collapsed ? "mx-auto" : "mr-3"} />
          {!collapsed && <span className="font-medium text-sm">Logout</span>}
        </button>
      </div>
    </aside>
  );
}
