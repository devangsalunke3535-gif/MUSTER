import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/db';
import { isSessionValid } from './auth.middleware';

/**
 * Permission gate. Also re-validates the account on every protected call: a
 * deactivated user, or a token whose organization no longer matches the user,
 * is rejected even if the JWT itself is still within its expiry window.
 */
export function requirePermission(permissionCode: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId, organizationId } = req.authContext || {};
      if (!userId || !organizationId) {
        return res.status(401).json({ error: 'Unauthorized: Context missing' });
      }

      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (!isSessionValid(user, req.authContext)) {
        return res.status(401).json({ error: 'Unauthorized: Session expired or account inactive' });
      }
      if (user!.is_super_admin) return next();

      const userRoles = await prisma.userRole.findMany({
        where: { user_id: userId, scope_organization_id: organizationId },
        include: { role: { include: { rolePermissions: { include: { permission: true } } } } }
      });

      const hasPerm = userRoles.some((ur: any) =>
        ur.role.organization_id === organizationId &&
        ur.role.rolePermissions.some((rp: any) => rp.permission.code === permissionCode)
      );

      if (!hasPerm) {
        return res.status(403).json({ error: `Forbidden: Requires ${permissionCode}` });
      }
      next();
    } catch (error) {
      next(error);
    }
  };
}

/** For self-service routes that need no specific permission but must still reject inactive accounts. */
export function requireActiveUser() {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = req.authContext?.userId;
      const user = userId ? await prisma.user.findUnique({ where: { id: userId } }) : null;
      if (!isSessionValid(user, req.authContext)) {
        return res.status(401).json({ error: 'Unauthorized: Session expired or account inactive' });
      }
      next();
    } catch (error) {
      next(error);
    }
  };
}
