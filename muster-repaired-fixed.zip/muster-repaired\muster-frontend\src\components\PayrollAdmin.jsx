import { useState, useEffect } from 'react';
import api, { describeError, inr } from '../api';
import { PlayCircle, CheckCircle, Lock, AlertCircle, Plus, X, Calendar } from 'lucide-react';

export default function PayrollAdmin() {
  const [runs, setRuns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchRuns();
  }, []);

  const fetchRuns = async () => {
    try {
      setLoading(true);
      const res = await api.get('/payroll/runs');
      const data = res.data?.data || [];
      // Totals are computed server-side from PayrollItem rows (never summed
      // client-side from data that may not have been fetched).
      setRuns(data.map(r => ({
        id: r.id,
        period: r.period?.name || 'Period',
        status: r.status,
        employees: r.totals?.employees || 0,
        gross: r.totals?.gross || 0,
        deds: r.totals?.deductions || 0,
        net: r.totals?.net || 0,
      })));
      setError(null);
    } catch (e) {
      setError(describeError(e, 'Failed to fetch payroll runs.'));
    } finally {
      setLoading(false);
    }
  };

  const [actionError, setActionError] = useState(null);
  const [showNewRun, setShowNewRun] = useState(false);
  const [periodForm, setPeriodForm] = useState({ start_date: '', end_date: '', name: '' });
  const [creating, setCreating] = useState(false);

  const calculateRun = async (id) => {
    setActionError(null);
    try {
      const res = await api.post(`/payroll/runs/${id}/calculate`);
      if (res.data?.warnings?.length) {
        setActionError(`Calculated with ${res.data.warnings.length} warning(s): ${res.data.warnings.map(w => `${w.name} — ${w.reason}`).join('; ')}`);
      }
      fetchRuns();
    } catch (e) {
      setActionError(describeError(e, 'Calculation failed'));
    }
  };

  const finalizeRun = async (id) => {
    setActionError(null);
    try {
      await api.post(`/payroll/runs/${id}/finalize`);
      fetchRuns();
    } catch (e) {
      setActionError(describeError(e, 'Finalization failed'));
    }
  };

  const createRun = async (e) => {
    e.preventDefault();
    setCreating(true);
    setActionError(null);
    try {
      await api.post('/payroll/runs', periodForm);
      setShowNewRun(false);
      setPeriodForm({ start_date: '', end_date: '', name: '' });
      fetchRuns();
    } catch (e) {
      setActionError(describeError(e, 'Failed to create payroll run'));
    }
    setCreating(false);
  };

  const getStatusBadge = (status) => {
    const maps = {
      DRAFT: 'bg-slate-100 text-slate-700 border-slate-200',
      PROCESSING: 'bg-amber-100 text-amber-700 border-amber-200',
      REVIEW: 'bg-blue-100 text-blue-700 border-blue-200',
      APPROVED: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      FINALIZED: 'bg-primary-100 text-primary-700 border-primary-200',
    };
    return `px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border ${maps[status] || maps.DRAFT}`;
  };

  if (error) return <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm"><AlertCircle size={16}/> {error}</div>;

  if (loading) return <div className="p-8 animate-pulse flex space-x-4"><div className="h-12 w-1/4 bg-slate-200 rounded-xl"></div></div>;

  return (
    <div className="p-8 font-sans max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 tracking-tight">Payroll Engine</h1>
          <p className="text-slate-500 mt-1">Manage processing cycles and finalize statements.</p>
        </div>
        <button onClick={() => setShowNewRun(true)} className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 text-white rounded-xl font-semibold shadow-lg shadow-primary-600/25 hover:bg-primary-700 active:scale-95 transition-all">
          <Plus size={16} /> New Run
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {[
          { label: 'Active Period', val: runs.length > 0 ? runs[0].period : '—' },
          { label: 'Total Gross', val: inr(runs.reduce((acc, r) => acc + (r.gross || 0), 0)) },
          { label: 'Deductions', val: inr(runs.reduce((acc, r) => acc + (r.deds || 0), 0)) },
          { label: 'Net Payable', val: inr(runs.reduce((acc, r) => acc + (r.net || 0), 0)) }
        ].map(kpi => (
          <div key={kpi.label} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">{kpi.label}</p>
            <p className="text-2xl font-bold text-slate-800">{kpi.val}</p>
          </div>
        ))}
      </div>

      {actionError && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 rounded-xl p-4 text-sm mb-6">{actionError}</div>
      )}

      {showNewRun && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-elevated w-full max-w-md overflow-hidden border border-slate-100">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800">New Payroll Run</h3>
              <button onClick={() => setShowNewRun(false)} className="p-1 text-slate-400 hover:bg-slate-100 rounded-lg"><X size={18} /></button>
            </div>
            <form onSubmit={createRun} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5">Period name (optional)</label>
                <input value={periodForm.name} onChange={e => setPeriodForm({ ...periodForm, name: e.target.value })} placeholder="e.g. September 2026" className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5">Start date</label>
                  <input type="date" required value={periodForm.start_date} onChange={e => setPeriodForm({ ...periodForm, start_date: e.target.value })} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5">End date</label>
                  <input type="date" required value={periodForm.end_date} min={periodForm.start_date || undefined} onChange={e => setPeriodForm({ ...periodForm, end_date: e.target.value })} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                </div>
              </div>
              <button type="submit" disabled={creating} className="w-full py-3 bg-primary-600 text-white rounded-xl font-bold shadow-lg shadow-primary-600/25 hover:bg-primary-700 disabled:opacity-60">
                {creating ? 'Creating...' : 'Create Run'}
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        {runs.length === 0 ? <div className="p-12 text-center text-sm text-slate-400">No payroll runs yet. Create one to get started.</div> :
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-sm font-semibold text-slate-600">
              <th className="p-5">Payroll Period</th>
              <th className="p-5">Status</th>
              <th className="p-5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {runs.map(run => (
              <tr key={run.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="p-5 font-semibold text-slate-800">{run.period}</td>
                <td className="p-5">
                  <span className={getStatusBadge(run.status)}>{run.status}</span>
                </td>
                <td className="p-5 flex justify-end gap-3">
                  {run.status === 'DRAFT' && (
                    <button onClick={() => calculateRun(run.id)} className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white text-sm font-medium rounded-lg hover:bg-slate-700 transition-colors">
                      <PlayCircle size={16} /> Calculate
                    </button>
                  )}
                  {run.status === 'REVIEW' && (
                    <button onClick={() => finalizeRun(run.id)} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors">
                      <CheckCircle size={16} /> Finalize
                    </button>
                  )}
                  {run.status === 'FINALIZED' && (
                    <span className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-400 text-sm font-medium rounded-lg cursor-not-allowed">
                      <Lock size={16} /> Locked
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>}
      </div>
    </div>
  );
}
