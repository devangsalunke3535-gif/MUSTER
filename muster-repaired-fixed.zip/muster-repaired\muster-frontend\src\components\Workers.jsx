import { useEffect, useState, useCallback } from 'react';
import { getWorkers, getShifts, createWorker, updateWorker, deactivateWorker, describeError, inr, SHIFT_LABEL } from '../api';
import { Edit2, Eye, ShieldCheck, ShieldAlert, X, Plus, UserPlus, ChevronLeft, ChevronRight, Search, AlertCircle } from 'lucide-react';
import WorkerDetail from './WorkerDetail';
import { useToast } from './Toast';

const PAGE_SIZE = 15;

export default function Workers() {
  const [workers, setWorkers] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(1);
  const [selectedWorker, setSelectedWorker] = useState(null);
  const [saving, setSaving] = useState(false);
  const { addToast } = useToast();

  const [newWorker, setNewWorker] = useState({ name: '', phone: '', default_shift_id: '', daily_wage: '' });

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [{ data }, shiftData] = await Promise.all([getWorkers('active'), getShifts()]);
      setWorkers(data);
      setShifts(shiftData);
    } catch (err) {
      setError(describeError(err, 'Failed to load the worker directory'));
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleAddWorker = async (e) => {
    e.preventDefault();
    if (!newWorker.name.trim()) return;
    setSaving(true);
    try {
      await createWorker(newWorker);
      addToast(`Worker "${newWorker.name}" added successfully`, 'success');
      setIsModalOpen(false);
      setNewWorker({ name: '', phone: '', default_shift_id: '', daily_wage: '' });
      await loadData();
    } catch (err) {
      addToast(describeError(err, 'Failed to add worker'), 'error');
    }
    setSaving(false);
  };

  const handleSaveWorker = async (updated) => {
    try {
      await updateWorker(updated.id, {
        phone: updated.phone,
        daily_wage: updated.daily_wage,
        default_shift_id: updated.default_shift_id,
      });
      await loadData();
      setSelectedWorker(null);
      addToast('Worker updated successfully', 'success');
    } catch (err) {
      addToast(describeError(err, 'Failed to update worker'), 'error');
    }
  };

  const handleDeactivate = async (workerId) => {
    try {
      await deactivateWorker(workerId);
      setWorkers(prev => prev.filter(w => w.id !== workerId));
      setSelectedWorker(null);
      addToast('Worker deactivated', 'warning');
    } catch (err) {
      addToast(describeError(err, 'Failed to deactivate worker'), 'error');
    }
  };

  const filteredWorkers = workers.filter(w =>
    (w.full_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (w.emp_id || '').toLowerCase().includes(searchTerm.toLowerCase())
  );
  const totalPages = Math.max(1, Math.ceil(filteredWorkers.length / PAGE_SIZE));
  const paginatedWorkers = filteredWorkers.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => { setPage(1); }, [searchTerm]);

  const shiftBadge = (w) => {
    const cls = { DAY: 'bg-amber-50 text-amber-600 border-amber-100', NIGHT: 'bg-indigo-50 text-indigo-600 border-indigo-100' }[w.shift_type]
      || 'bg-slate-50 text-slate-500 border-slate-200';
    const emoji = { DAY: '☀️', NIGHT: '🌙' }[w.shift_type] || '—';
    return <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-semibold border ${cls}`}>{emoji} {SHIFT_LABEL[w.shift_type] || 'Unassigned'}</span>;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Workers Directory</h1>
          <p className="text-slate-400 text-sm mt-1">Manage and view all {workers.length} active workers</p>
        </div>
        <button onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-all shadow-lg shadow-primary-600/20 hover:shadow-primary-600/30 active:scale-95">
          <Plus size={16} /> Add Worker
        </button>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-100 shadow-soft p-4 flex items-center gap-3">
        <Search size={16} className="text-slate-400" />
        <input type="text" placeholder="Search by name or ID..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
          className="flex-1 text-sm text-slate-700 placeholder-slate-400 outline-none" />
        <span className="text-xs text-slate-400 font-medium">{filteredWorkers.length} workers</span>
      </div>

      <div className="bg-white rounded-2xl shadow-soft overflow-hidden border border-slate-100">
        {loading ? (
          <div className="p-16 text-center">
            <div className="h-8 w-8 border-2 border-slate-200 border-t-primary-500 rounded-full animate-spin mx-auto mb-3" />
            <span className="text-sm text-slate-400">Loading directory...</span>
          </div>
        ) : filteredWorkers.length === 0 ? (
          <div className="p-16 text-center text-slate-400 text-sm">No workers found.</div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/80 text-slate-400 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-100">
                    <th className="px-6 py-3.5">Worker Info</th>
                    <th className="px-6 py-3.5">Shift</th>
                    <th className="px-6 py-3.5">Daily Wage</th>
                    <th className="px-6 py-3.5">Compliance</th>
                    <th className="px-6 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {paginatedWorkers.map(w => (
                    <tr key={w.id} className="hover:bg-primary-50/30 transition-colors group cursor-pointer" onClick={() => setSelectedWorker(w)}>
                      <td className="px-6 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center text-primary-700 font-bold text-xs shadow-sm">
                            {(w.full_name || 'U').trim().split(/\s+/).map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-800 text-sm">{w.full_name}</div>
                            <div className="text-[11px] text-slate-400 font-medium mt-0.5">{w.emp_id} • {w.phone || 'No phone'}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-3.5">{shiftBadge(w)}</td>
                      <td className="px-6 py-3.5">
                        <span className="font-semibold text-slate-700 text-sm">{w.wage?.basis === 'DAILY' ? inr(w.daily_wage) : (w.wage ? w.wage.basis : 'Not configured')}</span>
                      </td>
                      <td className="px-6 py-3.5">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            {w.has_uan ? <ShieldCheck size={13} className="text-emerald-500" /> : <ShieldAlert size={13} className="text-rose-400" />}
                            <span className={"text-[11px] font-medium " + (w.has_uan ? "text-slate-500" : "text-rose-500")}>UAN: {w.has_uan ? 'On file' : 'Missing'}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            {w.has_esi ? <ShieldCheck size={13} className="text-emerald-500" /> : <ShieldAlert size={13} className="text-rose-400" />}
                            <span className={"text-[11px] font-medium " + (w.has_esi ? "text-slate-500" : "text-rose-500")}>ESI: {w.has_esi ? 'On file' : 'Missing'}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-3.5 text-right" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => setSelectedWorker(w)} className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors" title="View"><Eye size={15} /></button>
                          <button onClick={() => setSelectedWorker(w)} className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors" title="Edit"><Edit2 size={15} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {totalPages > 1 && (
              <div className="flex items-center justify-between px-6 py-3 border-t border-slate-100 bg-slate-50/50">
                <span className="text-xs text-slate-400">
                  Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filteredWorkers.length)} of {filteredWorkers.length}
                </span>
                <div className="flex items-center gap-1">
                  <button onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1}
                    className={"p-1.5 rounded-lg transition-colors " + (page === 1 ? "text-slate-300 cursor-not-allowed" : "text-slate-500 hover:bg-slate-200")}>
                    <ChevronLeft size={16} />
                  </button>
                  {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                    const p = i + 1;
                    return (
                      <button key={p} onClick={() => setPage(p)}
                        className={"w-8 h-8 rounded-lg text-xs font-semibold transition-all " + (page === p ? "bg-primary-600 text-white shadow-sm" : "text-slate-500 hover:bg-slate-200")}>
                        {p}
                      </button>
                    );
                  })}
                  {totalPages > 5 && <span className="text-slate-400 text-xs px-1">...</span>}
                  <button onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page === totalPages}
                    className={"p-1.5 rounded-lg transition-colors " + (page === totalPages ? "text-slate-300 cursor-not-allowed" : "text-slate-500 hover:bg-slate-200")}>
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {selectedWorker && (
        <WorkerDetail worker={selectedWorker} shifts={shifts} onClose={() => setSelectedWorker(null)} onSave={handleSaveWorker} onDelete={handleDeactivate} />
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-elevated w-full max-w-md overflow-hidden animate-scale-in border border-slate-100">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center"><UserPlus size={20} className="text-primary-600" /></div>
                <div>
                  <h3 className="text-lg font-bold text-slate-800">Add New Worker</h3>
                  <p className="text-xs text-slate-400">Fill in the worker details</p>
                </div>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-slate-100 rounded-lg transition-colors"><X size={18} /></button>
            </div>
            <form onSubmit={handleAddWorker} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5">Full Name</label>
                <input type="text" required value={newWorker.name} onChange={e => setNewWorker({ ...newWorker, name: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 transition-all text-sm text-slate-700" placeholder="e.g. Rahul Kumar" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5">Phone Number</label>
                <input type="tel" value={newWorker.phone} onChange={e => setNewWorker({ ...newWorker, phone: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 transition-all text-sm text-slate-700" placeholder="e.g. 9876543210" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5">Daily Wage (₹)</label>
                  <input type="number" min="0" value={newWorker.daily_wage} onChange={e => setNewWorker({ ...newWorker, daily_wage: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 transition-all text-sm text-slate-700" placeholder="e.g. 650" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5">Default Shift</label>
                  <select value={newWorker.default_shift_id} onChange={e => setNewWorker({ ...newWorker, default_shift_id: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 transition-all text-sm text-slate-700">
                    <option value="">Unassigned</option>
                    {shifts.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
              </div>
              <div className="pt-3 flex gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2.5 bg-slate-100 text-slate-600 rounded-xl font-semibold hover:bg-slate-200 transition-colors text-sm">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 px-4 py-2.5 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 shadow-lg shadow-primary-600/20 transition-all text-sm active:scale-95 disabled:opacity-60">
                  {saving ? 'Saving...' : 'Save Worker'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
