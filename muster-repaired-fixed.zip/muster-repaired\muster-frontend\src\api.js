import axios from 'axios';

const api = axios.create({
  baseURL: '/api/v1',
  withCredentials: true, // HttpOnly session cookie
  headers: { 'Content-Type': 'application/json' },
});

let csrfToken = null;

export const fetchCsrfToken = async () => {
  const response = await api.get('/auth/csrf');
  csrfToken = response.data.csrfToken;
  api.defaults.headers.common['CSRF-Token'] = csrfToken;
  return csrfToken;
};

/**
 * Turn any request failure into an honest, user-facing message. Backend
 * outages are never reported as "invalid credentials" or as empty data.
 */
export function describeError(err, fallback = 'Something went wrong') {
  if (!err?.response) return 'Cannot reach the MUSTER server. Check your connection and try again.';
  const { status, data } = err.response;
  const server = typeof data === 'object' ? data?.error : null;
  if ([502, 503, 504].includes(status)) return 'The MUSTER server is unavailable right now. Please try again shortly.';
  if (status >= 500) return server && server !== 'Internal server error' ? server : 'Server error. Please try again.';
  if (status === 401) return 'Your session has expired. Please sign in again.';
  if (status === 403) return server || 'You do not have permission to do this.';
  if (status === 429) return server || 'Too many requests. Please wait and try again.';
  return server || fallback;
}

// Session expired → go to login (but never for the auth endpoints themselves,
// which would cause a redirect loop).
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      const url = error.config?.url || '';
      const isAuthEndpoint = url.includes('/auth/login') || url.includes('/auth/csrf') || url.includes('/auth/me') || url.includes('/auth/change-password');
      if (!isAuthEndpoint && window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// ---------------------------------------------------------------------------
// Employees — the API returns a server-computed DTO (daily_wage, shift,
// shift_type, status, branch, has_uan, has_esi). The UI renders those fields
// directly; missing values arrive as null and are shown as "Not configured".
// ---------------------------------------------------------------------------
export const getWorkers = async (status = 'active') => {
  const res = await api.get('/employees', { params: { status, limit: 1000 } });
  return { data: res.data?.data || [], total: res.data?.meta?.total ?? 0 };
};
export const getWorker = async (id) => (await api.get(`/employees/${id}`)).data.data;
export const getMyProfile = async () => (await api.get('/employees/me')).data.data;

export const createWorker = async ({ name, phone, daily_wage, default_shift_id, branch_id }) => {
  const parts = name.trim().split(/\s+/);
  const res = await api.post('/employees', {
    first_name: parts[0],
    last_name: parts.slice(1).join(' '),
    phone,
    daily_wage: daily_wage === '' ? undefined : Number(daily_wage),
    default_shift_id: default_shift_id || null,
    branch_id: branch_id || undefined,
  });
  return res.data.data;
};
export const updateWorker = async (id, data) => (await api.put(`/employees/${id}`, data)).data.data;
export const deactivateWorker = async (id) => (await api.delete(`/employees/${id}`)).data;

export const getShifts = async () => (await api.get('/shifts')).data?.data || [];
export const getBranches = async () => (await api.get('/branches')).data?.data || [];

// Dashboard / reports
export const getSummary = async (date) => (await api.get('/dashboard/summary', { params: date ? { date } : {} })).data;
export const getCompliance = async () => (await api.get('/dashboard/compliance')).data;

// Attendance — employee_id is ALWAYS the Employee UUID (never the "W-1001" code).
export const getAttendance = async (date) => (await api.get(`/attendance/date/${date}`)).data?.data || [];
export const markAttendanceBulk = async (date, entries) => (await api.post('/attendance/mark-bulk', { date, entries })).data;
export const markAttendance = async (employeeId, date, status, shiftId) =>
  (await api.post('/attendance/mark', { employee_id: employeeId, date, status, ...(shiftId ? { shift_id: shiftId } : {}) })).data;

// Approvals
export const approveLeave = async (id) => (await api.post(`/leaves/requests/${id}/approve`)).data;
export const rejectLeave = async (id) => (await api.post(`/leaves/requests/${id}/reject`)).data;
export const approveLoan = async (id) => (await api.post(`/loans/${id}/approve`)).data;
export const rejectLoan = async (id) => (await api.post(`/loans/${id}/reject`)).data;

// ---------------------------------------------------------------------------
// Formatting helpers (shared so every page shows missing data the same way)
// ---------------------------------------------------------------------------
export const inr = (n) => (n === null || n === undefined || Number.isNaN(Number(n)))
  ? '—'
  : '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 });

export const todayISO = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });

export const fmtDate = (d) => d
  ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' })
  : '—';

export const fmtTime = (d) => d
  ? new Date(d).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata' })
  : '—';

export const fmtMins = (m) => (m === null || m === undefined) ? '—' : `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`;

export const SHIFT_LABEL = { DAY: 'Day', NIGHT: 'Night', OTHER: 'Other', UNASSIGNED: 'Unassigned' };

export default api;
