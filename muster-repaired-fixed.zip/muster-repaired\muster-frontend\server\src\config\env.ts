import 'dotenv/config';

/**
 * Centralised environment configuration.
 *
 * Every module that needs a secret reads it from here, so there is exactly one
 * place that decides whether an insecure development fallback is acceptable.
 * In production a missing or placeholder secret is fatal.
 */
export const isProd = process.env.NODE_ENV === 'production';
export const isTest = process.env.NODE_ENV === 'test';

const DEV_JWT_FALLBACK = 'dev-only-insecure-jwt-secret-do-not-use-in-production';
const DEV_ENCRYPTION_FALLBACK = 'dev-only-insecure-32-byte-key!!!'; // exactly 32 chars

// Values that have appeared in this repository or its .env.example. Using any of
// them in production means the secret is effectively public.
const KNOWN_PUBLIC_SECRETS = new Set([
  'super-secret-jwt-key-change-in-production',
  'generate-a-secure-random-string-for-jwt',
  '32-character-secure-random-string-here',
  '12345678901234567890123456789012',
  '01234567890123456789012345678912',
  DEV_JWT_FALLBACK,
  DEV_ENCRYPTION_FALLBACK,
]);

function fatal(message: string): never {
  // Never print the secret value itself.
  console.error(`⛔ FATAL: ${message} Refusing to start.`);
  process.exit(1);
  throw new Error(message); // unreachable at runtime; satisfies the `never` return type
}

function resolveSecret(name: string, devFallback: string): string {
  const value = process.env[name];
  if (!value) {
    if (isProd) fatal(`${name} is not set.`);
    console.warn(`⚠️  ${name} is not set — using an insecure development fallback. Never use this in production.`);
    return devFallback;
  }
  if (isProd && KNOWN_PUBLIC_SECRETS.has(value)) {
    fatal(`${name} is set to a publicly known placeholder value.`);
  }
  return value;
}

export const JWT_SECRET = resolveSecret('JWT_SECRET', DEV_JWT_FALLBACK);
export const ENCRYPTION_KEY = resolveSecret('ENCRYPTION_KEY', DEV_ENCRYPTION_FALLBACK);

if (Buffer.byteLength(ENCRYPTION_KEY) !== 32) {
  fatal('ENCRYPTION_KEY must be exactly 32 bytes for AES-256-GCM.');
}

export const CORS_ORIGIN = process.env.CORS_ORIGIN || (isProd ? '' : 'http://localhost:5173');
if (isProd && !CORS_ORIGIN) fatal('CORS_ORIGIN must be set in production.');

export const PORT = Number(process.env.PORT) || 3000;
