import { useState, useEffect } from 'react';
import { Building, Bell, Shield, Smartphone, Save, Check, AlertCircle } from 'lucide-react';
import api, { describeError } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';

function ToggleSwitch({ label, description, isOn, onToggle }) {
  return (
    <div className="flex items-center justify-between py-4 border-b border-slate-100 last:border-0">
      <div>
        <h4 className="text-sm font-semibold text-slate-800">{label}</h4>
        <p className="text-xs text-slate-400 mt-0.5">{description}</p>
      </div>
      <button type="button" onClick={onToggle}
        className={isOn ? "relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 bg-primary-500 shadow-inner" : "relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 bg-slate-200"}>
        <span className={isOn ? "inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 translate-x-6 shadow-sm" : "inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 translate-x-1 shadow-sm"} />
      </button>
    </div>
  );
}

export default function Settings() {
  const { user, hasPermission } = useAuth();
  const { addToast } = useToast();
  const [activeTab, setActiveTab] = useState('profile');

  // Company profile — real, persisted via PUT /organization.
  const [org, setOrg] = useState(null);
  const [orgLoading, setOrgLoading] = useState(true);
  const [orgError, setOrgError] = useState(null);
  const [saving, setSaving] = useState(false);
  const canEditOrg = hasPermission('org:update');

  useEffect(() => {
    api.get('/organization')
      .then(res => setOrg(res.data.data))
      .catch(err => setOrgError(describeError(err, 'Failed to load organization profile')))
      .finally(() => setOrgLoading(false));
  }, []);

  const saveOrg = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await api.put('/organization', {
        name: org.name, legal_name: org.legal_name, website: org.website, pan: org.pan, tan: org.tan, gstin: org.gstin,
      });
      setOrg(res.data.data);
      addToast('Company profile saved', 'success');
    } catch (err) {
      addToast(describeError(err, 'Failed to save'), 'error');
    }
    setSaving(false);
  };

  // Notifications — this app has no notification-delivery backend at all
  // (no email/SMS provider is wired up anywhere in the server). These toggles
  // are shown as an honestly-unavailable feature rather than a fake save.
  const [notifPrefs, setNotifPrefs] = useState({ emailNotifications: true, smsAlerts: false, autoReports: true });

  const [pwForm, setPwForm] = useState({ current_password: '', new_password: '', confirm: '' });
  const [pwSaving, setPwSaving] = useState(false);
  const [pwMsg, setPwMsg] = useState(null);

  const changePassword = async (e) => {
    e.preventDefault();
    setPwMsg(null);
    if (pwForm.new_password !== pwForm.confirm) { setPwMsg({ type: 'error', text: 'New passwords do not match' }); return; }
    if (pwForm.new_password.length < 8) { setPwMsg({ type: 'error', text: 'New password must be at least 8 characters' }); return; }
    setPwSaving(true);
    try {
      const res = await api.post('/auth/change-password', { current_password: pwForm.current_password, new_password: pwForm.new_password });
      setPwMsg({ type: 'success', text: res.data.message });
      setPwForm({ current_password: '', new_password: '', confirm: '' });
    } catch (err) {
      setPwMsg({ type: 'error', text: describeError(err, 'Failed to change password') });
    }
    setPwSaving(false);
  };

  const tabs = [
    { id: 'profile', label: 'Company Profile', icon: Building },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'security', label: 'Security', icon: Shield },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Settings</h1>
        <p className="text-slate-400 text-sm mt-1">Manage your platform configuration</p>
      </div>

      <div className="bg-white rounded-2xl shadow-soft flex flex-col md:flex-row overflow-hidden border border-slate-100 min-h-[550px]">
        <div className="w-full md:w-56 bg-slate-50/50 border-r border-slate-100 p-4 flex flex-col space-y-1">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            const base = "flex items-center space-x-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 w-full";
            const cls = isActive ? base + " bg-primary-50 text-primary-600 shadow-sm border border-primary-100" : base + " text-slate-500 hover:bg-slate-100 hover:text-slate-700";
            return (
              <button key={tab.id} type="button" onClick={() => setActiveTab(tab.id)} className={cls}>
                <Icon size={16} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <div className="flex-1 p-8">
          {activeTab === 'profile' && (
            <div className="max-w-lg animate-fade-in">
              <h3 className="text-lg font-bold text-slate-800 mb-1">Company Profile</h3>
              <p className="text-sm text-slate-400 mb-6">Update your organization's registered information</p>

              {orgError && (
                <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm mb-4">
                  <AlertCircle size={16} /> {orgError}
                </div>
              )}

              {orgLoading ? (
                <div className="space-y-3 animate-pulse">
                  {[1, 2, 3].map(i => <div key={i} className="h-11 bg-slate-100 rounded-xl" />)}
                </div>
              ) : org && (
                <form onSubmit={saveOrg} className="space-y-5">
                  <div>
                    <label className="block text-sm font-semibold text-slate-600 mb-1.5">Company Name</label>
                    <input type="text" value={org.name || ''} disabled={!canEditOrg} onChange={e => setOrg({ ...org, name: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 transition-all text-sm text-slate-700 disabled:opacity-60" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-600 mb-1.5">Legal Name</label>
                    <input type="text" value={org.legal_name || ''} disabled={!canEditOrg} onChange={e => setOrg({ ...org, legal_name: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 transition-all text-sm text-slate-700 disabled:opacity-60" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-600 mb-1.5">Website</label>
                    <div className="relative">
                      <Smartphone className="absolute left-3.5 top-3 text-slate-400" size={16} />
                      <input type="text" value={org.website || ''} disabled={!canEditOrg} onChange={e => setOrg({ ...org, website: e.target.value })} placeholder="https://example.com"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 transition-all text-sm text-slate-700 disabled:opacity-60" />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1.5">PAN</label>
                      <input type="text" value={org.pan || ''} disabled={!canEditOrg} onChange={e => setOrg({ ...org, pan: e.target.value.toUpperCase() })} maxLength={10}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 disabled:opacity-60 font-mono" />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1.5">TAN</label>
                      <input type="text" value={org.tan || ''} disabled={!canEditOrg} onChange={e => setOrg({ ...org, tan: e.target.value.toUpperCase() })} maxLength={10}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 disabled:opacity-60 font-mono" />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1.5">GSTIN</label>
                      <input type="text" value={org.gstin || ''} disabled={!canEditOrg} onChange={e => setOrg({ ...org, gstin: e.target.value.toUpperCase() })} maxLength={15}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 disabled:opacity-60 font-mono" />
                    </div>
                  </div>

                  {canEditOrg ? (
                    <div className="pt-3">
                      <button type="submit" disabled={saving}
                        className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl font-semibold transition-all shadow-lg shadow-primary-600/20 text-sm active:scale-95 disabled:opacity-60">
                        <Save size={16} />
                        <span>{saving ? 'Saving...' : 'Save Changes'}</span>
                      </button>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 italic">You need the org:update permission to edit this.</p>
                  )}
                </form>
              )}
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="max-w-lg animate-fade-in">
              <h3 className="text-lg font-bold text-slate-800 mb-1">Notification Preferences</h3>
              <p className="text-sm text-slate-400 mb-2">Manage how you receive alerts and reports</p>
              <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4">
                <AlertCircle size={14} className="text-amber-600 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-amber-800">MUSTER does not yet send email or SMS notifications — there is no
                  delivery provider configured on the server. These toggles are shown for preview and are not saved.</p>
              </div>

              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 opacity-70 pointer-events-none">
                <ToggleSwitch label="Email Notifications" description="Daily summary emails after shifts close" isOn={notifPrefs.emailNotifications} onToggle={() => {}} />
                <ToggleSwitch label="SMS Alerts" description="Instant SMS for 3+ consecutive absent days" isOn={notifPrefs.smsAlerts} onToggle={() => {}} />
                <ToggleSwitch label="Monthly Reports" description="Auto-compile monthly compliance reports" isOn={notifPrefs.autoReports} onToggle={() => {}} />
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="max-w-lg animate-fade-in">
              <h3 className="text-lg font-bold text-slate-800 mb-1">Security</h3>
              <p className="text-sm text-slate-400 mb-6">Change your password. This signs you (and every other device) out everywhere else.</p>

              <form onSubmit={changePassword} className="p-5 border border-slate-200 rounded-2xl space-y-4">
                {pwMsg && (
                  <div className={`rounded-xl p-3 text-sm flex items-center gap-2 ${pwMsg.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'}`}>
                    {pwMsg.type === 'success' ? <Check size={15} /> : <AlertCircle size={15} />} {pwMsg.text}
                  </div>
                )}
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5">Current Password</label>
                  <input type="password" required value={pwForm.current_password} onChange={e => setPwForm({ ...pwForm, current_password: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5">New Password</label>
                  <input type="password" required minLength={8} value={pwForm.new_password} onChange={e => setPwForm({ ...pwForm, new_password: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1.5">Confirm New Password</label>
                  <input type="password" required value={pwForm.confirm} onChange={e => setPwForm({ ...pwForm, confirm: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                </div>
                <button type="submit" disabled={pwSaving} className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-xl text-sm font-semibold transition-colors active:scale-95 disabled:opacity-60">
                  {pwSaving ? 'Changing...' : 'Change Password'}
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
