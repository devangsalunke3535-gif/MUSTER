import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, WifiOff } from 'lucide-react';

function Spinner() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="h-8 w-8 border-2 border-slate-200 border-t-primary-500 rounded-full animate-spin" />
    </div>
  );
}

export default function ProtectedRoute() {
  const { user, loading, bootError, refetchUser } = useAuth();
  if (loading) return <Spinner />;
  if (!user && bootError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 max-w-md text-center shadow-soft">
          <WifiOff className="mx-auto text-rose-500 mb-3" size={32} />
          <h1 className="text-lg font-bold text-slate-800">Server unavailable</h1>
          <p className="text-sm text-slate-500 mt-2">{bootError}</p>
          <button onClick={refetchUser} className="mt-5 px-5 py-2.5 bg-primary-600 text-white rounded-xl text-sm font-semibold hover:bg-primary-700">Retry</button>
        </div>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  return <Outlet />;
}

/** Route-level guard. The backend still enforces every permission; this only avoids showing pages that would 403. */
export function RequirePermission({ perm, workerOnly, children }) {
  const { hasPermission, isWorker, user } = useAuth();
  const allowed = workerOnly ? !!user?.employee : (Array.isArray(perm) ? perm.some(hasPermission) : hasPermission(perm));
  if (!allowed) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center shadow-soft">
        <ShieldAlert className="mx-auto text-amber-500 mb-3" size={32} />
        <h2 className="text-lg font-bold text-slate-800">
          {workerOnly ? 'No employee profile linked' : 'You do not have access to this page'}
        </h2>
        <p className="text-sm text-slate-500 mt-1">
          {workerOnly
            ? 'Your login is not linked to an employee record, so there is no personal attendance, leave or salary to show.'
            : 'Ask your administrator if you need access.'}
        </p>
        <a href={isWorker ? '/home' : '/dashboard'} className="inline-block mt-4 text-sm font-semibold text-primary-600">Go to home</a>
      </div>
    );
  }
  return children;
}
