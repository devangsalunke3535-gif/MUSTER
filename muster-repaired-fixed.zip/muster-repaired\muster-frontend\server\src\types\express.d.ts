import { User } from '@prisma/client';

declare global {
  namespace Express {
    interface Request {
      user?: User;
      authContext?: {
        userId: string;
        organizationId: string;
        tokenVersion: number;
      };
      permissions?: Set<string>;
    }
  }
}
