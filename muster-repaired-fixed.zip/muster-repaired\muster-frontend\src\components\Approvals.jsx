import { useState, useEffect, useCallback } from 'react';
import api, { approveLeave, rejectLeave, approveLoan, rejectLoan, describeError, inr, fmtDate } from '../api';
import { CheckCircle, XCircle, Clock, AlertCircle, Calendar as CalIcon, IndianRupee, Lock } from 'lucide-react';
import { useToast } from './Toast';

/**
 * Combined leave + advance approvals inbox.
 *
 * Each row's approve/reject buttons are enabled only when the server says
 * `can_decide: true` for the current user (they are the assigned approver,
 * or a super admin) — the backend enforces this regardless, but the UI
 * reflects it honestly instead of showing buttons that will 403.
 */
export default function Approvals() {
  const [tab, setTab] = useState('leave');
  const [leaves, setLeaves] = useState([]);
  const [loans, setLoans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const { addToast } = useToast();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [leaveRes, loanRes] = await Promise.all([
        api.get('/leaves/requests').catch(() => ({ data: { data: [] } })),
        api.get('/loans').catch(() => ({ data: { data: [] } })),
      ]);
      setLeaves(leaveRes.data?.data || []);
      setLoans(loanRes.data?.data || []);
      setError(null);
    } catch (err) {
      setError(describeError(err, 'Failed to load approvals'));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { load(); }, [load]);

  const badge = (status) => {
    const maps = {
      APPROVED: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      ACTIVE: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      PENDING: 'bg-amber-100 text-amber-700 border-amber-200',
      REJECTED: 'bg-rose-100 text-rose-700 border-rose-200',
    };
    return `px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${maps[status] || maps.PENDING}`;
  };

  const decide = async (kind, id, action) => {
    setBusyId(id);
    try {
      if (kind === 'leave') await (action === 'approve' ? approveLeave(id) : rejectLeave(id));
      else await (action === 'approve' ? approveLoan(id) : rejectLoan(id));
      addToast(`Request ${action === 'approve' ? 'approved' : 'rejected'}`, 'success');
      await load();
    } catch (err) {
      addToast(describeError(err, 'Action failed'), 'error');
    }
    setBusyId(null);
  };

  const pendingLeaves = leaves.filter(l => l.status === 'PENDING');
  const pendingLoans = loans.filter(l => l.status === 'PENDING');

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Approvals</h1>
        <p className="text-slate-400 text-sm mt-1">{pendingLeaves.length + pendingLoans.length} request(s) waiting on you</p>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      <div className="flex gap-2 bg-white p-1.5 rounded-xl border border-slate-100 shadow-soft w-max">
        <button onClick={() => setTab('leave')} className={tab === 'leave' ? "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold bg-primary-600 text-white shadow-sm" : "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-slate-500 hover:bg-slate-50"}>
          <CalIcon size={15} /> Leave ({pendingLeaves.length})
        </button>
        <button onClick={() => setTab('loan')} className={tab === 'loan' ? "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold bg-primary-600 text-white shadow-sm" : "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-slate-500 hover:bg-slate-50"}>
          <IndianRupee size={15} /> Advances ({pendingLoans.length})
        </button>
      </div>

      {loading ? (
        <div className="bg-white p-16 rounded-2xl shadow-soft text-center"><div className="h-8 w-8 border-2 border-slate-200 border-t-primary-500 rounded-full animate-spin mx-auto" /></div>
      ) : tab === 'leave' ? (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          {leaves.length === 0 ? <div className="p-12 text-center text-sm text-slate-400">No leave requests.</div> : (
            <table className="w-full text-left border-collapse">
              <thead><tr className="bg-slate-50 border-b border-slate-200 text-sm font-semibold text-slate-600">
                <th className="p-5">Worker</th><th className="p-5">Type</th><th className="p-5">Dates</th><th className="p-5">Status</th><th className="p-5 text-right">Action</th>
              </tr></thead>
              <tbody className="divide-y divide-slate-100">
                {leaves.map(l => (
                  <tr key={l.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-5 font-semibold text-slate-800">{`${l.employee?.first_name || ''} ${l.employee?.last_name || ''}`.trim() || 'Worker'}</td>
                    <td className="p-5 text-sm text-slate-700">{l.leaveType?.name}<div className="text-xs text-slate-400 max-w-xs truncate">{l.reason}</div></td>
                    <td className="p-5 text-sm text-slate-700">{fmtDate(l.start_date)} — {fmtDate(l.end_date)} · {l.duration_days}d</td>
                    <td className="p-5"><span className={badge(l.status)}>{l.status}</span></td>
                    <td className="p-5 text-right">
                      {l.status !== 'PENDING' ? <span className="text-xs text-slate-400">Processed</span>
                        : l.can_decide ? (
                          <div className="flex justify-end gap-2">
                            <button disabled={busyId === l.id} onClick={() => decide('leave', l.id, 'approve')} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg disabled:opacity-50"><CheckCircle size={18} /></button>
                            <button disabled={busyId === l.id} onClick={() => decide('leave', l.id, 'reject')} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg disabled:opacity-50"><XCircle size={18} /></button>
                          </div>
                        ) : <span className="flex items-center justify-end gap-1 text-xs text-slate-400"><Lock size={12} /> Not your step</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          {loans.length === 0 ? <div className="p-12 text-center text-sm text-slate-400">No advance requests.</div> : (
            <table className="w-full text-left border-collapse">
              <thead><tr className="bg-slate-50 border-b border-slate-200 text-sm font-semibold text-slate-600">
                <th className="p-5">Worker</th><th className="p-5">Amount</th><th className="p-5">Reason</th><th className="p-5">Status</th><th className="p-5 text-right">Action</th>
              </tr></thead>
              <tbody className="divide-y divide-slate-100">
                {loans.map(l => (
                  <tr key={l.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-5 font-semibold text-slate-800">{`${l.employee?.first_name || ''} ${l.employee?.last_name || ''}`.trim() || 'Worker'}</td>
                    <td className="p-5 text-sm font-bold text-slate-800">{inr(l.amount)}</td>
                    <td className="p-5 text-sm text-slate-600">{l.reason || '—'}</td>
                    <td className="p-5"><span className={badge(l.status)}>{l.status}</span></td>
                    <td className="p-5 text-right">
                      {l.status !== 'PENDING' ? <span className="text-xs text-slate-400">Processed</span>
                        : l.can_decide ? (
                          <div className="flex justify-end gap-2">
                            <button disabled={busyId === l.id} onClick={() => decide('loan', l.id, 'approve')} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg disabled:opacity-50"><CheckCircle size={18} /></button>
                            <button disabled={busyId === l.id} onClick={() => decide('loan', l.id, 'reject')} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg disabled:opacity-50"><XCircle size={18} /></button>
                          </div>
                        ) : <span className="flex items-center justify-end gap-1 text-xs text-slate-400"><Lock size={12} /> Not your step</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}
