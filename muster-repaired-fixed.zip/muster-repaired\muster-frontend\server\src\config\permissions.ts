/**
 * Canonical permission catalogue and default role grants.
 * Used by prisma/seed.ts (and available to tests) so there is one list, not
 * several drifting copies in ad-hoc scripts.
 */
export const PERMISSIONS: { code: string; module: string; action: string; description: string }[] = [
  ['org:view', 'View organization profile'],
  ['org:update', 'Edit organization profile'],
  ['branch:create', 'Create branches'],
  ['employee:view', 'View employee directory and org dashboards'],
  ['employee:create', 'Add employees'],
  ['employee:update', 'Edit employees'],
  ['employee:delete', 'Deactivate employees'],
  ['employee:bank:view', 'View unmasked bank account numbers'],
  ['employee:bank:update', 'Edit bank details'],
  ['holiday:view', 'View holidays'],
  ['holiday:create', 'Create holidays'],
  ['holiday:update', 'Edit holidays'],
  ['leave_type:view', 'View leave types'],
  ['leave_type:create', 'Create leave types'],
  ['leave:view', 'View own leave'],
  ['leave:create', 'Request leave'],
  ['leave:cancel', 'Cancel own leave'],
  ['leave:approve', 'Approve/reject leave requests'],
  ['leave:manage', 'Allocate leave balances, view others\' balances'],
  ['shift:view', 'View shifts'],
  ['shift:create', 'Create shifts'],
  ['shift:update', 'Edit shifts'],
  ['attendance:create', 'Own check-in / check-out'],
  ['attendance:view', 'View own attendance history'],
  ['attendance:manage', 'Mark and view attendance for other employees'],
  ['attendance:correction:create', 'Request attendance corrections'],
  ['attendance:correction:approve', 'Approve attendance corrections'],
  ['attendance:correction:view', 'View attendance corrections'],
  ['loan:request', 'Request a salary advance'],
  ['loan:manage', 'Issue, approve and reject advances'],
  ['payroll:view', 'View payroll runs'],
  ['payroll:manage', 'Manage payroll periods'],
  ['payroll:create', 'Create payroll runs'],
  ['payroll:calculate', 'Calculate payroll runs'],
  ['payroll:finalize', 'Finalize payroll runs'],
  ['salary:manage', 'Manage salary components and structures'],
  ['salary_statement:view', 'View own payslips'],
].map(([code, description]) => {
  const i = code.indexOf(':');
  return { code, module: code.slice(0, i), action: code.slice(i + 1), description };
});

export const WORKER_PERMISSIONS = [
  'leave:view', 'leave:create', 'leave:cancel', 'leave_type:view',
  'attendance:create', 'attendance:view', 'attendance:correction:create',
  'loan:request', 'salary_statement:view',
];

export const SITE_MANAGER_PERMISSIONS = [
  ...WORKER_PERMISSIONS,
  'org:view',
  'employee:view', 'employee:create', 'employee:update', 'employee:bank:update',
  'holiday:view', 'holiday:create', 'holiday:update',
  'leave_type:create', 'leave:approve', 'leave:manage',
  'shift:view', 'shift:create', 'shift:update',
  'attendance:manage', 'attendance:correction:approve', 'attendance:correction:view',
  'loan:manage',
  'payroll:view', 'payroll:manage', 'payroll:create', 'payroll:calculate', 'payroll:finalize',
  'salary:manage',
];

export const SUPER_ADMIN_PERMISSIONS = PERMISSIONS.map(p => p.code);
