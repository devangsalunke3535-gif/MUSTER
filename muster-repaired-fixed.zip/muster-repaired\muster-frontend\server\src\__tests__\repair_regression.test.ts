/**
 * Regression suite for the forensic-audit repairs. REQUIRES the muster_test
 * Postgres database (see jest.db-guard.js) — it wipes that database.
 *
 * Covers: auth contract + token revocation, employee wage/shift persistence and
 * tenant validation, safe deactivation, attendance UUID contract + RBAC,
 * check-in using the worker's own shift, leave/loan approval synchronisation and
 * step authorisation, payroll idempotency/concurrency/immutability/multi-loan
 * cap, dashboard shift grouping, and cross-tenant rejection.
 */
import request from 'supertest';
import app from '../server';
import { prisma } from '../config/db';
import * as argon2 from 'argon2';
import { PERMISSIONS, WORKER_PERMISSIONS, SITE_MANAGER_PERMISSIONS, SUPER_ADMIN_PERMISSIONS } from '../config/permissions';

const PASSWORD = 'Regress123!';
const TODAY = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
const MONTH_START = `${TODAY.slice(0, 7)}-01`;

async function wipe() {
  const tables: { tablename: string }[] = await prisma.$queryRaw`SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename <> '_prisma_migrations'`;
  // jest.db-guard.js guarantees this is a *_test database before any test file loads.
  for (const { tablename } of tables) await prisma.$executeRawUnsafe(`TRUNCATE TABLE "${tablename}" CASCADE`);
}

type Session = { cookies: string[]; csrf: string };
let csrfCookie: string;
let csrfToken: string;

async function login(email: string): Promise<Session> {
  const res = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email, password: PASSWORD });
  if (res.status !== 200) throw new Error(`login ${email} failed: ${res.status} ${JSON.stringify(res.body)}`);
  const set: string[] = ([] as string[]).concat(res.headers['set-cookie'] as any);
  const session = set.find(c => c.startsWith('muster_session='))!.split(';')[0];
  return { cookies: [csrfCookie, session], csrf: csrfToken };
}
const as = (s: Session) => ({
  get: (u: string) => request(app).get(u).set('Cookie', s.cookies).set('CSRF-Token', s.csrf),
  post: (u: string, b?: any) => request(app).post(u).set('Cookie', s.cookies).set('CSRF-Token', s.csrf).send(b ?? {}),
  put: (u: string, b?: any) => request(app).put(u).set('Cookie', s.cookies).set('CSRF-Token', s.csrf).send(b ?? {}),
  del: (u: string) => request(app).delete(u).set('Cookie', s.cookies).set('CSRF-Token', s.csrf),
});

const ids: any = {};
let admin: Session, manager: Session, worker: Session, otherManager: Session, foreignAdmin: Session;

beforeAll(async () => {
  await wipe();
  const hash = await argon2.hash(PASSWORD);
  for (const p of PERMISSIONS) await prisma.permission.create({ data: p });
  const perm = new Map((await prisma.permission.findMany()).map(p => [p.code, p.id]));

  async function makeOrg(code: string) {
    const org = await prisma.organization.create({ data: { name: `Org ${code}`, code, legal_name: `Org ${code} Ltd` } });
    const branch = await prisma.branch.create({ data: { organization_id: org.id, name: 'HQ', code: 'HQ', city: 'Mumbai', state: 'MH', country: 'India', is_headquarters: true } });
    const roles: any = {};
    for (const [rc, codes] of [['SUPER_ADMIN', SUPER_ADMIN_PERMISSIONS], ['SITE_MANAGER', SITE_MANAGER_PERMISSIONS], ['WORKER', WORKER_PERMISSIONS]] as const) {
      roles[rc] = await prisma.role.create({ data: { organization_id: org.id, name: rc, code: rc } });
      await prisma.rolePermission.createMany({ data: codes.map(c => ({ role_id: roles[rc].id, permission_id: perm.get(c)! })) });
    }
    const day = await prisma.shift.create({ data: { organization_id: org.id, name: 'Day Shift', start_time: '09:00', end_time: '18:00' } });
    const night = await prisma.shift.create({ data: { organization_id: org.id, name: 'Night Shift', start_time: '21:00', end_time: '06:00' } });
    return { org, branch, roles, day, night };
  }
  async function person(o: any, email: string, role: string, empId: string, opts: { superAdmin?: boolean; managerId?: string; shiftId?: string } = {}) {
    const user = await prisma.user.create({ data: { organization_id: o.org.id, email, password_hash: hash, is_super_admin: !!opts.superAdmin } });
    await prisma.userRole.create({ data: { user_id: user.id, role_id: o.roles[role].id, scope_organization_id: o.org.id, scope_branch_id: role === 'SUPER_ADMIN' ? null : o.branch.id } });
    const emp = await prisma.employee.create({
      data: {
        organization_id: o.org.id, user_id: user.id, emp_id: empId, first_name: empId, last_name: 'T', default_shift_id: opts.shiftId ?? null,
        employment: { create: { joining_date: new Date('2026-01-01'), status: 'ACTIVE', manager_id: opts.managerId ?? null } },
        assignmentHistory: { create: { branch_id: o.branch.id, effective_from: new Date('2026-01-01') } },
      }
    });
    return emp;
  }

  const A = await makeOrg('RA');
  const B = await makeOrg('RB');
  Object.assign(ids, { orgA: A.org.id, branchA: A.branch.id, dayA: A.day.id, nightA: A.night.id, branchB: B.branch.id, nightB: B.night.id });

  ids.adminEmp = (await person(A, 'admin@r.test', 'SUPER_ADMIN', 'A-1', { superAdmin: true })).id;
  ids.managerEmp = (await person(A, 'manager@r.test', 'SITE_MANAGER', 'M-1', { managerId: ids.adminEmp })).id;
  ids.otherManagerEmp = (await person(A, 'manager2@r.test', 'SITE_MANAGER', 'M-2')).id;
  ids.workerEmp = (await person(A, 'worker@r.test', 'WORKER', 'W-1001', { managerId: ids.managerEmp, shiftId: A.night.id })).id;
  ids.foreignEmp = (await person(B, 'admin@rb.test', 'SUPER_ADMIN', 'B-1', { superAdmin: true })).id;

  const lt = await prisma.leaveType.create({ data: { organization_id: A.org.id, name: 'Annual', code: 'AL', is_paid: true } });
  ids.leaveType = lt.id;
  await prisma.leaveBalance.create({ data: { employee_id: ids.workerEmp, leave_type_id: lt.id, leave_year: Number(TODAY.slice(0, 4)), allocated_balance: 10, remaining_balance: 10 } });
  const basic = await prisma.salaryComponent.create({ data: { organization_id: A.org.id, name: 'Basic', code: 'BASIC', type: 'EARNING' } });
  await prisma.salaryStructure.create({ data: { organization_id: A.org.id, employee_id: ids.workerEmp, wage_basis: 'DAILY', effective_from: new Date('2026-01-01'), items: { create: [{ salary_component_id: basic.id, amount: 1000 }] } } });
  ids.foreignComponent = (await prisma.salaryComponent.create({ data: { organization_id: B.org.id, name: 'X', code: 'X', type: 'EARNING' } })).id;
  ids.foreignPeriod = (await prisma.payrollPeriod.create({ data: { organization_id: B.org.id, name: 'B', start_date: new Date('2025-01-01'), end_date: new Date('2025-01-31') } })).id;

  const c = await request(app).get('/api/v1/auth/csrf');
  csrfToken = c.body.csrfToken;
  csrfCookie = ([] as string[]).concat(c.headers['set-cookie'] as any)[0].split(';')[0];
  admin = await login('admin@r.test');
  manager = await login('manager@r.test');
  otherManager = await login('manager2@r.test');
  worker = await login('worker@r.test');
  foreignAdmin = await login('admin@rb.test');
}, 60000);

afterAll(async () => { await prisma.$disconnect(); });

describe('Auth contract', () => {
  it('login and /auth/me return the same user payload with flat permissions and roles', async () => {
    const r = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'manager@r.test', password: PASSWORD });
    const me = await as(manager).get('/api/v1/auth/me');
    expect(me.status).toBe(200);
    expect(me.body.user).toEqual(r.body.user);
    expect(me.body.user.roles).toEqual(['SITE_MANAGER']);
    expect(me.body.user.permissions).toContain('attendance:manage');
    expect(me.body.user.employee.emp_id).toBe('M-1');
    expect(me.body.user.userRoles[0].role.permissions.length).toBeGreaterThan(0); // legacy shape kept
  });

  it('logout revokes the token server-side: replaying the old cookie is rejected', async () => {
    const s = await login('manager2@r.test');
    expect((await as(s).get('/api/v1/auth/me')).status).toBe(200);
    expect((await as(s).post('/api/v1/auth/logout')).status).toBe(200);
    expect((await as(s).get('/api/v1/auth/me')).status).toBe(401);
    expect((await as(s).get('/api/v1/employees')).status).toBe(401);
    otherManager = await login('manager2@r.test'); // re-login works
    expect((await as(otherManager).get('/api/v1/auth/me')).status).toBe(200);
  });

  it('wrong password is 401; missing CSRF is 403 (distinct, not masked)', async () => {
    const bad = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'worker@r.test', password: 'nope' });
    expect(bad.status).toBe(401);
    const noCsrf = await request(app).post('/api/v1/auth/login').send({ email: 'worker@r.test', password: PASSWORD });
    expect(noCsrf.status).toBe(403);
  });
});

describe('Employee directory', () => {
  it('creates a worker whose ₹800 wage and Night shift persist and are returned on a fresh GET', async () => {
    const res = await as(admin).post('/api/v1/employees', { first_name: 'Test', last_name: 'Worker', phone: '9000000000', daily_wage: 800, default_shift: 'night' });
    expect(res.status).toBe(200);
    ids.testWorker = res.body.data.id;
    expect(res.body.data.emp_id).toMatch(/^W-\d+$/);

    const list = await as(admin).get('/api/v1/employees');
    const w = list.body.data.find((e: any) => e.id === ids.testWorker);
    expect(w.daily_wage).toBe(800);
    expect(w.shift_type).toBe('NIGHT');
    expect(w.shift.id).toBe(ids.nightA);
    expect(w.branch.id).toBe(ids.branchA); // defaults to HQ so it is visible
    expect(w.status).toBe('ACTIVE');
  });

  it('edit persists wage, phone, shift and status', async () => {
    const res = await as(manager).put(`/api/v1/employees/${ids.testWorker}`, { daily_wage: 900, phone: '9111111111', default_shift: ids.dayA });
    expect(res.status).toBe(200);
    const fresh = await as(manager).get(`/api/v1/employees/${ids.testWorker}`);
    expect(fresh.body.data).toMatchObject({ daily_wage: 900, phone: '9111111111', shift_type: 'DAY' });
    const cleared = await as(manager).put(`/api/v1/employees/${ids.testWorker}`, { default_shift: 'unassigned' });
    expect(cleared.body.data.shift_type).toBe('UNASSIGNED');
  });

  it('rejects unknown shifts and foreign-tenant IDs instead of silently defaulting', async () => {
    expect((await as(admin).post('/api/v1/employees', { first_name: 'X', default_shift: 'evening' })).status).toBe(400);
    expect((await as(admin).post('/api/v1/employees', { first_name: 'X', default_shift_id: ids.nightB })).status).toBe(400);
    expect((await as(admin).post('/api/v1/employees', { first_name: 'X', branch_id: ids.branchB })).status).toBe(400);
    expect((await as(admin).post('/api/v1/employees', { first_name: 'X', manager_id: ids.foreignEmp })).status).toBe(400);
    expect((await as(foreignAdmin).get(`/api/v1/employees/${ids.testWorker}`)).status).toBe(404);
    expect((await as(foreignAdmin).put(`/api/v1/employees/${ids.testWorker}`, { phone: '1' })).status).toBe(404);
  });

  it('delete deactivates (history preserved) instead of hard-deleting', async () => {
    await prisma.attendance.create({ data: { organization_id: ids.orgA, employee_id: ids.testWorker, date: new Date(`${MONTH_START}T00:00:00Z`), status: 'PRESENT' } });
    const res = await as(admin).del(`/api/v1/employees/${ids.testWorker}`);
    expect(res.status).toBe(200);
    expect(await prisma.employee.findUnique({ where: { id: ids.testWorker } })).not.toBeNull();
    expect(await prisma.attendance.count({ where: { employee_id: ids.testWorker } })).toBe(1);
    const active = await as(admin).get('/api/v1/employees');
    expect(active.body.data.some((e: any) => e.id === ids.testWorker)).toBe(false);
    const all = await as(admin).get('/api/v1/employees?status=all');
    expect(all.body.data.find((e: any) => e.id === ids.testWorker).status).toBe('INACTIVE');
  });
});

describe('Attendance', () => {
  it('a WORKER cannot mark attendance for anyone or read org-wide attendance/dashboard', async () => {
    expect((await as(worker).post('/api/v1/attendance/mark', { employee_id: ids.managerEmp, date: TODAY, status: 'ABSENT' })).status).toBe(403);
    expect((await as(worker).get(`/api/v1/attendance/date/${TODAY}`)).status).toBe(403);
    expect((await as(worker).get('/api/v1/dashboard/summary')).status).toBe(403);
  });

  it('rejects the employee CODE where a UUID is required', async () => {
    const res = await as(manager).post('/api/v1/attendance/mark', { employee_id: 'W-1001', date: TODAY, status: 'PRESENT' });
    expect(res.status).toBe(400);
    expect(res.body.error).toContain('UUID');
  });

  it('marking uses the employee\'s persisted shift, persists, and is filtered by date', async () => {
    const res = await as(manager).post('/api/v1/attendance/mark', { employee_id: ids.workerEmp, date: MONTH_START, status: 'HALF_DAY' });
    expect(res.status).toBe(200);
    expect(res.body.data.shift_id).toBe(ids.nightA);
    const sameDay = await as(manager).get(`/api/v1/attendance/date/${MONTH_START}`);
    expect(sameDay.body.data.find((a: any) => a.employee_id === ids.workerEmp).status).toBe('HALF_DAY');
    const bulk = await as(manager).post('/api/v1/attendance/mark-bulk', { date: MONTH_START, entries: [{ employee_id: ids.workerEmp, status: 'PRESENT' }] });
    expect(bulk.status).toBe(200);
    expect((await prisma.attendance.findUnique({ where: { employee_id_date: { employee_id: ids.workerEmp, date: new Date(`${MONTH_START}T00:00:00Z`) } } }))!.status).toBe('PRESENT');
  });

  it('worker check-in uses their own shift; a second check-in is rejected; check-out closes the session', async () => {
    const inRes = await as(worker).post('/api/v1/attendance/check-in');
    expect(inRes.status).toBe(200);
    expect(inRes.body.data.attendance.shift_id).toBe(ids.nightA);
    expect((await as(worker).post('/api/v1/attendance/check-in')).status).toBe(400);
    const today = await as(worker).get('/api/v1/attendance/today');
    expect(today.body.open_session).toBe(true);
    const outRes = await as(worker).post('/api/v1/attendance/check-out');
    expect(outRes.status).toBe(200);
    expect((await as(worker).post('/api/v1/attendance/check-out')).status).toBe(400);
    expect((await as(worker).get('/api/v1/attendance/today')).body.open_session).toBe(false);
  });

  it('concurrent check-ins create exactly one open session', async () => {
    const results = await Promise.all([1, 2, 3].map(() => as(worker).post('/api/v1/attendance/check-in')));
    expect(results.filter(r => r.status === 200)).toHaveLength(1);
    const att = await prisma.attendance.findMany({ where: { employee_id: ids.workerEmp }, include: { sessions: true } });
    expect(att.flatMap(a => a.sessions).filter(s => !s.check_out_time)).toHaveLength(1);
    await as(worker).post('/api/v1/attendance/check-out');
  });
});

describe('Leave workflow', () => {
  it('only the assigned approver may decide; approval synchronises request, step, action and balance', async () => {
    const y = TODAY.slice(0, 4);
    const req = await as(worker).post('/api/v1/leaves/requests', { leave_type_id: ids.leaveType, start_date: `${y}-12-01`, end_date: `${y}-12-02`, reason: 'family' });
    expect(req.status).toBe(200);
    const id = req.body.data.id;

    expect((await as(otherManager).post(`/api/v1/leaves/requests/${id}/approve`)).status).toBe(403); // has permission, not the step
    expect((await as(foreignAdmin).post(`/api/v1/leaves/requests/${id}/approve`)).status).toBe(404); // cross-tenant

    const results = await Promise.all([as(manager).post(`/api/v1/leaves/requests/${id}/approve`), as(manager).post(`/api/v1/leaves/requests/${id}/approve`)]);
    expect(results.filter(r => r.status === 200)).toHaveLength(1);

    const lr = await prisma.leaveRequest.findUnique({ where: { id }, include: { approvalRequest: { include: { steps: true, actions: true } } } });
    expect(lr!.status).toBe('APPROVED');
    expect(lr!.approvalRequest!.status).toBe('APPROVED');
    expect(lr!.approvalRequest!.steps.map(s => s.status)).toEqual(['APPROVED']);
    expect(lr!.approvalRequest!.actions).toHaveLength(1);
    const bal = await prisma.leaveBalance.findFirst({ where: { employee_id: ids.workerEmp } });
    expect(bal!.remaining_balance).toBe(8); // deducted exactly once
  });

  it('a worker cannot read another employee\'s leave balance', async () => {
    expect((await as(worker).get(`/api/v1/leaves/balances?employee_id=${ids.managerEmp}`)).status).toBe(403);
  });
});

describe('Advances (loans)', () => {
  it('request persists amount + reason; server enforces the maximum', async () => {
    expect((await as(worker).post('/api/v1/loans/request', { amount: 999999 })).status).toBe(400);
    const res = await as(worker).post('/api/v1/loans/request', { amount: 3000, reason: 'Medical' });
    expect(res.status).toBe(200);
    ids.loan = res.body.data.id;
    expect(res.body.data).toMatchObject({ status: 'PENDING', reason: 'Medical', amount: 3000 });
    expect((await as(worker).post('/api/v1/loans/request', { amount: 100 })).status).toBe(409); // one pending at a time
  });

  it('approval is synchronised with ApprovalRequest/Step/Action; repeat approval fails', async () => {
    expect((await as(otherManager).post(`/api/v1/loans/${ids.loan}/approve`)).status).toBe(403);
    expect((await as(manager).post(`/api/v1/loans/${ids.loan}/approve`)).status).toBe(200);
    expect((await as(manager).post(`/api/v1/loans/${ids.loan}/approve`)).status).toBe(400);
    expect((await as(manager).post(`/api/v1/loans/${ids.loan}/reject`)).status).toBe(400);
    const ar = await prisma.approvalRequest.findFirst({ where: { entity_type: 'Loan', entity_id: ids.loan }, include: { steps: true, actions: true } });
    expect(ar!.status).toBe('APPROVED');
    expect(ar!.steps.map(s => s.status)).toEqual(['APPROVED']);
    expect(ar!.actions.map(a => a.action)).toEqual(['APPROVED']);
    expect((await prisma.loan.findUnique({ where: { id: ids.loan } }))!.status).toBe('ACTIVE');
  });
});

describe('Payroll integrity', () => {
  it('rejects a payroll period from another tenant', async () => {
    expect((await as(admin).post('/api/v1/payroll/runs', { payroll_period_id: ids.foreignPeriod })).status).toBe(404);
  });

  it('rejects a salary structure using another tenant\'s component', async () => {
    const res = await as(admin).post('/api/v1/salary/structures', { employee_id: ids.workerEmp, wage_basis: 'DAILY', items: [{ component_id: ids.foreignComponent, amount: 1 }] });
    expect(res.status).toBe(400);
  });

  it('calculate is idempotent, concurrency-safe, caps TOTAL multi-loan recovery, and FINALIZED is immutable', async () => {
    // Second loan so the multi-loan cap is exercised (first: ₹3000 approved above).
    await prisma.loan.create({ data: { organization_id: ids.orgA, employee_id: ids.workerEmp, amount: 3000, remaining_balance: 3000, status: 'ACTIVE', disbursed_date: new Date(`${MONTH_START}T00:00:00Z`) } });
    const [y, m] = TODAY.split('-').map(Number);
    const end = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
    const run = await as(admin).post('/api/v1/payroll/runs', { start_date: MONTH_START, end_date: end });
    expect(run.status).toBe(200);
    const runId = run.body.data.id;

    const snapshot = async () => {
      const items = await prisma.payrollItem.findMany({ where: { payroll_run_id: runId } });
      const itemIds = items.map(i => i.id);
      return {
        items: items.length,
        components: await prisma.payrollItemComponent.count({ where: { payroll_item_id: { in: itemIds } } }),
        repayments: await prisma.loanRepayment.count({ where: { payroll_item_id: { in: itemIds } } }),
        gross: items.reduce((s, i) => s + i.gross_earnings, 0),
        deductions: items.reduce((s, i) => s + i.total_deductions, 0),
        net: items.reduce((s, i) => s + i.net_pay, 0),
        outstanding: (await prisma.loan.findMany({ where: { employee_id: ids.workerEmp }, orderBy: { id: 'asc' } })).map(l => l.remaining_balance),
      };
    };

    const first = await as(admin).post(`/api/v1/payroll/runs/${runId}/calculate`);
    expect(first.status).toBe(200);
    const s1 = await snapshot();

    const workerItem = await prisma.payrollItem.findFirst({ where: { payroll_run_id: runId, employee_id: ids.workerEmp }, include: { loanRepayments: true } });
    const recovered = workerItem!.loanRepayments.reduce((s, r) => s + r.amount, 0);
    expect(recovered).toBeLessThanOrEqual(Math.round(workerItem!.gross_earnings * 0.10 * 100) / 100 + 0.001); // TOTAL cap across both loans

    expect((await as(admin).post(`/api/v1/payroll/runs/${runId}/calculate`)).status).toBe(200);
    expect(await snapshot()).toEqual(s1);

    const concurrent = await Promise.all([1, 2, 3].map(() => as(admin).post(`/api/v1/payroll/runs/${runId}/calculate`)));
    expect(concurrent.filter(r => r.status === 200).length).toBeGreaterThanOrEqual(1);
    expect(concurrent.every(r => r.status === 200 || r.status === 409)).toBe(true);
    expect(await snapshot()).toEqual(s1);

    expect((await as(admin).post(`/api/v1/payroll/runs/${runId}/finalize`)).status).toBe(200);
    expect((await as(admin).post(`/api/v1/payroll/runs/${runId}/calculate`)).status).toBe(400);
    expect((await as(manager).post('/api/v1/attendance/mark', { employee_id: ids.workerEmp, date: MONTH_START, status: 'ABSENT' })).status).toBe(400);
    expect(await snapshot()).toEqual(s1);
  });
});

describe('Dashboard', () => {
  it('groups by persisted shift (never inferred from attendance) and reports unassigned', async () => {
    const res = await as(admin).get(`/api/v1/dashboard/summary?date=${TODAY}`);
    expect(res.status).toBe(200);
    // Active: admin (no shift), manager (no shift), manager2 (no shift), worker (Night)
    expect(res.body.night.total).toBe(1);
    expect(res.body.day.total).toBe(0);
    expect(res.body.unassigned.total).toBe(3);
    expect(res.body.total.total).toBe(4);
    expect(typeof res.body.pending.total).toBe('number');
  });

  it('empty org returns zeros and null rates — never NaN', async () => {
    await prisma.employment.updateMany({ where: { employee: { organization_id: ids.orgA } }, data: { status: 'INACTIVE' } });
    const res = await as(admin).get(`/api/v1/dashboard/summary?date=${TODAY}`);
    expect(res.body.total).toMatchObject({ total: 0, attendance_rate: null });
    expect(JSON.stringify(res.body)).not.toContain('NaN');
    const comp = await as(admin).get('/api/v1/dashboard/compliance');
    expect(comp.body).toMatchObject({ total: 0, uan_coverage: null, esi_coverage: null });
  });
});
