import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { auditLog } from '../middleware/audit.middleware';
import { AttendanceService, isDateInFinalizedPayroll } from '../services/attendance.service';
import { recordDecision } from '../services/approval.service';
import { openApproval } from '../services/approval.service';
import {
  sendError, badRequest, notFound, conflict, parseDateOnly, todayIST, addDaysUTC, isUuid, optionalString, toDateKey
} from '../utils/http';
import {
  getSelfEmployee, getScopedBranchIds, branchScopeWhere, getEmployeeInScope, hasPermission, isSuperAdmin
} from '../utils/access';
import { ACTIVE_EMPLOYMENT_STATUSES, classifyShift } from '../services/employee.service';

const router = Router();

const MARKABLE_STATUSES = ['PRESENT', 'ABSENT', 'HALF_DAY'];
const shiftSelect = { select: { id: true, name: true, start_time: true, end_time: true } };

function withShiftType(att: any) {
  if (!att) return att;
  return { ...att, shift: att.shift ? { ...att.shift, type: classifyShift(att.shift) } : null };
}

async function requireActiveSelfEmployee(userId: string, orgId: string) {
  const employee = await prisma.employee.findFirst({
    where: { user_id: userId, organization_id: orgId },
    include: { employment: true }
  });
  if (!employee) throw notFound('No employee profile is linked to your account');
  if (!employee.employment || !ACTIVE_EMPLOYMENT_STATUSES.includes(employee.employment.status)) {
    throw badRequest('Your employment is not active');
  }
  return employee;
}

/** Attendance row (today or yesterday — night shifts) that still has an open session. */
async function findOpenAttendance(tx: any, employeeId: string) {
  const today = todayIST();
  return tx.attendance.findFirst({
    where: {
      employee_id: employeeId,
      date: { gte: addDaysUTC(today, -1), lte: today },
      sessions: { some: { check_out_time: null } }
    },
    orderBy: { date: 'desc' }
  });
}

async function lockAttendanceRow(tx: any, attendanceId: string) {
  await tx.$queryRaw`SELECT id FROM "Attendance" WHERE id = ${attendanceId}::uuid FOR UPDATE`;
}

// ---------------------------------------------------------
// SELF-SERVICE (worker)
// ---------------------------------------------------------

// GET /attendance/today — the caller's own current attendance state.
router.get('/today', async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employee = await getSelfEmployee(req.authContext!.userId, orgId);
    if (!employee) return res.json({ data: null, open_session: false, employee_linked: false });

    const open = await findOpenAttendance(prisma, employee.id);
    const today = todayIST();
    const attendance = await prisma.attendance.findFirst({
      where: open ? { id: open.id } : { employee_id: employee.id, date: today },
      include: { sessions: { orderBy: { check_in_time: 'asc' } }, shift: shiftSelect }
    });
    res.json({ data: withShiftType(attendance), open_session: !!open, employee_linked: true });
  } catch (error) {
    sendError(res, error, "Load today's attendance");
  }
});

router.post('/check-in', requirePermission('attendance:create'), auditLog('CREATE', 'AttendanceSession'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employee = await requireActiveSelfEmployee(req.authContext!.userId, orgId);
    const today = todayIST();
    if (await isDateInFinalizedPayroll(orgId, today)) {
      throw badRequest('Attendance for today is inside a finalized payroll period');
    }
    const now = new Date();

    const result = await prisma.$transaction(async (tx: any) => {
      const open = await findOpenAttendance(tx, employee.id);
      if (open) throw conflict('You are already checked in');

      // Race-safe create-if-missing: ON CONFLICT avoids aborting the transaction
      // when two check-ins arrive at once; the row lock then serialises them.
      await tx.$executeRaw`
        INSERT INTO "Attendance" (id, organization_id, employee_id, shift_id, date, status, total_worked_mins, is_late, is_early_departure, first_check_in, created_at, updated_at)
        VALUES (gen_random_uuid(), ${orgId}::uuid, ${employee.id}::uuid, ${employee.default_shift_id}::uuid, ${toDateKey(today)}::date, 'PRESENT', 0, false, false, ${now}, now(), now())
        ON CONFLICT (employee_id, date) DO NOTHING`;

      const attendance = await tx.attendance.findUnique({ where: { employee_id_date: { employee_id: employee.id, date: today } } });
      await lockAttendanceRow(tx, attendance.id);

      const stillOpen = await tx.attendanceSession.findFirst({ where: { attendance_id: attendance.id, check_out_time: null } });
      if (stillOpen) throw conflict('You are already checked in');

      await tx.attendance.update({
        where: { id: attendance.id },
        data: {
          first_check_in: attendance.first_check_in ?? now,
          // The worker's own persisted shift — never "the first shift in the org".
          shift_id: attendance.shift_id ?? employee.default_shift_id,
          status: attendance.status === 'ABSENT' ? 'PRESENT' : attendance.status,
        }
      });
      const session = await tx.attendanceSession.create({ data: { attendance_id: attendance.id, check_in_time: now } });
      const fresh = await tx.attendance.findUnique({ where: { id: attendance.id }, include: { sessions: true, shift: shiftSelect } });
      return { attendance: withShiftType(fresh), session };
    });

    res.json({ data: result });
  } catch (error: any) {
    // Business-rule rejections keep the historical 400 contract.
    if (error?.status === 409) return res.status(400).json({ error: error.message });
    sendError(res, error, 'Check in');
  }
});

router.post('/check-out', requirePermission('attendance:create'), auditLog('UPDATE', 'AttendanceSession'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employee = await requireActiveSelfEmployee(req.authContext!.userId, orgId);
    const now = new Date();

    const result = await prisma.$transaction(async (tx: any) => {
      // May be yesterday's record for a night shift that ends after midnight.
      const attendance = await findOpenAttendance(tx, employee.id);
      if (!attendance) throw badRequest('No active check-in found to check out from');
      await lockAttendanceRow(tx, attendance.id);

      const openSession = await tx.attendanceSession.findFirst({ where: { attendance_id: attendance.id, check_out_time: null } });
      if (!openSession) throw badRequest('No active check-in found to check out from');
      if (await isDateInFinalizedPayroll(orgId, attendance.date, tx)) {
        throw badRequest('This attendance date is inside a finalized payroll period');
      }

      const session = await tx.attendanceSession.update({
        where: { id: openSession.id },
        data: { check_out_time: now, duration_mins: AttendanceService.getDurationMins(new Date(openSession.check_in_time), now) }
      });
      await tx.attendance.update({ where: { id: attendance.id }, data: { last_check_out: now } });
      await AttendanceService.recalculateAttendance(attendance.id, tx);
      const fresh = await tx.attendance.findUnique({ where: { id: attendance.id }, include: { sessions: true, shift: shiftSelect } });
      return { session, attendance: withShiftType(fresh) };
    });

    res.json({ data: result });
  } catch (error) {
    sendError(res, error, 'Check out');
  }
});

// ---------------------------------------------------------
// HISTORY — own records, or another employee's with attendance:manage
// GET /attendance/history?employee_id=<uuid>&month=YYYY-MM
// ---------------------------------------------------------
router.get('/history', requirePermission('attendance:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const selfEmp = await getSelfEmployee(userId, orgId);
    const requested = req.query.employee_id as string | undefined;

    let targetEmployeeId: string | undefined;
    if (requested && requested !== selfEmp?.id) {
      if (!(await hasPermission(userId, orgId, 'attendance:manage'))) {
        return res.status(403).json({ error: "Forbidden: Cannot view another employee's attendance" });
      }
      if (!isUuid(requested)) throw notFound('Employee not found in your organization');
      targetEmployeeId = (await getEmployeeInScope(userId, orgId, requested)).id;
    } else {
      targetEmployeeId = selfEmp?.id;
    }
    if (!targetEmployeeId) return res.json({ data: [] });

    const where: any = { organization_id: orgId, employee_id: targetEmployeeId };
    const month = req.query.month as string | undefined;
    if (month) {
      if (!/^\d{4}-\d{2}$/.test(month)) throw badRequest('month must be YYYY-MM');
      const start = parseDateOnly(`${month}-01`, 'month');
      const end = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 0));
      where.date = { gte: start, lte: end };
    }

    const attendances = await prisma.attendance.findMany({
      where,
      include: { sessions: { orderBy: { check_in_time: 'asc' } }, shift: shiftSelect },
      orderBy: { date: 'desc' },
      take: month ? 31 : 30
    });
    res.json({ data: attendances.map(withShiftType) });
  } catch (error) {
    sendError(res, error, 'Attendance history');
  }
});

// ---------------------------------------------------------
// MANAGER MARKING — requires attendance:manage (workers hold attendance:create
// for their own check-in only and must NOT be able to mark other employees).
// ---------------------------------------------------------

async function markOne(tx: any, orgId: string, userId: string, entry: { employee_id: unknown; status: unknown; shift_id?: unknown }, date: Date) {
  if (!isUuid(entry.employee_id)) {
    // Guard against the old contract bug of sending the display code (e.g. "W-1001").
    throw badRequest('employee_id must be the employee UUID (not the employee code)');
  }
  const status = String(entry.status || '').toUpperCase();
  if (!MARKABLE_STATUSES.includes(status)) throw badRequest(`status must be one of ${MARKABLE_STATUSES.join(', ')}`);

  const emp = await getEmployeeInScope(userId, orgId, entry.employee_id as string);
  if (emp.employment && !ACTIVE_EMPLOYMENT_STATUSES.includes(emp.employment.status)) {
    throw badRequest(`${emp.first_name} ${emp.last_name} is not an active employee`);
  }

  let shiftId: string | null | undefined;
  if (entry.shift_id !== undefined && entry.shift_id !== null && entry.shift_id !== '') {
    if (!isUuid(entry.shift_id)) throw badRequest('shift_id must be a shift UUID');
    const shift = await tx.shift.findFirst({ where: { id: entry.shift_id as string, organization_id: orgId } });
    if (!shift) throw badRequest('Shift not found in your organization');
    shiftId = shift.id;
  }

  const existing = await tx.attendance.findUnique({ where: { employee_id_date: { employee_id: emp.id, date } } });
  if (existing) {
    return tx.attendance.update({
      where: { id: existing.id },
      data: { status, shift_id: shiftId !== undefined ? shiftId : (existing.shift_id ?? emp.default_shift_id) },
      include: { shift: shiftSelect }
    });
  }
  return tx.attendance.create({
    data: {
      organization_id: orgId,
      employee_id: emp.id,
      date,
      status,
      shift_id: shiftId !== undefined ? shiftId : emp.default_shift_id, // employee's persisted shift, or none
    },
    include: { shift: shiftSelect }
  });
}

function parseMarkDate(v: unknown): Date {
  const date = parseDateOnly(v, 'date');
  if (date.getTime() > todayIST().getTime()) throw badRequest('Attendance cannot be marked for a future date');
  return date;
}

router.post('/mark', requirePermission('attendance:manage'), auditLog('UPDATE', 'Attendance'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const date = parseMarkDate(req.body?.date);
    if (await isDateInFinalizedPayroll(orgId, date)) {
      return res.status(400).json({ error: 'Cannot mark attendance for dates within a finalized payroll period.' });
    }
    const attendance = await prisma.$transaction((tx: any) => markOne(tx, orgId, req.authContext!.userId, req.body || {}, date));
    res.json({ data: withShiftType(attendance) });
  } catch (error) {
    sendError(res, error, 'Mark attendance');
  }
});

// POST /attendance/mark-bulk { date, entries: [{ employee_id, status, shift_id? }] }
// All-or-nothing: either every entry is saved or none is.
router.post('/mark-bulk', requirePermission('attendance:manage'), auditLog('UPDATE', 'Attendance'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const date = parseMarkDate(req.body?.date);
    const entries = req.body?.entries;
    if (!Array.isArray(entries) || entries.length === 0) throw badRequest('entries must be a non-empty array');
    if (entries.length > 1000) throw badRequest('Too many entries in one request (max 1000)');
    const ids = entries.map((e: any) => e?.employee_id);
    if (new Set(ids).size !== ids.length) throw badRequest('Each employee may appear only once');
    if (await isDateInFinalizedPayroll(orgId, date)) {
      return res.status(400).json({ error: 'Cannot mark attendance for dates within a finalized payroll period.' });
    }

    const saved = await prisma.$transaction(async (tx: any) => {
      const out: any[] = [];
      for (const e of entries) out.push(await markOne(tx, orgId, req.authContext!.userId, e || {}, date));
      return out;
    }, { timeout: 30000 });
    res.json({ data: saved.map(withShiftType), meta: { saved: saved.length } });
  } catch (error) {
    sendError(res, error, 'Bulk mark attendance');
  }
});

// GET /attendance/date/:date — all attendance in the caller's scope for one date.
router.get('/date/:date', requirePermission('attendance:manage'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const date = parseDateOnly(String(req.params.date), 'date');
    const branchIds = await getScopedBranchIds(req.authContext!.userId, orgId);
    const attendances = await prisma.attendance.findMany({
      where: { organization_id: orgId, date, employee: branchScopeWhere(branchIds) },
      include: { shift: shiftSelect, sessions: { select: { id: true, check_in_time: true, check_out_time: true } } }
    });
    res.json({ data: attendances.map(withShiftType) });
  } catch (error) {
    sendError(res, error, 'Attendance by date');
  }
});

// ---------------------------------------------------------
// CORRECTIONS
// ---------------------------------------------------------

router.post('/corrections', requirePermission('attendance:correction:create'), auditLog('CREATE', 'AttendanceCorrection'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employee = await getSelfEmployee(req.authContext!.userId, orgId);
    if (!employee) return res.status(404).json({ error: 'Employee not found' });

    const { attendance_id, requested_status, requested_check_in, requested_check_out } = req.body || {};
    const reason = optionalString(req.body?.reason, 'reason', 2000);
    if (!reason) throw badRequest('reason is required');
    if (!isUuid(attendance_id)) throw notFound('Attendance record not found');
    const status = String(requested_status || '').toUpperCase();
    if (!MARKABLE_STATUSES.includes(status)) throw badRequest(`requested_status must be one of ${MARKABLE_STATUSES.join(', ')}`);

    // Workers may only correct their own attendance.
    const att = await prisma.attendance.findFirst({ where: { id: attendance_id, organization_id: orgId, employee_id: employee.id } });
    if (!att) return res.status(404).json({ error: 'Attendance record not found' });

    if (await isDateInFinalizedPayroll(orgId, att.date)) {
      return res.status(400).json({ error: 'Attendance corrections cannot be submitted for dates within a finalized payroll period.' });
    }

    const checkIn = requested_check_in ? new Date(requested_check_in) : null;
    const checkOut = requested_check_out ? new Date(requested_check_out) : null;
    if ((checkIn && isNaN(checkIn.getTime())) || (checkOut && isNaN(checkOut.getTime()))) throw badRequest('Invalid check-in/check-out time');
    if (checkIn && checkOut && checkOut <= checkIn) throw badRequest('Check-out must be after check-in');

    const result = await prisma.$transaction(async (tx: any) => {
      const correction = await tx.attendanceCorrection.create({
        data: {
          attendance_id, requested_by_user_id: employee.id, requested_status: status,
          requested_check_in: checkIn, requested_check_out: checkOut, reason
        }
      });
      const approval = await openApproval(tx, { orgId, requesterEmployeeId: employee.id, entityType: 'AttendanceCorrection', entityId: correction.id });
      return tx.attendanceCorrection.update({ where: { id: correction.id }, data: { approval_request_id: approval.id } });
    });
    res.json({ data: result });
  } catch (error) {
    sendError(res, error, 'Create attendance correction');
  }
});

async function decideCorrection(req: Request, res: Response, decision: 'APPROVED' | 'REJECTED') {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const correctionId = String(req.params.id);
    if (!isUuid(correctionId)) throw notFound('Correction not found');

    const correction = await prisma.attendanceCorrection.findFirst({
      where: { id: correctionId, attendance: { organization_id: orgId } },
      include: { attendance: true }
    });
    if (!correction) return res.status(404).json({ error: 'Correction not found' });
    if (correction.status !== 'PENDING') return res.status(400).json({ error: 'Correction already processed' });
    if (decision === 'APPROVED' && await isDateInFinalizedPayroll(orgId, correction.attendance.date)) {
      return res.status(400).json({ error: 'Cannot approve corrections for dates within a finalized payroll period.' });
    }

    const actor = await getSelfEmployee(userId, orgId);
    const superAdmin = await isSuperAdmin(userId, orgId);

    await prisma.$transaction(async (tx: any) => {
      const claimed = await tx.attendanceCorrection.updateMany({ where: { id: correction.id, status: 'PENDING' }, data: { status: decision } });
      if (claimed.count !== 1) throw conflict('Correction already processed');

      await recordDecision(tx, {
        orgId, approvalRequestId: correction.approval_request_id, entityType: 'AttendanceCorrection', entityId: correction.id,
        requesterEmployeeId: correction.requested_by_user_id, actorEmployeeId: actor?.id ?? null, actorIsSuperAdmin: superAdmin, decision
      });

      if (decision === 'APPROVED') {
        let totalWorkedMins: number | undefined;
        if (correction.requested_check_in && correction.requested_check_out) {
          totalWorkedMins = Math.floor((new Date(correction.requested_check_out).getTime() - new Date(correction.requested_check_in).getTime()) / 60000);
        }
        await tx.attendance.update({
          where: { id: correction.attendance_id },
          data: {
            status: correction.requested_status,
            ...(correction.requested_check_in ? { first_check_in: correction.requested_check_in } : {}),
            ...(correction.requested_check_out ? { last_check_out: correction.requested_check_out } : {}),
            ...(totalWorkedMins !== undefined ? { total_worked_mins: totalWorkedMins } : {})
          }
        });
      }
    });

    res.json({ message: decision === 'APPROVED' ? 'Correction approved and applied' : 'Correction rejected' });
  } catch (error) {
    sendError(res, error, 'Decide attendance correction');
  }
}

router.post('/corrections/:id/approve', requirePermission('attendance:correction:approve'), auditLog('UPDATE', 'AttendanceCorrection'),
  (req: Request, res: Response) => decideCorrection(req, res, 'APPROVED'));
router.post('/corrections/:id/reject', requirePermission('attendance:correction:approve'), auditLog('UPDATE', 'AttendanceCorrection'),
  (req: Request, res: Response) => decideCorrection(req, res, 'REJECTED'));

router.get('/corrections', requirePermission('attendance:correction:view'), async (req: Request, res: Response) => {
  try {
    const corrections = await prisma.attendanceCorrection.findMany({
      where: { attendance: { organization_id: req.authContext!.organizationId } },
      include: { attendance: true, requestedBy: { select: { id: true, emp_id: true, first_name: true, last_name: true } } },
      orderBy: { created_at: 'desc' }
    });
    res.json(corrections);
  } catch (error) {
    sendError(res, error, 'List corrections');
  }
});

export default router;
