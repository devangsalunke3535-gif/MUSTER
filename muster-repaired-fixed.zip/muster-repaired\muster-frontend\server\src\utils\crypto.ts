import crypto from 'crypto';

// The key comes from config/env, which refuses to start in production when it is
// missing, a known placeholder, or not exactly 32 bytes.
//
// MIGRATION NOTE: changing ENCRYPTION_KEY on a system with existing data makes
// every encrypted record (bank accounts, PAN, Aadhaar, UAN...) undecryptable.
// Run a re-encryption migration before rotating the key.
import { ENCRYPTION_KEY } from '../config/env';

const ALGORITHM = 'aes-256-gcm';

export function encrypt(text: string): string {
  if (!text) return text;
  
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, Buffer.from(ENCRYPTION_KEY), iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag();
  
  return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
}

export function decrypt(hash: string): string {
  if (!hash) return hash;
  
  const parts = hash.split(':');
  if (parts.length !== 3) return hash;
  
  const iv = Buffer.from(parts[0], 'hex');
  const authTag = Buffer.from(parts[1], 'hex');
  const encryptedText = Buffer.from(parts[2], 'hex');
  
  const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(ENCRYPTION_KEY), iv);
  decipher.setAuthTag(authTag);
  
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  
  return decrypted.toString('utf8');
}

export function maskData(text: string, visibleChars: number = 4): string {
  if (!text) return text;
  if (text.length <= visibleChars) return text;
  
  const masked = '*'.repeat(text.length - visibleChars);
  const visible = text.slice(-visibleChars);
  return `${masked}${visible}`;
}
