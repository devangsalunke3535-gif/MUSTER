import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { auditLog } from '../middleware/audit.middleware';
import { LeaveService } from '../services/leave.service';
import { openApproval, recordDecision, cancelApproval, Decision } from '../services/approval.service';
import { sendError, badRequest, notFound, conflict, parseDateOnly, parsePositiveNumber, optionalString, isUuid } from '../utils/http';
import { getSelfEmployee, hasPermission, isSuperAdmin, getScopedBranchIds, branchScopeWhere, getEmployeeInScope } from '../utils/access';

const router = Router();

// ---------------------------------------------------------
// LEAVE TYPES
// ---------------------------------------------------------

router.get('/types', requirePermission('leave_type:view'), async (req: Request, res: Response) => {
  try {
    const types = await prisma.leaveType.findMany({
      where: { organization_id: req.authContext!.organizationId },
      orderBy: { name: 'asc' }
    });
    res.json({ data: types });
  } catch (error) {
    sendError(res, error, 'List leave types');
  }
});

router.post('/types', requirePermission('leave_type:create'), auditLog('CREATE', 'LeaveType'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const name = optionalString(req.body?.name, 'name', 100);
    const code = optionalString(req.body?.code, 'code', 50);
    if (!name || !code) throw badRequest('name and code are required');
    const leaveType = await prisma.leaveType.create({
      data: {
        organization_id: orgId,
        name,
        code: code.toUpperCase(),
        is_paid: req.body?.is_paid ?? true,
        annual_quota: req.body?.annual_quota ? parsePositiveNumber(req.body.annual_quota, 'annual_quota', { allowZero: true }) : 0,
        is_active: req.body?.is_active ?? true
      }
    });
    res.json({ data: leaveType });
  } catch (error) {
    sendError(res, error, 'Create leave type');
  }
});

// ---------------------------------------------------------
// LEAVE BALANCES
// Own balances by default; another employee's requires leave:manage.
// ---------------------------------------------------------

router.get('/balances', requirePermission('leave:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const self = await getSelfEmployee(userId, orgId);
    const requested = req.query.employee_id as string | undefined;

    let employeeId: string | undefined;
    if (requested && requested !== self?.id) {
      if (!(await hasPermission(userId, orgId, 'leave:manage'))) {
        return res.status(403).json({ error: "Forbidden: Cannot view another employee's leave balance" });
      }
      if (!isUuid(requested)) throw notFound('Employee not found');
      employeeId = (await getEmployeeInScope(userId, orgId, requested)).id;
    } else {
      employeeId = self?.id;
    }
    if (!employeeId) return res.json({ data: [] });

    const where: any = { employee_id: employeeId, employee: { organization_id: orgId } };
    if (req.query.year) where.leave_year = parseInt(req.query.year as string, 10);

    const balances = await prisma.leaveBalance.findMany({
      where, include: { leaveType: true }, orderBy: [{ leave_year: 'desc' }]
    });
    res.json({ data: balances });
  } catch (error) {
    sendError(res, error, 'Leave balances');
  }
});

router.post('/balances/allocate', requirePermission('leave:manage'), auditLog('UPDATE', 'LeaveBalance'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const { employee_id, leave_type_id } = req.body || {};
    const year = parseInt(req.body?.year, 10);
    if (!Number.isInteger(year) || year < 2000 || year > 2100) throw badRequest('year must be a valid year');
    const allocated = parsePositiveNumber(req.body?.allocated_balance, 'allocated_balance', { allowZero: true, max: 366 });
    if (!isUuid(employee_id) || !isUuid(leave_type_id)) throw badRequest('employee_id and leave_type_id must be UUIDs');

    await getEmployeeInScope(req.authContext!.userId, orgId, employee_id);
    const type = await prisma.leaveType.findFirst({ where: { id: leave_type_id, organization_id: orgId } });
    if (!type) throw badRequest('Leave type not found in organization');

    const balance = await prisma.$transaction(async (tx: any) => {
      const existing = await tx.leaveBalance.findUnique({
        where: { employee_id_leave_type_id_leave_year: { employee_id, leave_type_id, leave_year: year } }
      });
      if (!existing) {
        return tx.leaveBalance.create({
          data: { employee_id, leave_type_id, leave_year: year, allocated_balance: allocated, remaining_balance: allocated }
        });
      }
      // Re-allocation applies only the delta so already-used days are preserved.
      const delta = allocated - existing.allocated_balance;
      if (existing.remaining_balance + delta < 0) throw badRequest('Allocation would make the remaining balance negative');
      return tx.leaveBalance.update({
        where: { id: existing.id },
        data: { allocated_balance: allocated, remaining_balance: { increment: delta } }
      });
    });
    res.json({ data: balance });
  } catch (error) {
    sendError(res, error, 'Allocate leave balance');
  }
});

// ---------------------------------------------------------
// LEAVE REQUESTS
// ---------------------------------------------------------

router.post('/requests', requirePermission('leave:create'), auditLog('CREATE', 'LeaveRequest'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employee = await getSelfEmployee(req.authContext!.userId, orgId);
    if (!employee) return res.status(404).json({ error: 'Employee not found' });

    const { leave_type_id } = req.body || {};
    const reason = optionalString(req.body?.reason, 'reason', 2000);
    if (!reason) throw badRequest('reason is required');
    if (!isUuid(leave_type_id)) return res.status(404).json({ error: 'Leave Type not found' });
    const leaveType = await prisma.leaveType.findFirst({ where: { id: leave_type_id, organization_id: orgId } });
    if (!leaveType) return res.status(404).json({ error: 'Leave Type not found' });
    if (!leaveType.is_active) throw badRequest('This leave type is inactive');

    const sDate = parseDateOnly(req.body?.start_date, 'start_date');
    const eDate = parseDateOnly(req.body?.end_date, 'end_date');
    if (sDate > eDate) throw badRequest('Start date cannot be after end date');
    if (sDate.getUTCFullYear() !== eDate.getUTCFullYear()) {
      throw badRequest('A leave request cannot span two calendar years; submit one request per year');
    }

    const assignment = await prisma.employeeAssignmentHistory.findFirst({ where: { employee_id: employee.id, effective_to: null } });
    const durationDays = await LeaveService.calculateDurationDays(orgId, sDate, eDate, prisma as any, assignment?.branch_id);
    if (durationDays <= 0) throw badRequest('Invalid leave duration');

    const year = sDate.getUTCFullYear();
    const result = await prisma.$transaction(async (tx: any) => {
      const overlap = await tx.leaveRequest.findFirst({
        where: {
          employee_id: employee.id,
          status: { in: ['PENDING', 'APPROVED'] },
          start_date: { lte: eDate },
          end_date: { gte: sDate }
        }
      });
      if (overlap) throw badRequest('You already have a pending or approved leave overlapping these dates');

      const balance = await tx.leaveBalance.findUnique({
        where: { employee_id_leave_type_id_leave_year: { employee_id: employee.id, leave_type_id, leave_year: year } }
      });
      if (!balance || balance.remaining_balance < durationDays) throw badRequest('Insufficient leave balance');

      const request = await tx.leaveRequest.create({
        data: { employee_id: employee.id, leave_type_id, start_date: sDate, end_date: eDate, duration_days: durationDays, reason, status: 'PENDING' }
      });
      const approval = await openApproval(tx, { orgId, requesterEmployeeId: employee.id, entityType: 'LeaveRequest', entityId: request.id });
      return tx.leaveRequest.update({ where: { id: request.id }, data: { approval_request_id: approval.id }, include: { leaveType: true } });
    });

    res.json({ data: result });
  } catch (error) {
    sendError(res, error, 'Create leave request');
  }
});

/**
 * Approve or reject. The PENDING → X transition is claimed with a conditional
 * UPDATE inside the transaction, so two concurrent approvals of the same
 * request cannot both succeed (and cannot both deduct balance). The leave
 * status, approval records and balance change commit together or not at all.
 */
async function decideLeave(req: Request, res: Response, decision: Decision) {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const requestId = String(req.params.id);
    if (!isUuid(requestId)) return res.status(404).json({ error: 'Leave Request not found' });

    const request = await prisma.leaveRequest.findFirst({
      where: { id: requestId, employee: { organization_id: orgId } },
      include: { employee: true }
    });
    if (!request) return res.status(404).json({ error: 'Leave Request not found' });
    if (request.status !== 'PENDING') return res.status(400).json({ error: 'Request is not pending' });

    const actor = await getSelfEmployee(userId, orgId);
    const superAdmin = await isSuperAdmin(userId, orgId);
    const comments = optionalString(req.body?.comments, 'comments', 2000) || null;

    await prisma.$transaction(async (tx: any) => {
      const claimed = await tx.leaveRequest.updateMany({ where: { id: request.id, status: 'PENDING' }, data: { status: decision } });
      if (claimed.count !== 1) throw conflict('Request is not pending');

      const approvalId = await recordDecision(tx, {
        orgId, approvalRequestId: request.approval_request_id, entityType: 'LeaveRequest', entityId: request.id,
        requesterEmployeeId: request.employee_id, actorEmployeeId: actor?.id ?? null, actorIsSuperAdmin: superAdmin,
        decision, comments
      });
      if (!request.approval_request_id) {
        await tx.leaveRequest.update({ where: { id: request.id }, data: { approval_request_id: approvalId } });
      }

      if (decision === 'APPROVED') {
        // Legacy/seeded rows may carry duration_days = 0; recompute rather than deduct nothing.
        let duration = request.duration_days;
        if (!(duration > 0)) {
          const a = await tx.employeeAssignmentHistory.findFirst({ where: { employee_id: request.employee_id, effective_to: null } });
          duration = await LeaveService.calculateDurationDays(orgId, request.start_date, request.end_date, tx, a?.branch_id);
          if (!(duration > 0)) throw badRequest('Leave request has no chargeable days');
          await tx.leaveRequest.update({ where: { id: request.id }, data: { duration_days: duration } });
        }
        await LeaveService.deductBalance(tx, request.employee_id, request.leave_type_id, new Date(request.start_date).getUTCFullYear(), duration);
      }
    });

    res.json({ message: decision === 'APPROVED' ? 'Leave request approved and balance deducted' : 'Leave request rejected' });
  } catch (error) {
    sendError(res, error, 'Decide leave request');
  }
}

router.post('/requests/:id/approve', requirePermission('leave:approve'), auditLog('UPDATE', 'LeaveRequest'),
  (req: Request, res: Response) => decideLeave(req, res, 'APPROVED'));
router.post('/requests/:id/reject', requirePermission('leave:approve'), auditLog('UPDATE', 'LeaveRequest'),
  (req: Request, res: Response) => decideLeave(req, res, 'REJECTED'));

router.post('/requests/:id/cancel', requirePermission('leave:cancel'), auditLog('UPDATE', 'LeaveRequest'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const emp = await getSelfEmployee(req.authContext!.userId, orgId);
    if (!emp) return res.status(403).json({ error: 'Employee profile missing' });
    const requestId = String(req.params.id);
    if (!isUuid(requestId)) return res.status(404).json({ error: 'Leave Request not found' });

    const request = await prisma.leaveRequest.findFirst({ where: { id: requestId, employee: { organization_id: orgId } } });
    if (!request) return res.status(404).json({ error: 'Leave Request not found' });
    if (request.employee_id !== emp.id) return res.status(403).json({ error: 'Only the requester can cancel their leave' });
    if (request.status === 'CANCELLED' || request.status === 'REJECTED') return res.status(400).json({ error: 'Leave already inactive' });

    await prisma.$transaction(async (tx: any) => {
      const claimed = await tx.leaveRequest.updateMany({
        where: { id: request.id, status: request.status }, data: { status: 'CANCELLED' }
      });
      if (claimed.count !== 1) throw conflict('Leave request changed; please refresh and try again');
      await cancelApproval(tx, orgId, request.approval_request_id);
      if (request.status === 'APPROVED') {
        await LeaveService.restoreBalance(tx, request.employee_id, request.leave_type_id, new Date(request.start_date).getUTCFullYear(), request.duration_days);
      }
    });
    res.json({ message: 'Leave cancelled successfully' });
  } catch (error) {
    sendError(res, error, 'Cancel leave request');
  }
});

router.get('/my-requests', requirePermission('leave:view'), async (req: Request, res: Response) => {
  try {
    const employee = await getSelfEmployee(req.authContext!.userId, req.authContext!.organizationId);
    if (!employee) return res.json({ data: [] });
    const requests = await prisma.leaveRequest.findMany({
      where: { employee_id: employee.id },
      include: { leaveType: true },
      orderBy: { created_at: 'desc' }
    });
    res.json({ data: requests });
  } catch (error) {
    sendError(res, error, 'My leave requests');
  }
});

// GET /leaves/requests?status=PENDING — for approvers, within their branch scope.
// Each row reports whether the caller can act on it (assigned step / super admin / no steps).
router.get('/requests', requirePermission('leave:approve'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const branchIds = await getScopedBranchIds(userId, orgId);
    const where: any = { employee: { organization_id: orgId, ...branchScopeWhere(branchIds) } };
    if (req.query.status) where.status = String(req.query.status).toUpperCase();

    const [requests, actor, superAdmin] = await Promise.all([
      prisma.leaveRequest.findMany({
        where,
        include: {
          leaveType: true,
          employee: { select: { id: true, emp_id: true, first_name: true, last_name: true } },
          approvalRequest: { include: { steps: true } }
        },
        orderBy: { created_at: 'desc' }
      }),
      getSelfEmployee(userId, orgId),
      isSuperAdmin(userId, orgId),
    ]);

    res.json({
      data: requests.map((r: any) => {
        const steps = r.approvalRequest?.steps || [];
        const assigned = steps.some((s: any) => s.status === 'PENDING' && s.approver_user_id === actor?.id);
        const can_decide = r.status === 'PENDING' && !!actor && r.employee_id !== actor.id && (superAdmin || steps.length === 0 || assigned);
        const { approvalRequest, ...rest } = r;
        return { ...rest, can_decide };
      })
    });
  } catch (error) {
    sendError(res, error, 'List leave requests');
  }
});

export default router;
