/**
 * Hard safety guard: the test suites DELETE every row in beforeAll. Refuse to
 * run unless DATABASE_URL points at a database whose name ends in "_test".
 * (The previous guard only rejected the literal substring "/muster?", which a
 * differently-named dev database, or a URL without "?schema", would slip past.)
 */
const url = process.env.DATABASE_URL || '';
let dbName = '';
try { dbName = new URL(url).pathname.replace(/^\//, ''); } catch { /* invalid URL */ }

if (!/_test$/.test(dbName)) {
  // eslint-disable-next-line no-console
  console.error(`\n⛔ SAFETY ABORT: tests must run against a database whose name ends in "_test" (got "${dbName || 'unparseable DATABASE_URL'}").\n` +
    '   Create it and point .env.test at it, e.g. postgresql://user@localhost:5432/muster_test?schema=public\n');
  process.exit(1);
}
if (process.env.NODE_ENV !== 'test') process.env.NODE_ENV = 'test';
