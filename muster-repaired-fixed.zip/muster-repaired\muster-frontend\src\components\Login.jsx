import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Eye, EyeOff, Lock, Mail, ArrowRight, Shield } from 'lucide-react';
import { useToast } from './Toast';

export default function Login() {
  const { login } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await login(email, password);
    if (!result.success) {
      setError(result.error);
    } else {
      // Navigate based on role
      navigate('/');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex font-sans">
      {/* Left Panel — Branding */}
      <div className="hidden lg:flex lg:w-[55%] bg-gradient-to-br from-primary-950 via-primary-900 to-slate-900 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-72 h-72 bg-primary-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary-400/8 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-violet-500/10 rounded-full blur-2xl" />
          {/* Grid pattern */}
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.03) 1px, transparent 0)',
            backgroundSize: '32px 32px'
          }} />
        </div>

        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center font-bold text-white text-lg border border-white/10">
              M
            </div>
            <span className="font-bold text-xl text-white tracking-tight">Muster</span>
            <span className="text-[10px] bg-primary-400/20 text-primary-300 px-2 py-0.5 rounded-full font-semibold border border-primary-400/20">PRO</span>
          </div>

          {/* Main content */}
          <div className="max-w-lg">
            <h1 className="text-4xl font-bold text-white leading-tight mb-4">
              Workforce Management,<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-300 to-violet-300">Simplified.</span>
            </h1>
            <p className="text-slate-400 text-lg leading-relaxed mb-8">
              Track attendance, manage compliance, and generate reports — all from one powerful dashboard.
            </p>

            {/* Feature pills */}
            <div className="flex flex-wrap gap-3">
              {['Real-time Tracking', 'Compliance Reports', 'Multi-shift Support', 'Worker Directory'].map(f => (
                <span key={f} className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-sm text-slate-300 backdrop-blur-sm">
                  {f}
                </span>
              ))}
            </div>
          </div>

          {/* Sign-in help — no marketing numbers here; nothing on this screen is fabricated. */}
          <div className="text-xs text-slate-500">
            Need access? Ask your organization's administrator to create your account.
          </div>
        </div>
      </div>

      {/* Right Panel — Login Form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-white relative">
        {/* Subtle background */}
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(99,102,241,0.02) 1px, transparent 0)',
          backgroundSize: '24px 24px'
        }} />

        <div className="w-full max-w-md relative z-10">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center space-x-3 mb-10">
            <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center font-bold text-white text-lg">
              M
            </div>
            <span className="font-bold text-xl text-slate-800 tracking-tight">Muster</span>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-800 mb-2">Welcome back</h2>
          </div>

          {error && (
            <div className="mb-6 px-4 py-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-3 animate-scale-in">
              <Shield size={16} className="text-rose-500" />
              <p className="text-sm font-medium text-rose-700">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-2">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="Sign in to your dashboard"
                  className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 focus:bg-white transition-all text-sm text-slate-700 placeholder-slate-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-2">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-11 pr-12 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-400 focus:bg-white transition-all text-sm text-slate-700 placeholder-slate-400"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end">
              <button
                type="button"
                onClick={() => addToast('Password reset is not self-service yet — please contact your administrator.', 'info')}
                className="text-sm text-primary-600 hover:text-primary-700 font-medium transition-colors"
              >
                Forgot password?
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className={
                loading
                  ? "w-full flex items-center justify-center gap-2 bg-primary-400 text-white py-3 rounded-xl font-semibold text-sm cursor-wait"
                  : "w-full flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-700 text-white py-3 rounded-xl font-semibold text-sm transition-all shadow-lg shadow-primary-600/25 hover:shadow-primary-600/35 active:scale-[0.98]"
              }
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Signing in...</span>
                </>
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
