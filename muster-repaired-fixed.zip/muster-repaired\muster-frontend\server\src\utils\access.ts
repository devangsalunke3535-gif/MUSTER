import { prisma } from '../config/db';
import { forbidden, notFound } from './http';

/**
 * Permission and scope helpers shared by routes. The backend is the authority:
 * every check here derives the organization from the authenticated context,
 * never from request input.
 */

export async function getPermissionCodes(userId: string, orgId: string): Promise<Set<string>> {
  const userRoles = await prisma.userRole.findMany({
    where: { user_id: userId, scope_organization_id: orgId },
    include: { role: { include: { rolePermissions: { include: { permission: true } } } } },
  });
  const codes = new Set<string>();
  for (const ur of userRoles) {
    if (ur.role.organization_id !== orgId) continue; // defensive: role must belong to the same org
    for (const rp of ur.role.rolePermissions) codes.add(rp.permission.code);
  }
  return codes;
}

export async function isSuperAdmin(userId: string, orgId: string): Promise<boolean> {
  const u = await prisma.user.findFirst({ where: { id: userId, organization_id: orgId, is_active: true } });
  return !!u?.is_super_admin;
}

export async function hasPermission(userId: string, orgId: string, code: string): Promise<boolean> {
  if (await isSuperAdmin(userId, orgId)) return true;
  return (await getPermissionCodes(userId, orgId)).has(code);
}

/** Employee profile linked to the authenticated user in this org (or null). */
export function getSelfEmployee(userId: string, orgId: string) {
  return prisma.employee.findFirst({ where: { user_id: userId, organization_id: orgId } });
}

/**
 * Branch IDs the user is restricted to. An empty array means org-wide access
 * (super admin, or at least one role that is not branch-scoped).
 */
export async function getScopedBranchIds(userId: string, orgId: string): Promise<string[]> {
  if (await isSuperAdmin(userId, orgId)) return [];
  const userRoles = await prisma.userRole.findMany({ where: { user_id: userId, scope_organization_id: orgId } });
  if (userRoles.length === 0) return [];
  if (userRoles.some((ur: any) => !ur.scope_branch_id)) return []; // an org-wide role wins
  return Array.from(new Set(userRoles.map((ur: any) => ur.scope_branch_id as string)));
}

/** Prisma where-fragment restricting employees to the user's branch scope. */
export function branchScopeWhere(branchIds: string[]) {
  if (branchIds.length === 0) return {};
  return { assignmentHistory: { some: { branch_id: { in: branchIds }, effective_to: null } } };
}

/**
 * Load an employee that must belong to the caller's org AND branch scope.
 * Foreign-tenant and out-of-scope IDs both return 404 so existence isn't leaked.
 */
export async function getEmployeeInScope(userId: string, orgId: string, employeeId: string) {
  const branchIds = await getScopedBranchIds(userId, orgId);
  const emp = await prisma.employee.findFirst({
    where: { id: employeeId, organization_id: orgId, ...branchScopeWhere(branchIds) },
    include: { employment: true },
  });
  if (!emp) throw notFound('Employee not found');
  return emp;
}

export async function requirePermissionOrThrow(userId: string, orgId: string, code: string) {
  if (!(await hasPermission(userId, orgId, code))) throw forbidden(`Forbidden: Requires ${code}`);
}

/** Read a numeric org setting (OrganizationSetting.value JSON), with a default. */
export async function getNumericSetting(orgId: string, category: string, key: string, fallback: number): Promise<number> {
  const s = await prisma.organizationSetting.findUnique({
    where: { organization_id_category_key: { organization_id: orgId, category, key } },
  });
  const v = typeof s?.value === 'number' ? s.value : Number((s?.value as any)?.value ?? NaN);
  return Number.isFinite(v) ? v : fallback;
}
