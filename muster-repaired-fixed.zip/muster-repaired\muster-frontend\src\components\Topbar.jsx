import { Search } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Topbar() {
  const { displayName, roleLabel } = useAuth();
  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
  const dateStr = now.toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const initials = (displayName || '?').trim().split(/\s+/).map(n => n[0]).join('').slice(0, 2).toUpperCase();

  return (
    <header className="h-16 bg-white/70 backdrop-blur-xl border-b border-slate-200/60 flex items-center justify-between px-6 sticky top-0 z-10">
      <div className="hidden md:flex items-center space-x-3">
        <span className="text-sm font-medium text-slate-500">{greeting}</span>
        <span className="text-slate-300">|</span>
        <span className="text-sm text-slate-400">{dateStr}</span>
      </div>

      <div className="flex items-center bg-slate-100/80 rounded-xl px-4 py-2 w-80 border border-slate-200/50 focus-within:border-primary-300 focus-within:ring-2 focus-within:ring-primary-100 focus-within:bg-white transition-all">
        <Search size={16} className="text-slate-400" />
        <input type="text" placeholder="Search workers, attendance..." disabled
          className="bg-transparent border-none outline-none text-sm w-full ml-2 text-slate-700 placeholder-slate-400" />
      </div>

      <div className="flex items-center space-x-4">
        <div className="h-8 w-px bg-slate-200" />
        <div className="flex items-center space-x-3">
          <div className="text-right hidden md:block">
            <p className="text-sm font-semibold text-slate-700">{displayName}</p>
            <p className="text-[11px] text-slate-400">{roleLabel}</p>
          </div>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white font-bold text-sm shadow-md shadow-primary-500/20">
            {initials}
          </div>
        </div>
      </div>
    </header>
  );
}
