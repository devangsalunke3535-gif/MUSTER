import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import api, { getMyProfile, inr, fmtTime, fmtMins, describeError } from '../api';
import { Clock, Calendar as CalendarIcon, Briefcase, FileText, ChevronRight, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from './Toast';

export default function WorkerHome() {
  const { displayName } = useAuth();
  const { addToast } = useToast();
  const [attendance, setAttendance] = useState(null);
  const [openSession, setOpenSession] = useState(false);
  const [profile, setProfile] = useState(null);
  const [leaveBalance, setLeaveBalance] = useState(0);
  const [loanBalance, setLoanBalance] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [punching, setPunching] = useState(false);

  const fetchWorkerData = useCallback(async () => {
    try {
      const [todayRes, leaveRes, loanRes, profileData] = await Promise.all([
        api.get('/attendance/today'),
        api.get('/leaves/balances'),
        api.get('/loans/my-advances'),
        getMyProfile(),
      ]);
      setAttendance(todayRes.data.data);
      setOpenSession(todayRes.data.open_session);
      setProfile(profileData);
      const leaves = leaveRes.data?.data || [];
      setLeaveBalance(leaves.reduce((sum, l) => sum + l.remaining_balance, 0));
      const loans = (loanRes.data?.data || []).filter(l => l.status === 'ACTIVE');
      setLoanBalance(loans.reduce((sum, l) => sum + l.remaining_balance, 0));
      setError(null);
    } catch (e) {
      setError(describeError(e, 'Failed to load your dashboard'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchWorkerData(); }, [fetchWorkerData]);

  const handlePunch = async () => {
    setPunching(true);
    try {
      await api.post(openSession ? '/attendance/check-out' : '/attendance/check-in');
      addToast(openSession ? 'Checked out successfully' : 'Checked in successfully', 'success');
      await fetchWorkerData();
    } catch (e) {
      addToast(describeError(e, 'Failed to record attendance'), 'error');
    }
    setPunching(false);
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="h-32 bg-slate-200 rounded-2xl animate-pulse mb-6"></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="h-40 bg-slate-200 rounded-2xl animate-pulse"></div>
          <div className="h-40 bg-slate-200 rounded-2xl animate-pulse"></div>
          <div className="h-40 bg-slate-200 rounded-2xl animate-pulse"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8 space-y-6 md:space-y-8 font-sans">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight">Good morning, {displayName || 'there'}</h1>
        <p className="text-slate-500 mt-1">Here is your daily summary.</p>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      <div className="bg-gradient-to-br from-primary-600 to-primary-800 rounded-3xl p-6 md:p-8 text-white shadow-xl shadow-primary-600/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <p className="text-primary-100 font-medium uppercase tracking-wider text-xs mb-4">Today's Attendance</p>
            <div className="flex items-baseline gap-4 mb-1">
              <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
                {fmtTime(attendance?.first_check_in)}
              </h2>
              {attendance?.status && (
                <span className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-xs font-semibold uppercase tracking-wide border border-white/20">
                  {attendance.status.replace('_', ' ')}
                </span>
              )}
            </div>
            <p className="text-primary-200 mt-2 flex items-center gap-2">
              <Clock size={16} />
              {attendance?.total_worked_mins ? `${fmtMins(attendance.total_worked_mins)} worked today` : (openSession ? 'Checked in' : 'Not checked in yet')}
            </p>
          </div>

          <div className="flex-shrink-0 w-full md:w-auto">
            <button onClick={handlePunch} disabled={punching}
              className={openSession
                ? "w-full md:w-auto px-8 py-4 bg-white text-primary-700 font-bold rounded-2xl shadow-lg hover:bg-slate-50 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-60"
                : "w-full md:w-auto px-8 py-4 bg-primary-500 text-white font-bold rounded-2xl shadow-lg border border-primary-400 hover:bg-primary-400 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-60"}>
              {punching ? 'Please wait...' : openSession ? 'Check Out' : 'Check In'}
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
        <Link to="/my-salary" className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-slate-300 transition-all group">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 group-hover:scale-110 transition-transform">
              <Briefcase size={20} />
            </div>
            <ChevronRight size={20} className="text-slate-300 group-hover:text-emerald-500 transition-colors" />
          </div>
          <p className="text-sm font-medium text-slate-500 mb-1">My Wage</p>
          <p className="text-2xl font-bold text-slate-800">
            {profile?.wage?.basis === 'DAILY' ? <>{inr(profile.daily_wage)}<span className="text-sm font-normal text-slate-500">/day</span></> : (profile?.wage ? profile.wage.basis : 'Not configured')}
          </p>
        </Link>

        <Link to="/my-leave" className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-slate-300 transition-all group">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 group-hover:scale-110 transition-transform">
              <CalendarIcon size={20} />
            </div>
            <ChevronRight size={20} className="text-slate-300 group-hover:text-amber-500 transition-colors" />
          </div>
          <p className="text-sm font-medium text-slate-500 mb-1">Leave Balance</p>
          <p className="text-2xl font-bold text-slate-800">{leaveBalance} <span className="text-sm font-normal text-slate-500">days left</span></p>
        </Link>

        <Link to="/my-advances" className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-slate-300 transition-all group">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-600 group-hover:scale-110 transition-transform">
              <FileText size={20} />
            </div>
            <ChevronRight size={20} className="text-slate-300 group-hover:text-rose-500 transition-colors" />
          </div>
          <p className="text-sm font-medium text-slate-500 mb-1">Active Advance</p>
          <p className="text-2xl font-bold text-slate-800">{inr(loanBalance)} <span className="text-sm font-normal text-slate-500">remaining</span></p>
        </Link>
      </div>
    </div>
  );
}
