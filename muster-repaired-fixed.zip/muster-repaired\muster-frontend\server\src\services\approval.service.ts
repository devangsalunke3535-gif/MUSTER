import { Prisma } from '@prisma/client';
import { forbidden, conflict } from '../utils/http';

export type Decision = 'APPROVED' | 'REJECTED';

/**
 * Create the approval chain for a new request: an ApprovalRequest plus one
 * ApprovalStep for the requester's manager (if they have one).
 */
export async function openApproval(
  tx: Prisma.TransactionClient,
  args: { orgId: string; requesterEmployeeId: string; entityType: string; entityId: string }
) {
  const approval = await tx.approvalRequest.create({
    data: {
      organization_id: args.orgId,
      requester_user_id: args.requesterEmployeeId,
      entity_type: args.entityType,
      entity_id: args.entityId,
    }
  });
  const employment = await tx.employment.findUnique({ where: { employee_id: args.requesterEmployeeId } });
  if (employment?.manager_id && employment.manager_id !== args.requesterEmployeeId) {
    await tx.approvalStep.create({
      data: { approval_request_id: approval.id, approver_user_id: employment.manager_id, step_order: 1 }
    });
  }
  return approval;
}

/**
 * Authorize and record an approve/reject decision, keeping ApprovalRequest,
 * ApprovalStep and ApprovalAction in sync. Must run inside the same
 * transaction that changes the underlying entity's status, so the workflow
 * records and the entity can never disagree.
 *
 * Authorization (on top of the route's permission check):
 *  - the actor must have an employee profile in the same org (actions are
 *    recorded against an Employee);
 *  - nobody may decide their own request, except a super admin;
 *  - if the request has approval steps, the actor must be the approver on a
 *    PENDING step — holding the permission alone is not enough — unless the
 *    actor is a super admin (explicit override, still recorded);
 *  - if the request has no steps (requester has no manager), the route-level
 *    permission is sufficient.
 *
 * Legacy records created without an ApprovalRequest get one created here, in
 * the same transaction, so the decision is never recorded partially.
 */
export async function recordDecision(
  tx: Prisma.TransactionClient,
  args: {
    orgId: string;
    approvalRequestId: string | null;
    entityType: string;
    entityId: string;
    requesterEmployeeId: string;
    actorEmployeeId: string | null;
    actorIsSuperAdmin: boolean;
    decision: Decision;
    comments?: string | null;
  }
): Promise<string> {
  if (!args.actorEmployeeId) {
    throw forbidden('Your account has no employee profile, so approval actions cannot be recorded for it');
  }
  if (args.actorEmployeeId === args.requesterEmployeeId && !args.actorIsSuperAdmin) {
    throw forbidden('You cannot approve or reject your own request');
  }

  let approval = args.approvalRequestId
    ? await tx.approvalRequest.findFirst({ where: { id: args.approvalRequestId, organization_id: args.orgId }, include: { steps: true } })
    : await tx.approvalRequest.findFirst({
        where: { organization_id: args.orgId, entity_type: args.entityType, entity_id: args.entityId },
        include: { steps: true }
      });

  if (!approval) {
    approval = await tx.approvalRequest.create({
      data: {
        organization_id: args.orgId,
        requester_user_id: args.requesterEmployeeId,
        entity_type: args.entityType,
        entity_id: args.entityId,
      },
      include: { steps: true }
    });
  }

  if (approval.status !== 'PENDING') {
    throw conflict(`This request's approval is already ${approval.status.toLowerCase()}`);
  }

  const pendingSteps = approval.steps.filter((s: any) => s.status === 'PENDING');
  const mySteps = pendingSteps.filter((s: any) => s.approver_user_id === args.actorEmployeeId);

  if (approval.steps.length > 0 && mySteps.length === 0 && !args.actorIsSuperAdmin) {
    throw forbidden('You are not the assigned approver for this request');
  }

  const stepsToClose = mySteps.length > 0 ? mySteps : pendingSteps; // super-admin override closes the open steps
  if (stepsToClose.length > 0) {
    await tx.approvalStep.updateMany({
      where: { id: { in: stepsToClose.map((s: any) => s.id) }, status: 'PENDING' },
      data: { status: args.decision }
    });
  }

  await tx.approvalRequest.update({ where: { id: approval.id }, data: { status: args.decision } });
  await tx.approvalAction.create({
    data: {
      approval_request_id: approval.id,
      actor_user_id: args.actorEmployeeId,
      action: args.decision,
      comments: args.comments ?? null,
    }
  });
  return approval.id;
}

/** Mark an approval chain as cancelled (e.g. requester withdrew). */
export async function cancelApproval(tx: Prisma.TransactionClient, orgId: string, approvalRequestId: string | null) {
  if (!approvalRequestId) return;
  await tx.approvalStep.updateMany({ where: { approval_request_id: approvalRequestId, status: 'PENDING' }, data: { status: 'CANCELLED' } });
  await tx.approvalRequest.updateMany({ where: { id: approvalRequestId, organization_id: orgId }, data: { status: 'CANCELLED' } });
}
