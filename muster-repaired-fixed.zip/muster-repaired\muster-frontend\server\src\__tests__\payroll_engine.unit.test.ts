/**
 * Payroll engine — executable unit tests (no database required).
 *
 * Runs the REAL PayrollService against an in-memory stand-in for the Prisma
 * transaction client. This verifies the financial logic itself: recalculation
 * idempotency, the TOTAL multi-loan cap, net pay never negative, paid leave,
 * holidays, loan clearing, and finalized-run rejection.
 *
 * What this does NOT verify: SQL row locking and real transaction isolation.
 * Those need Postgres — see payroll_integrity.test.ts.
 */
const store: any = {};
let snapshot: any = null;

function resetStore() {
  for (const k of Object.keys(store)) delete store[k];
  Object.assign(store, {
    runs: [], loans: [], items: [], components: [], repayments: [], employees: [],
    holidays: [], structures: [], attendances: [], leaves: [], settings: [], seq: 0,
  });
}
const id = (p: string) => `${p}-${++store.seq}`;
const d = (s: string) => new Date(`${s}T00:00:00.000Z`);
const within = (v: Date, r: any) => (!r?.gte || v >= r.gte) && (!r?.lte || v <= r.lte);

const tx: any = {
  $queryRaw: async (strings: TemplateStringsArray, ...vals: any[]) => {
    if (strings.join('?').includes('"PayrollRun"')) {
      const run = store.runs.find((r: any) => r.id === vals[0] && r.organization_id === vals[1]);
      return run ? [{ status: run.status }] : [];
    }
    return []; // loan row locks: no-op in memory
  },
  $executeRaw: async () => {
    for (const l of store.loans) l.remaining_balance = Math.round(l.remaining_balance * 100) / 100;
    return 0;
  },
  payrollRun: {
    update: async ({ where, data }: any) => Object.assign(store.runs.find((r: any) => r.id === where.id), data),
  },
  payrollItem: {
    findMany: async ({ where }: any) => store.items.filter((i: any) => i.payroll_run_id === where.payroll_run_id),
    deleteMany: async ({ where }: any) => { store.items = store.items.filter((i: any) => i.payroll_run_id !== where.payroll_run_id); },
    create: async ({ data }: any) => {
      const { components, ...rest } = data;
      const item = { id: id('item'), ...rest };
      store.items.push(item);
      for (const c of components.create) store.components.push({ id: id('pic'), payroll_item_id: item.id, ...c });
      return item;
    },
  },
  payrollItemComponent: {
    deleteMany: async ({ where }: any) => { store.components = store.components.filter((c: any) => !where.payroll_item_id.in.includes(c.payroll_item_id)); },
  },
  loanRepayment: {
    findMany: async ({ where }: any) => store.repayments.filter((r: any) => where.payroll_item_id.in.includes(r.payroll_item_id)),
    deleteMany: async ({ where }: any) => { store.repayments = store.repayments.filter((r: any) => !where.payroll_item_id.in.includes(r.payroll_item_id)); },
    create: async ({ data }: any) => { const r = { id: id('rep'), ...data }; store.repayments.push(r); return r; },
  },
  loan: {
    update: async ({ where, data }: any) => {
      const l = store.loans.find((x: any) => x.id === where.id);
      if (data.remaining_balance?.increment !== undefined) l.remaining_balance += data.remaining_balance.increment;
      else if (typeof data.remaining_balance === 'number') l.remaining_balance = data.remaining_balance;
      if (data.status) l.status = data.status;
      return l;
    },
    findMany: async ({ where }: any) => store.loans
      .filter((l: any) => l.employee_id === where.employee_id && l.status === where.status &&
        l.remaining_balance > where.remaining_balance.gt && l.disbursed_date <= where.disbursed_date.lte)
      .sort((a: any, b: any) => +a.disbursed_date - +b.disbursed_date || +a.created_at - +b.created_at),
  },
  employee: { findMany: async () => store.employees },
  holiday: { findMany: async ({ where }: any) => store.holidays.filter((h: any) => within(h.date, where.date)) },
  salaryStructure: {
    findFirst: async ({ where }: any) => store.structures.find((s: any) => s.employee_id === where.employee_id && s.status === 'ACTIVE') || null,
  },
  attendance: {
    findMany: async ({ where }: any) => store.attendances.filter((a: any) => a.employee_id === where.employee_id && within(a.date, where.date)),
  },
  leaveRequest: {
    findMany: async ({ where }: any) => store.leaves.filter((l: any) =>
      l.employee_id === where.employee_id && l.status === 'APPROVED' && l.is_paid &&
      l.start_date <= where.start_date.lte && l.end_date >= where.end_date.gte),
  },
  organizationSetting: {
    findUnique: async ({ where }: any) => store.settings.find((s: any) => s.key === where.organization_id_category_key.key) || null,
  },
};

const mockPrisma: any = {
  ...tx,
  // Transaction semantics: all-or-nothing via snapshot/restore.
  $transaction: async (fn: any) => {
    snapshot = JSON.parse(JSON.stringify(store), (_k, v) => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v) ? new Date(v) : v));
    try { return await fn(tx); } catch (e) { resetStore(); Object.assign(store, snapshot); throw e; }
  },
};

// Getter so the (hoisted) factory never touches mockPrisma before it is initialised.
jest.mock('../config/db', () => ({ get prisma() { return mockPrisma; } }));

import { PayrollService } from '../services/payroll.service';

const ORG = 'org-1';
const START = d('2026-09-01');
const END = d('2026-09-30');
const BASIC = { id: 'c-basic', name: 'Basic', code: 'BASIC', type: 'EARNING', is_active: true };
const PF = { id: 'c-pf', name: 'PF', code: 'PF', type: 'DEDUCTION', is_active: true };

function addEmployee(opts: { wage: number; basis?: string; pf?: number; joining?: string }) {
  const empId = id('emp');
  store.employees.push({
    id: empId, emp_id: empId.toUpperCase(), first_name: 'Test', last_name: empId,
    employment: { status: 'ACTIVE', joining_date: d(opts.joining || '2026-01-01') },
    defaultShift: { full_day_mins: 480 }, assignmentHistory: [{ branch_id: 'b-1' }],
  });
  const items: any[] = [{ amount: opts.wage, component: BASIC }];
  if (opts.pf !== undefined) items.push({ amount: opts.pf, component: PF });
  store.structures.push({ employee_id: empId, status: 'ACTIVE', wage_basis: opts.basis || 'DAILY', items });
  return empId;
}
function attend(empId: string, dates: string[], status = 'PRESENT', mins = 480) {
  for (const s of dates) store.attendances.push({ employee_id: empId, date: d(s), status, total_worked_mins: mins });
}
function addLoan(empId: string, amount: number, disbursed = '2026-08-01') {
  const l = { id: id('loan'), employee_id: empId, organization_id: ORG, amount, remaining_balance: amount, status: 'ACTIVE', disbursed_date: d(disbursed), created_at: new Date(store.seq) };
  store.loans.push(l);
  return l;
}
function addRun(status = 'PROCESSING') {
  const r = { id: id('run'), organization_id: ORG, status };
  store.runs.push(r);
  return r;
}
const days = (n: number, from = 1) => Array.from({ length: n }, (_, i) => `2026-09-${String(from + i).padStart(2, '0')}`);
const itemFor = (runId: string, empId: string) => store.items.find((i: any) => i.payroll_run_id === runId && i.employee_id === empId);

function financialState(runId: string) {
  const items = store.items.filter((i: any) => i.payroll_run_id === runId);
  const itemIds = items.map((i: any) => i.id);
  return {
    items: items.length,
    components: store.components.filter((c: any) => itemIds.includes(c.payroll_item_id)).length,
    repayments: store.repayments.filter((r: any) => itemIds.includes(r.payroll_item_id)).length,
    gross: items.reduce((s: number, i: any) => s + i.gross_earnings, 0),
    deductions: items.reduce((s: number, i: any) => s + i.total_deductions, 0),
    net: items.reduce((s: number, i: any) => s + i.net_pay, 0),
    loans: store.loans.map((l: any) => ({ id: l.id, remaining: l.remaining_balance, status: l.status })),
  };
}

beforeEach(() => resetStore());

describe('Payroll engine (real PayrollService, in-memory store)', () => {
  it('matches the established single-loan figures: 1.5 days × ₹700, PF ₹50, 10% loan recovery', async () => {
    const emp = addEmployee({ wage: 700, pf: 50 });
    attend(emp, ['2026-09-10']);
    attend(emp, ['2026-09-11'], 'HALF_DAY', 240);
    const loan = addLoan(emp, 2000);
    const run = addRun();

    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    const item = itemFor(run.id, emp);
    expect(item.payable_days).toBe(1.5);
    expect(item.gross_earnings).toBe(1050);
    expect(item.total_deductions).toBe(155);
    expect(item.net_pay).toBe(895);
    expect(loan.remaining_balance).toBe(1895);
    expect(run.status).toBe('REVIEW');
  });

  it('recalculating the SAME run is idempotent (items, components, repayments, totals, loan balances)', async () => {
    const emp = addEmployee({ wage: 800, pf: 50 });
    attend(emp, days(20));
    addLoan(emp, 5000);
    addLoan(emp, 3000, '2026-08-15');
    const run = addRun();

    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    const first = financialState(run.id);
    run.status = 'PROCESSING';
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    const second = financialState(run.id);
    run.status = 'PROCESSING';
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    const third = financialState(run.id);

    expect(second).toEqual(first);
    expect(third).toEqual(first);
    expect(first.items).toBe(1);
    // Oldest loan first: the ₹5000 loan absorbs the whole ₹1600 cap, so exactly one repayment — never duplicated.
    expect(first.repayments).toBe(1);
    expect(first.loans).toEqual([
      expect.objectContaining({ remaining: 3400, status: 'ACTIVE' }),
      expect.objectContaining({ remaining: 3000, status: 'ACTIVE' }),
    ]);
    // Gross 16000; loan cap 10% = 1600 total across both loans
    expect(first.gross).toBe(16000);
    expect(first.deductions).toBe(50 + 1600);
    const totalOutstanding = first.loans.reduce((s: number, l: any) => s + l.remaining, 0);
    expect(totalOutstanding).toBe(8000 - 1600); // decreased exactly once
  });

  it('caps TOTAL deductions across multiple loans (A=1000, B=1000, cap=1200 → 1200, not 2000)', async () => {
    const emp = addEmployee({ wage: 1000 });
    attend(emp, days(12)); // gross 12000 → 10% = 1200
    const a = addLoan(emp, 1000, '2026-07-01');
    const b = addLoan(emp, 1000, '2026-08-01');
    const run = addRun();

    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    const item = itemFor(run.id, emp);
    expect(item.total_deductions).toBe(1200);
    expect(item.net_pay).toBe(10800);
    expect(a.remaining_balance).toBe(0);      // oldest loan recovered first
    expect(a.status).toBe('CLEARED');
    expect(b.remaining_balance).toBe(800);
    expect(b.status).toBe('ACTIVE');
  });

  it('respects a configured deduction cap percentage', async () => {
    store.settings.push({ key: 'max_loan_deduction_pct', value: 25 });
    const emp = addEmployee({ wage: 1000 });
    attend(emp, days(10));
    addLoan(emp, 1000); addLoan(emp, 1000, '2026-08-02');
    const run = addRun();
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    expect(itemFor(run.id, emp).total_deductions).toBe(2000); // 25% of 10000 = 2500 cap, only 2000 owed
  });

  it('recalculation after a loan was cleared restores and re-clears it exactly once', async () => {
    const emp = addEmployee({ wage: 1000 });
    attend(emp, days(10));
    const loan = addLoan(emp, 500);
    const run = addRun();
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    expect(loan).toMatchObject({ remaining_balance: 0, status: 'CLEARED' });
    run.status = 'PROCESSING';
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    expect(loan).toMatchObject({ remaining_balance: 0, status: 'CLEARED' });
    expect(store.repayments.length).toBe(1);
  });

  it('never produces negative net pay: fixed deductions are capped and reported', async () => {
    const emp = addEmployee({ wage: 700, pf: 50 }); // no attendance → gross 0
    addLoan(emp, 1000);
    const run = addRun();
    const { warnings } = await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    const item = itemFor(run.id, emp);
    expect(item.gross_earnings).toBe(0);
    expect(item.total_deductions).toBe(0);
    expect(item.net_pay).toBe(0);
    expect(warnings.some(w => w.reason.includes('PF reduced'))).toBe(true);
    expect(store.loans[0].remaining_balance).toBe(1000);
  });

  it('pays approved paid leave, without double-counting attendance or holidays', async () => {
    const emp = addEmployee({ wage: 500 });
    attend(emp, ['2026-09-01', '2026-09-02']);
    store.holidays.push({ date: d('2026-09-05'), branch_id: null });
    // Leave 2–6 Sep: 2nd already attended, 5th is a holiday → paid leave = 3rd, 4th, 6th
    store.leaves.push({ employee_id: emp, status: 'APPROVED', is_paid: true, start_date: d('2026-09-02'), end_date: d('2026-09-06') });
    const run = addRun();
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    // 2 attended + 3 paid leave + 1 holiday (DAILY) = 6
    expect(itemFor(run.id, emp).payable_days).toBe(6);
    expect(itemFor(run.id, emp).gross_earnings).toBe(3000);
  });

  it('does not pay holidays on top of a MONTHLY salary, and ignores holidays before joining for DAILY', async () => {
    const monthly = addEmployee({ wage: 30000, basis: 'MONTHLY' });
    attend(monthly, days(10, 10));
    const daily = addEmployee({ wage: 500, joining: '2026-09-15' });
    attend(daily, ['2026-09-16']);
    store.holidays.push({ date: d('2026-09-05'), branch_id: null }, { date: d('2026-09-20'), branch_id: null });
    const run = addRun();
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    expect(itemFor(run.id, monthly).payable_days).toBe(10);
    expect(itemFor(run.id, monthly).gross_earnings).toBe(10000); // 30000 / 30 × 10
    expect(itemFor(run.id, daily).payable_days).toBe(2);           // 16th + holiday on 20th (5th is before joining)
  });

  it('ignores holidays for a different branch', async () => {
    const emp = addEmployee({ wage: 500 });
    store.holidays.push({ date: d('2026-09-05'), branch_id: 'b-other' });
    const run = addRun();
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    expect(itemFor(run.id, emp).payable_days).toBe(0);
  });

  it('does not recover loans disbursed after the period ends', async () => {
    const emp = addEmployee({ wage: 1000 });
    attend(emp, days(10));
    const future = addLoan(emp, 1000, '2026-10-05');
    const run = addRun();
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    expect(future.remaining_balance).toBe(1000);
    expect(itemFor(run.id, emp).total_deductions).toBe(0);
  });

  it('refuses to recalculate a FINALIZED run and leaves its data untouched', async () => {
    const emp = addEmployee({ wage: 700 });
    attend(emp, days(5));
    const loan = addLoan(emp, 1000);
    const run = addRun();
    await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    const before = financialState(run.id);
    run.status = 'FINALIZED';
    attend(emp, days(5, 20)); // new attendance must not change a finalized run
    await expect(PayrollService.calculatePayrollRun(run.id, ORG, START, END)).rejects.toThrow('finalized');
    expect(financialState(run.id)).toEqual(before);
    expect(loan.remaining_balance).toBe(1000 - 350);
  });

  it('warns (never silently skips) employees without a salary structure', async () => {
    const emp = addEmployee({ wage: 700 });
    store.structures = [];
    const run = addRun();
    const { warnings } = await PayrollService.calculatePayrollRun(run.id, ORG, START, END);
    expect(warnings).toEqual([expect.objectContaining({ employee_id: emp, reason: expect.stringContaining('No active salary structure') })]);
    expect(store.items.length).toBe(0);
  });
});
