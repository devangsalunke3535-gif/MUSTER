import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { sendError, parseDateOnly, todayIST, addDaysUTC, toDateKey } from '../utils/http';
import { getScopedBranchIds, branchScopeWhere } from '../utils/access';
import { ACTIVE_EMPLOYMENT_STATUSES, classifyShift } from '../services/employee.service';

const router = Router();

type Bucket = { total: number; present: number; absent: number; half: number; not_marked: number; attendance_rate: number | null };
const emptyBucket = (): Bucket => ({ total: 0, present: 0, absent: 0, half: 0, not_marked: 0, attendance_rate: null });

function finalize(b: Bucket) {
  b.not_marked = b.total - b.present - b.absent - b.half;
  // null (not 0) when there is nobody to measure — the UI shows "—", never NaN or a fake 0%.
  b.attendance_rate = b.total > 0 ? Math.round(((b.present + b.half * 0.5) / b.total) * 100) : null;
  return b;
}

/**
 * GET /dashboard/summary?date=YYYY-MM-DD
 *
 * Order of operations (as required):
 *  1. active employees in the caller's scope
 *  2. each employee's CURRENT persisted shift (Employee.default_shift_id)
 *  3. group employees by that shift — never inferred from attendance, never defaulted to Day
 *  4. aggregate the day's attendance within each group
 *
 * Requires employee:view — workers (who only have self-service permissions) cannot see org-wide numbers.
 */
router.get('/summary', requirePermission('employee:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const date = req.query.date ? parseDateOnly(req.query.date as string, 'date') : todayIST();
    const branchIds = await getScopedBranchIds(req.authContext!.userId, orgId);
    const scope = branchScopeWhere(branchIds);

    const employees = await prisma.employee.findMany({
      where: { organization_id: orgId, employment: { status: { in: ACTIVE_EMPLOYMENT_STATUSES } }, ...scope },
      select: { id: true, defaultShift: { select: { name: true } } }
    });

    const buckets = { day: emptyBucket(), night: emptyBucket(), other: emptyBucket(), unassigned: emptyBucket() };
    const byEmp = new Map<string, Bucket>();
    for (const e of employees) {
      const t = classifyShift(e.defaultShift);
      const b = t === 'DAY' ? buckets.day : t === 'NIGHT' ? buckets.night : t === 'OTHER' ? buckets.other : buckets.unassigned;
      b.total++;
      byEmp.set(e.id, b);
    }

    const attendances = await prisma.attendance.findMany({
      where: { organization_id: orgId, date, employee_id: { in: Array.from(byEmp.keys()) } },
      select: { employee_id: true, status: true }
    });
    for (const a of attendances) {
      const b = byEmp.get(a.employee_id);
      if (!b) continue;
      if (a.status === 'PRESENT') b.present++;
      else if (a.status === 'ABSENT') b.absent++;
      else if (a.status === 'HALF_DAY') b.half++;
    }

    const total = emptyBucket();
    for (const b of Object.values(buckets)) {
      finalize(b);
      total.total += b.total; total.present += b.present; total.absent += b.absent; total.half += b.half;
    }
    finalize(total);

    // 7-day trend of the same metric. Uses today's active roster as the denominator
    // (historical roster snapshots are not stored); days with no roster return null.
    const trendStart = addDaysUTC(date, -6);
    const trendAtt = await prisma.attendance.findMany({
      where: { organization_id: orgId, date: { gte: trendStart, lte: date }, employee_id: { in: Array.from(byEmp.keys()) } },
      select: { date: true, status: true }
    });
    const trend: { date: string; label: string; value: number | null; marked: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = addDaysUTC(date, -i);
      const key = toDateKey(d);
      const dayRows = trendAtt.filter((a: any) => toDateKey(a.date) === key);
      const present = dayRows.filter((a: any) => a.status === 'PRESENT').length;
      const half = dayRows.filter((a: any) => a.status === 'HALF_DAY').length;
      trend.push({
        date: key,
        label: i === 0 ? 'Today' : d.toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' }),
        value: employees.length ? Math.round(((present + half * 0.5) / employees.length) * 100) : null,
        marked: dayRows.length,
      });
    }

    const [pendingLeave, pendingLoans, latestRun] = await Promise.all([
      prisma.leaveRequest.count({ where: { status: 'PENDING', employee: { organization_id: orgId, ...scope } } }),
      prisma.loan.count({ where: { organization_id: orgId, status: 'PENDING', employee: scope } }),
      prisma.payrollRun.findFirst({
        where: { organization_id: orgId },
        orderBy: { period: { start_date: 'desc' } },
        include: { period: { select: { name: true, start_date: true, end_date: true } } }
      }),
    ]);

    res.json({
      date: toDateKey(date),
      ...buckets,
      total,
      trend,
      pending: { leave: pendingLeave, loans: pendingLoans, total: pendingLeave + pendingLoans },
      payroll: latestRun ? { id: latestRun.id, status: latestRun.status, period: latestRun.period } : null,
    });
  } catch (error) {
    sendError(res, error, 'Dashboard summary');
  }
});

router.get('/compliance', requirePermission('employee:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const branchIds = await getScopedBranchIds(req.authContext!.userId, orgId);
    const employees = await prisma.employee.findMany({
      where: { organization_id: orgId, employment: { status: { in: ACTIVE_EMPLOYMENT_STATUSES } }, ...branchScopeWhere(branchIds) },
      include: { statutoryProfile: true, defaultShift: true },
      orderBy: { emp_id: 'asc' }
    });

    let missing_uan = 0;
    let missing_esi = 0;
    const workers = employees.map((emp: any) => {
      const uan = !!emp.statutoryProfile?.uan_enc;
      const esi = !!emp.statutoryProfile?.esi_number_enc;
      if (!uan) missing_uan++;
      if (!esi) missing_esi++;
      return {
        id: emp.id,
        worker_id: emp.emp_id,
        name: `${emp.first_name || ''} ${emp.last_name || ''}`.trim(),
        shift_type: classifyShift(emp.defaultShift),
        shift_name: emp.defaultShift?.name || null,
        uan,
        esi_ip: esi,
      };
    });

    const total = employees.length;
    res.json({
      total,
      missing_uan,
      missing_esi,
      uan_coverage: total ? Math.round(((total - missing_uan) / total) * 100) : null,
      esi_coverage: total ? Math.round(((total - missing_esi) / total) * 100) : null,
      workers
    });
  } catch (error) {
    sendError(res, error, 'Compliance summary');
  }
});

export default router;
