import { Request, Response, NextFunction } from 'express';

/**
 * P0-3 FIX: isolateTenant no longer writes organization_id into req.body.
 * Writing into req.body was an architectural IDOR surface — a route using
 * `...req.body` spread into Prisma could allow the client to override the org.
 *
 * The authenticated organization_id is available ONLY through req.authContext.
 * All route handlers must read it from req.authContext!.organizationId directly.
 */
export function isolateTenant(req: Request, res: Response, next: NextFunction) {
  if (!req.authContext?.organizationId) {
    return res.status(403).json({ error: 'Tenant context missing' });
  }
  // Do NOT inject into req.body. Routes must use req.authContext!.organizationId.
  next();
}
