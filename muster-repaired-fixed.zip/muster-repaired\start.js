const { spawn } = require('child_process');
const path = require('path');

const isWin = process.platform === 'win32';
const npmCmd = isWin ? 'npm.cmd' : 'npm';

console.log('Starting MUSTER Backend and Frontend...\n');

const server = spawn(npmCmd, ['run', 'dev'], {
  cwd: path.join(__dirname, 'muster-frontend', 'server'),
  stdio: 'inherit',
  shell: true,
});

const client = spawn(npmCmd, ['run', 'dev'], {
  cwd: path.join(__dirname, 'muster-frontend'),
  stdio: 'inherit',
  shell: true,
});

function cleanup() {
  if (server) server.kill();
  if (client) client.kill();
  process.exit();
}

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
