/**
 * Idempotent, NON-DESTRUCTIVE demo seed.
 *
 * Safe to run any number of times against an existing database:
 *  - creates only what is missing (find-or-create by natural keys);
 *  - fills in empty links (e.g. a worker with no manager / no shift) but never
 *    overwrites a value that is already set;
 *  - never deletes, truncates, or resets anything;
 *  - never changes an existing user's password.
 *
 * Demo logins (password admin123): admin@muster.com, manager@muster.com, worker@muster.com
 */
import { PrismaClient } from '@prisma/client';
import * as argon2 from 'argon2';
import { PERMISSIONS, WORKER_PERMISSIONS, SITE_MANAGER_PERMISSIONS, SUPER_ADMIN_PERMISSIONS } from '../src/config/permissions';

const prisma = new PrismaClient();
const log = (m: string) => console.log(`  ${m}`);

async function findOrCreate(label: string, find: () => Promise<any>, create: () => Promise<any>): Promise<any> {
  const existing = await find();
  if (existing) return existing;
  const created = await create();
  log(`created ${label}`);
  return created;
}

async function main() {
  console.log('Seeding MUSTER demo data (idempotent)...');

  const org = await findOrCreate('organization MDC',
    () => prisma.organization.findUnique({ where: { code: 'MDC' } }),
    () => prisma.organization.create({ data: { name: 'MUSTER Demo Corp', code: 'MDC', legal_name: 'MUSTER Demo Corporation Pvt Ltd' } }));

  const branch = await findOrCreate('branch HQ',
    () => prisma.branch.findUnique({ where: { organization_id_code: { organization_id: org.id, code: 'HQ' } } }),
    () => prisma.branch.create({ data: { organization_id: org.id, name: 'Headquarters', code: 'HQ', city: 'Mumbai', state: 'Maharashtra', country: 'India', is_headquarters: true } }));

  const department = await findOrCreate('department CONST',
    () => prisma.department.findUnique({ where: { branch_id_code: { branch_id: branch.id, code: 'CONST' } } }),
    () => prisma.department.create({ data: { branch_id: branch.id, name: 'Construction', code: 'CONST' } }));

  const designation = await findOrCreate('designation MASON',
    () => prisma.designation.findUnique({ where: { department_id_code: { department_id: department.id, code: 'MASON' } } }),
    () => prisma.designation.create({ data: { department_id: department.id, title: 'Mason', code: 'MASON' } }));

  // ---- Permissions & roles ------------------------------------------------
  for (const p of PERMISSIONS) {
    await prisma.permission.upsert({ where: { code: p.code }, update: {}, create: p });
  }
  const permId = new Map((await prisma.permission.findMany()).map((p: any) => [p.code, p.id]));

  const role = (code: string, name: string) => findOrCreate(`role ${code}`,
    () => prisma.role.findUnique({ where: { organization_id_code: { organization_id: org.id, code } } }),
    () => prisma.role.create({ data: { organization_id: org.id, code, name, is_system_role: true } }));
  const adminRole = await role('SUPER_ADMIN', 'Super Admin');
  const managerRole = await role('SITE_MANAGER', 'Site Manager');
  const workerRole = await role('WORKER', 'Worker');

  const grant = async (r: any, codes: string[]) => {
    let added = 0;
    for (const code of codes) {
      const permission_id = permId.get(code);
      if (!permission_id) throw new Error(`Unknown permission ${code}`);
      const exists = await prisma.rolePermission.findUnique({ where: { role_id_permission_id: { role_id: r.id, permission_id } } });
      if (!exists) { await prisma.rolePermission.create({ data: { role_id: r.id, permission_id } }); added++; }
    }
    if (added) log(`granted ${added} permission(s) to ${r.code}`);
  };
  await grant(adminRole, SUPER_ADMIN_PERMISSIONS);
  await grant(managerRole, SITE_MANAGER_PERMISSIONS);
  await grant(workerRole, WORKER_PERMISSIONS);

  // ---- Shifts ---------------------------------------------------------------
  const shift = (name: string, start: string, end: string) => findOrCreate(`shift ${name}`,
    () => prisma.shift.findFirst({ where: { organization_id: org.id, name } }),
    () => prisma.shift.create({ data: { organization_id: org.id, name, start_time: start, end_time: end, grace_period_mins: 15, half_day_mins: 240, full_day_mins: 480 } }));
  const dayShift = await shift('Day Shift', '09:00', '18:00');
  await shift('Night Shift', '21:00', '06:00');

  // ---- Users -----------------------------------------------------------------
  let passwordHash: string | null = null;
  const user = async (email: string, isSuperAdmin: boolean, r: any, branchScope: string | null) => {
    let u = await prisma.user.findUnique({ where: { organization_id_email: { organization_id: org.id, email } } });
    if (!u) {
      passwordHash = passwordHash || await argon2.hash('admin123');
      u = await prisma.user.create({ data: { organization_id: org.id, email, password_hash: passwordHash, is_super_admin: isSuperAdmin } });
      log(`created user ${email}`);
    }
    const ur = await prisma.userRole.findFirst({ where: { user_id: u.id, role_id: r.id, scope_organization_id: org.id } });
    if (!ur) {
      await prisma.userRole.create({ data: { user_id: u.id, role_id: r.id, scope_organization_id: org.id, scope_branch_id: branchScope } });
      log(`assigned ${r.code} to ${email}`);
    }
    return u;
  };
  const adminUser = await user('admin@muster.com', true, adminRole, null);
  const managerUser = await user('manager@muster.com', false, managerRole, branch.id);
  const workerUser = await user('worker@muster.com', false, workerRole, branch.id);

  // ---- Employee profiles ------------------------------------------------------
  // Approval actions are recorded against Employee rows, so admin and manager need one too.
  const profile = async (u: any, empId: string, first: string, last: string, extra: { managerId?: string | null; shiftId?: string | null }) => {
    let emp = await prisma.employee.findFirst({ where: { organization_id: org.id, user_id: u.id } });
    if (!emp) {
      const codeTaken = await prisma.employee.findUnique({ where: { organization_id_emp_id: { organization_id: org.id, emp_id: empId } } });
      if (codeTaken && !codeTaken.user_id) {
        emp = await prisma.employee.update({ where: { id: codeTaken.id }, data: { user_id: u.id } });
        log(`linked existing employee ${empId} to ${u.email}`);
      } else {
        emp = await prisma.employee.create({
          data: {
            organization_id: org.id, user_id: u.id, emp_id: codeTaken ? `${empId}-${u.id.slice(0, 4)}` : empId,
            first_name: first, last_name: last,
            assignmentHistory: { create: { branch_id: branch.id, department_id: department.id, designation_id: designation.id, effective_from: new Date('2026-01-01') } },
            statusHistory: { create: { status: 'ACTIVE', effective_from: new Date('2026-01-01'), reason: 'Seed' } },
          }
        });
        log(`created employee profile for ${u.email}`);
      }
    }
    const employment = await prisma.employment.findUnique({ where: { employee_id: emp.id } });
    if (!employment) {
      await prisma.employment.create({ data: { employee_id: emp.id, joining_date: new Date('2026-01-01'), status: 'ACTIVE', manager_id: extra.managerId ?? null } });
      log(`created employment for ${u.email}`);
    } else if (!employment.manager_id && extra.managerId && extra.managerId !== emp.id) {
      await prisma.employment.update({ where: { employee_id: emp.id }, data: { manager_id: extra.managerId } });
      log(`set manager for ${u.email}`);
    }
    if (!emp.default_shift_id && extra.shiftId) {
      emp = await prisma.employee.update({ where: { id: emp.id }, data: { default_shift_id: extra.shiftId } });
      log(`assigned default shift to ${u.email}`);
    }
    const assignment = await prisma.employeeAssignmentHistory.findFirst({ where: { employee_id: emp.id } });
    if (!assignment) {
      await prisma.employeeAssignmentHistory.create({ data: { employee_id: emp.id, branch_id: branch.id, effective_from: new Date('2026-01-01') } });
    }
    return emp;
  };
  const adminEmp = await profile(adminUser, 'A-0001', 'Admin', 'User', {});
  const managerEmp = await profile(managerUser, 'M-0001', 'Site', 'Manager', { managerId: adminEmp.id, shiftId: dayShift.id });
  const workerEmp = await profile(workerUser, 'W-1001', 'Rahul', 'Kumar', { managerId: managerEmp.id, shiftId: dayShift.id });

  // ---- Leave --------------------------------------------------------------------
  const leaveType = await findOrCreate('leave type AL',
    () => prisma.leaveType.findUnique({ where: { organization_id_code: { organization_id: org.id, code: 'AL' } } }),
    () => prisma.leaveType.create({ data: { organization_id: org.id, name: 'Annual Leave', code: 'AL', is_paid: true, annual_quota: 12 } }));
  const year = Number(new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' }).slice(0, 4));
  for (const emp of [workerEmp, managerEmp]) {
    const bal = await prisma.leaveBalance.findUnique({ where: { employee_id_leave_type_id_leave_year: { employee_id: emp.id, leave_type_id: leaveType.id, leave_year: year } } });
    if (!bal) {
      await prisma.leaveBalance.create({ data: { employee_id: emp.id, leave_type_id: leaveType.id, leave_year: year, allocated_balance: 12, remaining_balance: 12 } });
      log(`allocated ${year} leave balance to ${emp.emp_id}`);
    }
  }

  // ---- Salary ------------------------------------------------------------------
  const component = (code: string, name: string, type: string) => findOrCreate(`component ${code}`,
    () => prisma.salaryComponent.findUnique({ where: { organization_id_code: { organization_id: org.id, code } } }),
    () => prisma.salaryComponent.create({ data: { organization_id: org.id, code, name, type, is_active: true } }));
  const basic = await component('BASIC', 'Basic', 'EARNING');
  const pf = await component('PF', 'PF', 'DEDUCTION');

  for (const [emp, wage] of [[workerEmp, 650], [managerEmp, 1200]] as const) {
    const active = await prisma.salaryStructure.findFirst({ where: { employee_id: emp.id, status: 'ACTIVE' } });
    if (!active) {
      await prisma.salaryStructure.create({
        data: {
          organization_id: org.id, employee_id: emp.id, wage_basis: 'DAILY', effective_from: new Date('2026-01-01'), status: 'ACTIVE',
          items: { create: [{ salary_component_id: basic.id, amount: wage }, { salary_component_id: pf.id, amount: 50 }] }
        }
      });
      log(`created salary structure for ${emp.emp_id}`);
    }
  }

  // ---- Org settings (read by the API; defaults match the previous hardcoded UI text) ----
  for (const [key, value, description] of [
    ['max_advance_amount', 10000, 'Maximum amount of a single self-service salary advance request (₹)'],
    ['max_loan_deduction_pct', 10, 'Maximum total loan recovery per payroll, as % of gross earnings, across ALL loans'],
  ] as const) {
    const s = await prisma.organizationSetting.findUnique({ where: { organization_id_category_key: { organization_id: org.id, category: 'payroll', key } } });
    if (!s) {
      await prisma.organizationSetting.create({ data: { organization_id: org.id, category: 'payroll', key, value, description } });
      log(`created setting payroll.${key}`);
    }
  }

  console.log(`Seed complete for ${org.name}. Logins: admin@muster.com, manager@muster.com, worker@muster.com`);
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
