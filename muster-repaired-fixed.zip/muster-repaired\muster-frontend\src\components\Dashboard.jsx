import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { getSummary, getCompliance, describeError, todayISO } from '../api';
import { Users, AlertCircle, CheckCircle, Clock, Sun, Moon, HelpCircle, Calendar as CalendarIcon, Activity, ShieldAlert, ArrowRight, UserPlus, ClipboardList } from 'lucide-react';

function StatCard({ label, value, icon: Icon, iconBg }) {
  return (
    <div className="hover-lift bg-white rounded-2xl p-5 border border-slate-100 shadow-soft">
      <div className="flex items-center justify-between mb-3">
        <div className={"w-10 h-10 rounded-xl flex items-center justify-center " + iconBg}>
          <Icon size={18} />
        </div>
      </div>
      <p className="text-2xl font-bold text-slate-800">{value}</p>
      <p className="text-xs font-medium text-slate-400 mt-1">{label}</p>
    </div>
  );
}

function MiniBarChart({ data }) {
  const values = data.map(d => d.value).filter(v => v !== null);
  const max = Math.max(...values, 1);
  if (data.length === 0) return <p className="text-xs text-slate-400 text-center py-8">No data yet</p>;
  return (
    <div className="flex items-end gap-1.5 h-24">
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <div className="w-full rounded-t-md bg-primary-100 relative overflow-hidden" style={{ height: '100%' }}>
            {d.value !== null ? (
              <div className="absolute bottom-0 w-full bg-gradient-to-t from-primary-600 to-primary-400 rounded-t-md transition-all duration-700" style={{ height: (d.value / max * 100) + '%' }} />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-slate-300 text-[9px]">—</div>
            )}
          </div>
          <span className="text-[9px] font-semibold text-slate-400">{d.label}</span>
        </div>
      ))}
    </div>
  );
}

function ShiftCard({ shiftName, icon: Icon, data }) {
  const total = data.total || 0;
  const isDay = shiftName === 'Day';
  const gradientClass = isDay ? 'bg-gradient-to-br from-amber-50 via-orange-50/50 to-white' : 'bg-gradient-to-br from-indigo-50 via-blue-50/50 to-white';
  const iconBg = isDay ? 'bg-amber-100 text-amber-600' : shiftName === 'Night' ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-500';
  const barColor = isDay ? 'bg-gradient-to-r from-amber-400 to-orange-400' : 'bg-gradient-to-r from-indigo-500 to-purple-500';

  return (
    <div className={"hover-lift rounded-2xl p-5 border border-slate-100 shadow-soft relative overflow-hidden " + gradientClass}>
      <div className="absolute -right-3 -top-3 opacity-[0.04]"><Icon size={90} /></div>
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className={"w-11 h-11 rounded-xl flex items-center justify-center shadow-sm " + iconBg}><Icon size={20} /></div>
          <div>
            <h3 className="text-base font-bold text-slate-800">{shiftName} Shift</h3>
            <p className="text-[11px] text-slate-400 font-medium">{total} workers</p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-black text-slate-800">{data.attendance_rate === null ? '—' : `${data.attendance_rate}%`}</div>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-2 relative z-10 mb-3">
        {[
          { label: 'Present', val: data.present, icon: CheckCircle, color: 'text-emerald-500' },
          { label: 'Absent', val: data.absent, icon: AlertCircle, color: 'text-rose-500' },
          { label: 'Half', val: data.half, icon: Clock, color: 'text-amber-500' },
          { label: 'Unmarked', val: data.not_marked, icon: Users, color: 'text-slate-400' },
        ].map(s => (
          <div key={s.label} className="bg-white/80 backdrop-blur-sm p-2.5 rounded-xl border border-white/80 text-center">
            <s.icon size={13} className={s.color + " mx-auto mb-1"} />
            <p className="text-lg font-bold text-slate-800">{s.val}</p>
            <p className="text-[9px] font-semibold text-slate-400 uppercase">{s.label}</p>
          </div>
        ))}
      </div>
      <div className="w-full bg-white/60 rounded-full h-1.5 overflow-hidden relative z-10">
        <div className={"h-full rounded-full transition-all duration-700 " + barColor} style={{ width: (data.attendance_rate || 0) + '%' }} />
      </div>
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [summary, setSummary] = useState(null);
  const [compliance, setCompliance] = useState(null);
  const [error, setError] = useState(null);
  const today = todayISO();
  const [date, setDate] = useState(today);
  const [loading, setLoading] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [sumData, compData] = await Promise.all([getSummary(date), getCompliance()]);
      setSummary(sumData);
      setCompliance(compData);
    } catch (err) {
      setError(describeError(err, 'Failed to load dashboard data'));
    }
    setLoading(false);
  }, [date]);

  useEffect(() => { loadData(); }, [loadData]);

  const totalWorkers = summary?.total?.total ?? 0;
  const totalPresent = summary?.total?.present ?? 0;
  const totalAbsent = summary?.total?.absent ?? 0;
  const attendanceRate = summary?.total?.attendance_rate;
  const trendData = summary?.trend || [];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Dashboard</h1>
          <p className="text-slate-400 text-sm mt-1">Your workforce at a glance</p>
        </div>
        <div className="flex items-center gap-3 bg-white px-4 py-2.5 rounded-xl border border-slate-200 shadow-soft">
          <CalendarIcon size={16} className="text-primary-500" />
          <input type="date" value={date} max={today} onChange={e => setDate(e.target.value)}
            className="bg-transparent text-sm font-medium text-slate-700 outline-none cursor-pointer" />
        </div>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-28 bg-white rounded-2xl animate-pulse border border-slate-100" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-slide-up">
          <StatCard label="Total Workers" value={totalWorkers} icon={Users} iconBg="bg-primary-100 text-primary-600" />
          <StatCard label="Present Today" value={totalPresent} icon={CheckCircle} iconBg="bg-emerald-100 text-emerald-600" />
          <StatCard label="Absent Today" value={totalAbsent} icon={AlertCircle} iconBg="bg-rose-100 text-rose-600" />
          <StatCard label="Attendance Rate" value={attendanceRate === null || attendanceRate === undefined ? '—' : attendanceRate + '%'} icon={Activity} iconBg="bg-amber-100 text-amber-600" />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {loading || !summary ? (
            <>
              <div className="h-56 bg-white rounded-2xl animate-pulse border border-slate-100" />
              <div className="h-56 bg-white rounded-2xl animate-pulse border border-slate-100" />
            </>
          ) : (
            <>
              <ShiftCard shiftName="Day" icon={Sun} data={summary.day} />
              <ShiftCard shiftName="Night" icon={Moon} data={summary.night} />
              {(summary.other.total > 0 || summary.unassigned.total > 0) && (
                <ShiftCard shiftName="Unassigned" icon={HelpCircle} data={{ ...summary.unassigned, total: summary.unassigned.total + summary.other.total }} />
              )}
            </>
          )}
        </div>

        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-soft">
            <h4 className="text-sm font-bold text-slate-700 mb-4">7-Day Attendance Trend</h4>
            <MiniBarChart data={trendData} />
          </div>

          {compliance && (
            <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-soft">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-sm font-bold text-slate-700">Compliance Health</h4>
                <ShieldAlert size={15} className="text-amber-500" />
              </div>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-500 font-medium">UAN Coverage</span>
                    <span className="font-bold text-slate-700">{compliance.uan_coverage === null ? '—' : compliance.uan_coverage + '%'}</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 mb-1 overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full transition-all duration-700" style={{ width: (compliance.uan_coverage || 0) + '%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-500 font-medium">ESI Coverage</span>
                    <span className="font-bold text-slate-700">{compliance.esi_coverage === null ? '—' : compliance.esi_coverage + '%'}</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div className="bg-amber-500 h-full rounded-full transition-all duration-700" style={{ width: (compliance.esi_coverage || 0) + '%' }} />
                  </div>
                </div>
              </div>
              <button onClick={() => navigate('/reports')} className="flex items-center gap-1 text-xs text-primary-600 font-semibold mt-3 hover:text-primary-700 transition-colors">
                View Full Report <ArrowRight size={12} />
              </button>
            </div>
          )}

          {summary?.pending?.total > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
              <h4 className="text-sm font-bold text-amber-800 mb-1">Pending Approvals</h4>
              <p className="text-xs text-amber-700">{summary.pending.leave} leave · {summary.pending.loans} advance request(s) awaiting your review.</p>
              <button onClick={() => navigate('/approvals')} className="flex items-center gap-1 text-xs text-amber-800 font-semibold mt-2 hover:text-amber-900">
                Review now <ArrowRight size={12} />
              </button>
            </div>
          )}

          <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-soft">
            <h4 className="text-sm font-bold text-slate-700 mb-3">Quick Actions</h4>
            <div className="space-y-2">
              <button onClick={() => navigate('/attendance')} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-600 hover:bg-primary-50 hover:text-primary-700 transition-colors border border-slate-100">
                <ClipboardList size={16} className="text-primary-500" /> Mark Today's Attendance
              </button>
              <button onClick={() => navigate('/directory')} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-600 hover:bg-primary-50 hover:text-primary-700 transition-colors border border-slate-100">
                <UserPlus size={16} className="text-primary-500" /> Add New Worker
              </button>
              <button onClick={() => navigate('/reports')} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-600 hover:bg-primary-50 hover:text-primary-700 transition-colors border border-slate-100">
                <ShieldAlert size={16} className="text-primary-500" /> View Compliance Gaps
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
