/**
 * P1 Functional Regression Tests
 * 
 * These tests cover:
 * - P1-1: Payroll warning for employees without salary structure
 * - P1-2/P1-3: Monthly payroll divisor & holiday double-count fix
 * - P1-5: Finalized payroll prevents attendance correction
 * - P1-6: Leave balance re-allocation math correctness
 */
import request from 'supertest';
import app from '../server';
import { prisma } from '../config/db';
import * as argon2 from 'argon2';

describe('P1 Functional Regression Tests', () => {
  let csrfToken: string;
  let csrfCookie: string;
  let authCookie: string;
  
  let orgId: string;
  let empWithStructureId: string;
  let empWithoutStructureId: string;
  let empMonthlyId: string;
  let basicComponentId: string;
  let pfComponentId: string;
  let leaveTypeId: string;
  let empForLeaveId: string;
  let attendanceIdForCorrectionTest: string;

  const PASSWORD = 'P1TestPass123';

  beforeAll(async () => {
    await prisma.loanRepayment.deleteMany();
    await prisma.payrollItemComponent.deleteMany();
    await prisma.payrollItem.deleteMany();
    await prisma.payrollRun.deleteMany();
    await prisma.payrollPeriod.deleteMany();
    await prisma.loan.deleteMany();
    await prisma.salaryStructureItem.deleteMany();
    await prisma.salaryStructure.deleteMany();
    await prisma.salaryComponent.deleteMany();
    await prisma.attendanceCorrection.deleteMany();
    await prisma.attendanceSession.deleteMany();
    await prisma.attendance.deleteMany();
    await prisma.holiday.deleteMany();
    await prisma.leaveRequest.deleteMany();
    await prisma.leaveBalance.deleteMany();
    await prisma.leaveType.deleteMany();
    await prisma.approvalAction.deleteMany();
    await prisma.approvalStep.deleteMany();
    await prisma.approvalRequest.deleteMany();
    await prisma.shift.deleteMany();
    await prisma.employment.deleteMany();
    await prisma.employee.deleteMany();
    await prisma.userRole.deleteMany();
    await prisma.rolePermission.deleteMany();
    await prisma.permission.deleteMany();
    await prisma.role.deleteMany();
    await prisma.auditLog.deleteMany();
    await prisma.branch.deleteMany();
    await prisma.user.deleteMany();
    await prisma.organization.deleteMany();

    const org = await prisma.organization.create({ data: { name: 'P1 Test Org', code: 'P1T', legal_name: 'P1 Org Ltd' } });
    orgId = org.id;

    const perms = await prisma.permission.createManyAndReturn({
      data: [
        { module: 'payroll', action: 'manage', code: 'payroll:manage' },
        { module: 'payroll', action: 'create', code: 'payroll:create' },
        { module: 'payroll', action: 'calculate', code: 'payroll:calculate' },
        { module: 'payroll', action: 'finalize', code: 'payroll:finalize' },
        { module: 'salary', action: 'manage', code: 'salary:manage' },
        { module: 'leave', action: 'manage', code: 'leave:manage' },
        { module: 'leave', action: 'create', code: 'leave:create' },
        { module: 'leave', action: 'view', code: 'leave:view' },
        { module: 'leave', action: 'approve', code: 'leave:approve' },
        { module: 'leave', action: 'cancel', code: 'leave:cancel' },
        { module: 'leave_type', action: 'create', code: 'leave_type:create' },
        { module: 'leave_type', action: 'view', code: 'leave_type:view' },
        { module: 'attendance', action: 'correction_create', code: 'attendance:correction:create' },
        { module: 'attendance', action: 'correction_approve', code: 'attendance:correction:approve' },
        { module: 'holiday', action: 'create', code: 'holiday:create' },
        { module: 'holiday', action: 'view', code: 'holiday:view' },
      ]
    });
    const permMap = Object.fromEntries(perms.map(p => [p.code, p]));
    
    const role = await prisma.role.create({ data: { organization_id: org.id, name: 'HR Admin', code: 'HRADMIN' } });
    await prisma.rolePermission.createMany({ data: perms.map(p => ({ role_id: role.id, permission_id: p.id })) });

    const hash = await argon2.hash(PASSWORD);
    const adminUser = await prisma.user.create({ data: { organization_id: org.id, email: 'admin@p1test.com', password_hash: hash, is_active: true } });
    await prisma.userRole.create({ data: { user_id: adminUser.id, role_id: role.id, scope_organization_id: org.id } });

    // Employee WITH daily salary structure
    const user1 = await prisma.user.create({ data: { organization_id: org.id, email: 'w1@p1test.com', password_hash: hash, is_active: true } });
    await prisma.userRole.create({ data: { user_id: user1.id, role_id: role.id, scope_organization_id: org.id } });
    const emp1 = await prisma.employee.create({ data: { organization_id: org.id, user_id: user1.id, emp_id: 'P1W01', first_name: 'Daily', last_name: 'Worker' } });
    await prisma.employment.create({ data: { employee_id: emp1.id, joining_date: new Date(), status: 'ACTIVE' } });
    empWithStructureId = emp1.id;

    // Employee WITHOUT salary structure (should trigger warning)
    const user2 = await prisma.user.create({ data: { organization_id: org.id, email: 'w2@p1test.com', password_hash: hash, is_active: true } });
    const emp2 = await prisma.employee.create({ data: { organization_id: org.id, user_id: user2.id, emp_id: 'P1W02', first_name: 'NoStructure', last_name: 'Worker' } });
    await prisma.employment.create({ data: { employee_id: emp2.id, joining_date: new Date(), status: 'ACTIVE' } });
    empWithoutStructureId = emp2.id;

    // Employee with MONTHLY salary structure
    const user3 = await prisma.user.create({ data: { organization_id: org.id, email: 'w3@p1test.com', password_hash: hash, is_active: true } });
    const emp3 = await prisma.employee.create({ data: { organization_id: org.id, user_id: user3.id, emp_id: 'P1W03', first_name: 'Monthly', last_name: 'Worker' } });
    await prisma.employment.create({ data: { employee_id: emp3.id, joining_date: new Date(), status: 'ACTIVE' } });
    empMonthlyId = emp3.id;

    // Employee for leave balance test
    const user4 = await prisma.user.create({ data: { organization_id: org.id, email: 'w4@p1test.com', password_hash: hash, is_active: true } });
    const emp4 = await prisma.employee.create({ data: { organization_id: org.id, user_id: user4.id, emp_id: 'P1W04', first_name: 'Leave', last_name: 'Tester' } });
    await prisma.employment.create({ data: { employee_id: emp4.id, joining_date: new Date(), status: 'ACTIVE', manager_id: emp4.id } });
    empForLeaveId = emp4.id;

    // Create salary components
    const basic = await prisma.salaryComponent.create({ data: { organization_id: org.id, name: 'Basic', code: 'BASIC_P1', type: 'EARNING', is_active: true } });
    const pf = await prisma.salaryComponent.create({ data: { organization_id: org.id, name: 'PF', code: 'PF_P1', type: 'STATUTORY', is_active: true } });
    basicComponentId = basic.id;
    pfComponentId = pf.id;

    // Daily structure for emp1
    await prisma.salaryStructure.create({
      data: {
        organization_id: org.id,
        employee_id: empWithStructureId,
        wage_basis: 'DAILY',
        effective_from: new Date(),
        status: 'ACTIVE',
        items: { create: [
          { salary_component_id: basicComponentId, amount: 700 },
          { salary_component_id: pfComponentId, amount: 50 }
        ]}
      }
    });

    // Monthly structure for emp3 — ₹30,000/month
    await prisma.salaryStructure.create({
      data: {
        organization_id: org.id,
        employee_id: empMonthlyId,
        wage_basis: 'MONTHLY',
        effective_from: new Date(),
        status: 'ACTIVE',
        items: { create: [
          { salary_component_id: basicComponentId, amount: 30000 },
          { salary_component_id: pfComponentId, amount: 100 }
        ]}
      }
    });

    // Create leave type
    const lt = await prisma.leaveType.create({ data: { organization_id: org.id, name: 'Annual', code: 'AL_P1', is_paid: true, annual_quota: 15 } });
    leaveTypeId = lt.id;
    
    // Create attendance for emp1 correction test
    const todayForTest = new Date();
    todayForTest.setDate(1); // 1st of current month
    todayForTest.setHours(0, 0, 0, 0);
    const att = await prisma.attendance.create({
      data: {
        organization_id: org.id,
        employee_id: empWithStructureId,
        date: todayForTest,
        status: 'ABSENT',
        total_worked_mins: 0
      }
    });
    attendanceIdForCorrectionTest = att.id;
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('1. Setup auth for P1 tests', async () => {
    const res = await request(app).get('/api/v1/auth/csrf');
    csrfToken = res.body.csrfToken;
    csrfCookie = res.headers['set-cookie'][0];

    const login = await request(app)
      .post('/api/v1/auth/login')
      .set('Cookie', csrfCookie).set('CSRF-Token', csrfToken)
      .send({ email: 'admin@p1test.com', password: PASSWORD });
    expect(login.status).toBe(200);
    const cookies = Array.isArray(login.headers['set-cookie']) ? login.headers['set-cookie'] : [login.headers['set-cookie']];
    authCookie = cookies.find((c: any) => typeof c === 'string' && c.startsWith('muster_session'))!.split(';')[0];
  });

  // -----------------------------------------------------------------------
  // P1-6: Leave balance allocation
  // -----------------------------------------------------------------------
  describe('P1-6: Leave balance allocation correctness', () => {
    it('Initial allocation of 10 days creates balance=10, remaining=10', async () => {
      const res = await request(app)
        .post('/api/v1/leaves/balances/allocate')
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken)
        .send({ employee_id: empForLeaveId, leave_type_id: leaveTypeId, year: 2026, allocated_balance: 10 });
      expect(res.status).toBe(200);
      expect(res.body.data.allocated_balance).toBe(10);
      expect(res.body.data.remaining_balance).toBe(10);
    });

    it('Re-allocation to 14 days: remaining increases by 4 (not 14)', async () => {
      const res = await request(app)
        .post('/api/v1/leaves/balances/allocate')
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken)
        .send({ employee_id: empForLeaveId, leave_type_id: leaveTypeId, year: 2026, allocated_balance: 14 });
      expect(res.status).toBe(200);
      expect(res.body.data.allocated_balance).toBe(14);
      expect(res.body.data.remaining_balance).toBe(14); // 10 + (14-10) = 14
    });

    it('Re-allocation to 12 days: remaining decreases by 2 (not resets to 12)', async () => {
      const res = await request(app)
        .post('/api/v1/leaves/balances/allocate')
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken)
        .send({ employee_id: empForLeaveId, leave_type_id: leaveTypeId, year: 2026, allocated_balance: 12 });
      expect(res.status).toBe(200);
      expect(res.body.data.allocated_balance).toBe(12);
      expect(res.body.data.remaining_balance).toBe(12); // 14 + (12-14) = 12
    });
  });

  // -----------------------------------------------------------------------
  // P1-1: Payroll warning for employees without salary structure
  // -----------------------------------------------------------------------
  describe('P1-1: Payroll excludes employees without salary structure with warning', () => {
    let periodId: string;
    let runId: string;

    it('Creates payroll period and run', async () => {
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);

      const r1 = await request(app)
        .post('/api/v1/payroll/periods')
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken)
        .send({ name: 'P1 Test Month', start_date: start.toISOString(), end_date: end.toISOString() });
      expect(r1.status).toBe(200);
      periodId = r1.body.data.id;

      const r2 = await request(app)
        .post('/api/v1/payroll/runs')
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken)
        .send({ payroll_period_id: periodId });
      expect(r2.status).toBe(200);
      runId = r2.body.data.id;
    });

    it('Calculation returns warning for employee without salary structure', async () => {
      const res = await request(app)
        .post(`/api/v1/payroll/runs/${runId}/calculate`)
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken);
      expect(res.status).toBe(200);

      // Warnings must be present for empWithoutStructureId
      expect(res.body.warnings).toBeDefined();
      expect(Array.isArray(res.body.warnings)).toBe(true);
      const w = res.body.warnings.find((w: any) => w.employee_id === empWithoutStructureId);
      expect(w).toBeDefined();
      expect(w.reason).toContain('No active salary structure');
    });

    it('Employee with structure gets calculated correctly (payroll item created)', async () => {
      const item = await prisma.payrollItem.findFirst({ where: { employee_id: empWithStructureId, payroll_run_id: runId } });
      expect(item).toBeDefined();
    });

    it('Employee without structure has NO payroll item (was skipped with warning, not silently)', async () => {
      const item = await prisma.payrollItem.findFirst({ where: { employee_id: empWithoutStructureId, payroll_run_id: runId } });
      expect(item).toBeNull();
    });

    // P1-3: Monthly employee with holidays should NOT get extra pay
    it('[P1-3] Monthly employee with 2 holidays in period does NOT get extra payable days', async () => {
      const now = new Date();
      const d1 = new Date(now.getFullYear(), now.getMonth(), 5);
      const d2 = new Date(now.getFullYear(), now.getMonth(), 6);

      // Seed 2 holidays in the period
      await prisma.holiday.createMany({
        data: [
          { organization_id: orgId, name: 'Test Holiday 1', date: d1, is_active: true },
          { organization_id: orgId, name: 'Test Holiday 2', date: d2, is_active: true }
        ]
      });

      // Seed 10 present attendance days for monthly employee
      for (let day = 10; day <= 19; day++) {
        await prisma.attendance.create({
          data: {
            organization_id: orgId,
            employee_id: empMonthlyId,
            date: new Date(now.getFullYear(), now.getMonth(), day),
            status: 'PRESENT',
            total_worked_mins: 480
          }
        });
      }

      // Recalculate the same run
      const res = await request(app)
        .post(`/api/v1/payroll/runs/${runId}/calculate`)
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken);
      expect(res.status).toBe(200);

      const monthlyItem = await prisma.payrollItem.findFirst({ where: { employee_id: empMonthlyId, payroll_run_id: runId } });
      expect(monthlyItem).toBeDefined();
      // Should have exactly 10 payable days — holidays NOT added for monthly
      expect(monthlyItem!.payable_days).toBe(10);
    });
  });

  // -----------------------------------------------------------------------
  // P1-5: Finalized payroll prevents attendance corrections
  // -----------------------------------------------------------------------
  describe('P1-5: Finalized payroll immutability', () => {
    let runId2: string;

    it('Creates and finalizes a payroll run', async () => {
      const now = new Date();
      // Use a specific past month for this test
      const start = new Date(2026, 0, 1); // Jan 2026
      const end = new Date(2026, 0, 31);

      // Create attendance on Jan 3rd for the test employee
      await prisma.attendance.create({
        data: {
          organization_id: orgId,
          employee_id: empWithStructureId,
          date: new Date(2026, 0, 3),
          status: 'PRESENT',
          total_worked_mins: 480
        }
      });

      const r1 = await request(app)
        .post('/api/v1/payroll/periods')
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken)
        .send({ name: 'January 2026', start_date: start.toISOString(), end_date: end.toISOString() });
      expect(r1.status).toBe(200);

      const r2 = await request(app)
        .post('/api/v1/payroll/runs')
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken)
        .send({ payroll_period_id: r1.body.data.id });
      expect(r2.status).toBe(200);
      runId2 = r2.body.data.id;

      await request(app)
        .post(`/api/v1/payroll/runs/${runId2}/calculate`)
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken);

      // Finalize
      const finRes = await request(app)
        .post(`/api/v1/payroll/runs/${runId2}/finalize`)
        .set('Cookie', [`${csrfCookie}`, `${authCookie}`]).set('CSRF-Token', csrfToken);
      expect(finRes.status).toBe(200);
      expect(finRes.body.data.status).toBe('FINALIZED');
    });

    it('[P1-5] Submitting attendance correction for date in finalized period returns 400', async () => {
      const jan3Att = await prisma.attendance.findFirst({
        where: { employee_id: empWithStructureId, date: new Date(2026, 0, 3), organization_id: orgId }
      });
      expect(jan3Att).toBeDefined();

      // Use w1's own auth cookie (empWithStructure is linked to w1@p1test.com)
      const w1Login = await request(app)
        .post('/api/v1/auth/login')
        .set('Cookie', csrfCookie).set('CSRF-Token', csrfToken)
        .send({ email: 'w1@p1test.com', password: PASSWORD });
      expect(w1Login.status).toBe(200);
      const w1Cookies = Array.isArray(w1Login.headers['set-cookie']) ? w1Login.headers['set-cookie'] : [w1Login.headers['set-cookie']];
      const w1Cookie = w1Cookies.find((c: any) => typeof c === 'string' && c.startsWith('muster_session'))!.split(';')[0];

      const res = await request(app)
        .post('/api/v1/attendance/corrections')
        .set('Cookie', [`${csrfCookie}`, `${w1Cookie}`]).set('CSRF-Token', csrfToken)
        .send({
          attendance_id: jan3Att!.id,
          requested_status: 'PRESENT',
          requested_check_in: new Date(2026, 0, 3, 9, 0, 0).toISOString(),
          requested_check_out: new Date(2026, 0, 3, 18, 0, 0).toISOString(),
          reason: 'Testing finalized period protection'
        });

      expect(res.status).toBe(400);
      expect(res.body.error).toContain('finalized payroll period');
    });
  });
});

