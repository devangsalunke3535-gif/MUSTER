import { Prisma } from '@prisma/client';
import { badRequest } from '../utils/http';
import { isUuid } from '../utils/http';

export type ShiftType = 'DAY' | 'NIGHT' | 'OTHER' | 'UNASSIGNED';

/** Classify a shift by its name. Never infers from attendance, never defaults to DAY. */
export function classifyShift(shift: { name?: string | null } | null | undefined): ShiftType {
  if (!shift) return 'UNASSIGNED';
  const n = (shift.name || '').toLowerCase();
  if (n.includes('night')) return 'NIGHT';
  if (n.includes('day')) return 'DAY';
  return 'OTHER';
}

export const ACTIVE_EMPLOYMENT_STATUSES = ['ACTIVE', 'PROBATION'];
export const EMPLOYMENT_STATUSES = ['ACTIVE', 'PROBATION', 'INACTIVE', 'TERMINATED'];

/** The include used wherever an employee DTO is produced. */
export const employeeDtoInclude = {
  employment: true,
  assignmentHistory: {
    where: { effective_to: null },
    orderBy: { effective_from: 'desc' as const },
    take: 1,
    include: { branch: true, department: true, designation: true }
  },
  salaryStructures: {
    where: { status: 'ACTIVE' },
    orderBy: { effective_from: 'desc' as const },
    take: 1,
    include: { items: { include: { component: true } } }
  },
  statutoryProfile: true,
  defaultShift: true,
};

/**
 * Server-computed view of an employee. The frontend renders these fields
 * directly instead of re-deriving them from nested relations — that
 * re-derivation (reading `salaryComponent` where the API returns `component`)
 * is what previously made every saved wage display as "—".
 *
 * Missing data is reported as null, never invented.
 */
export function toEmployeeDTO(emp: any) {
  const structure = emp.salaryStructures?.[0] || null;
  const basic = structure?.items?.find((i: any) => i.component?.code === 'BASIC') || null;
  const assignment = emp.assignmentHistory?.[0] || null;
  const shift = emp.defaultShift || null;

  // Encrypted statutory data is never returned; only whether it is present.
  const { statutoryProfile, salaryStructures, assignmentHistory, ...rest } = emp;

  return {
    ...rest,
    full_name: `${emp.first_name || ''} ${emp.last_name || ''}`.trim(),
    status: emp.employment?.status || null,
    joining_date: emp.employment?.joining_date || null,
    manager_id: emp.employment?.manager_id || null,
    branch: assignment?.branch ? { id: assignment.branch.id, name: assignment.branch.name } : null,
    department: assignment?.department ? { id: assignment.department.id, name: assignment.department.name } : null,
    designation: assignment?.designation ? { id: assignment.designation.id, title: assignment.designation.title } : null,
    shift: shift ? { id: shift.id, name: shift.name, type: classifyShift(shift), start_time: shift.start_time, end_time: shift.end_time } : null,
    shift_type: classifyShift(shift),
    wage: structure
      ? { basis: structure.wage_basis, amount: basic ? basic.amount : null, structure_id: structure.id }
      : null,
    daily_wage: structure?.wage_basis === 'DAILY' && basic ? basic.amount : null,
    has_uan: !!statutoryProfile?.uan_enc,
    has_esi: !!statutoryProfile?.esi_number_enc,
  };
}

/**
 * Resolve the requested shift to a UUID in the caller's organization.
 *
 * Accepts a shift UUID, or a keyword ("day" / "night" / a shift name).
 * "unassigned" / "" / null explicitly clears the shift. `undefined` means
 * "not provided" and returns undefined so callers leave the value unchanged.
 *
 * Every lookup is scoped by organization_id. An unknown or ambiguous shift is a
 * 400 — we never silently fall back to some other shift.
 */
export async function resolveShiftId(
  tx: Prisma.TransactionClient,
  orgId: string,
  input: unknown
): Promise<string | null | undefined> {
  if (input === undefined) return undefined;
  if (input === null) return null;
  if (typeof input !== 'string') throw badRequest('Shift must be a shift ID or name');
  const v = input.trim();
  if (v === '' || v.toLowerCase() === 'unassigned' || v === '—') return null;

  if (isUuid(v)) {
    const s = await tx.shift.findFirst({ where: { id: v, organization_id: orgId } });
    if (!s) throw badRequest('Shift not found in your organization');
    if (!s.is_active) throw badRequest(`Shift "${s.name}" is inactive`);
    return s.id;
  }

  const shifts = await tx.shift.findMany({ where: { organization_id: orgId, is_active: true } });
  const key = v.toLowerCase();
  const exact = shifts.filter((s: any) => s.name.toLowerCase() === key);
  const matches = exact.length ? exact
    : shifts.filter((s: any) => {
        const t = classifyShift(s);
        return (key === 'day' && t === 'DAY') || (key === 'night' && t === 'NIGHT');
      });
  if (matches.length === 0) throw badRequest(`No active "${v}" shift is configured for your organization`);
  if (matches.length > 1) throw badRequest(`"${v}" matches more than one shift; select a specific shift`);
  return matches[0].id;
}

/** Validate org-structure IDs belong to the caller's organization (and to each other). */
export async function validateOrgStructure(
  tx: Prisma.TransactionClient,
  orgId: string,
  ids: { branch_id?: unknown; department_id?: unknown; designation_id?: unknown; manager_id?: unknown },
  selfEmployeeId?: string
) {
  const out: { branch_id?: string | null; department_id?: string | null; designation_id?: string | null; manager_id?: string | null } = {};

  const norm = (v: unknown, field: string): string | null | undefined => {
    if (v === undefined) return undefined;
    if (v === null || v === '') return null;
    if (!isUuid(v)) throw badRequest(`${field} must be a valid UUID`);
    return v as string;
  };

  const branchId = norm(ids.branch_id, 'branch_id');
  const departmentId = norm(ids.department_id, 'department_id');
  const designationId = norm(ids.designation_id, 'designation_id');
  const managerId = norm(ids.manager_id, 'manager_id');

  if (branchId) {
    const b = await tx.branch.findFirst({ where: { id: branchId, organization_id: orgId } });
    if (!b) throw badRequest('Branch not found in your organization');
  }
  if (departmentId) {
    const d = await tx.department.findFirst({ where: { id: departmentId, branch: { organization_id: orgId } } });
    if (!d) throw badRequest('Department not found in your organization');
    if (branchId && d.branch_id !== branchId) throw badRequest('Department does not belong to the selected branch');
  }
  if (designationId) {
    const g = await tx.designation.findFirst({ where: { id: designationId, department: { branch: { organization_id: orgId } } } });
    if (!g) throw badRequest('Designation not found in your organization');
    if (departmentId && g.department_id !== departmentId) throw badRequest('Designation does not belong to the selected department');
  }
  if (managerId) {
    if (selfEmployeeId && managerId === selfEmployeeId) throw badRequest('An employee cannot be their own manager');
    const m = await tx.employee.findFirst({ where: { id: managerId, organization_id: orgId } });
    if (!m) throw badRequest('Manager not found in your organization');
  }

  out.branch_id = branchId; out.department_id = departmentId; out.designation_id = designationId; out.manager_id = managerId;
  return out;
}

/** Next sequential employee code (W-1001, W-1002, ...) for an organization. */
export async function nextEmpId(tx: Prisma.TransactionClient, orgId: string): Promise<string> {
  const rows = await tx.employee.findMany({
    where: { organization_id: orgId, emp_id: { startsWith: 'W-' } },
    select: { emp_id: true }
  });
  let max = 1000;
  for (const r of rows) {
    const n = parseInt(String(r.emp_id).slice(2), 10);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return `W-${max + 1}`;
}

/**
 * Set (create or update) the employee's DAILY wage on the active BASIC component.
 * Refuses to silently convert a MONTHLY/HOURLY structure into a daily one.
 */
export async function setDailyWage(tx: Prisma.TransactionClient, orgId: string, employeeId: string, amount: number, effectiveFrom: Date) {
  let basicComp = await tx.salaryComponent.findFirst({ where: { organization_id: orgId, code: 'BASIC' } });
  if (!basicComp) {
    basicComp = await tx.salaryComponent.create({
      data: { organization_id: orgId, name: 'Basic', code: 'BASIC', type: 'EARNING', is_active: true }
    });
  } else if (!basicComp.is_active) {
    throw badRequest('The BASIC salary component is inactive; re-activate it in Salary Config first');
  }

  const active = await tx.salaryStructure.findFirst({
    where: { employee_id: employeeId, organization_id: orgId, status: 'ACTIVE' },
    orderBy: { effective_from: 'desc' },
    include: { items: true }
  });

  if (!active) {
    await tx.salaryStructure.create({
      data: {
        organization_id: orgId, employee_id: employeeId, wage_basis: 'DAILY', effective_from: effectiveFrom, status: 'ACTIVE',
        items: { create: [{ salary_component_id: basicComp.id, amount }] }
      }
    });
    return;
  }
  if (active.wage_basis !== 'DAILY') {
    throw badRequest(`This employee is paid on a ${active.wage_basis} basis; change the salary structure instead of the daily wage`);
  }
  const item = active.items.find((i: any) => i.salary_component_id === basicComp!.id);
  if (item) {
    await tx.salaryStructureItem.update({ where: { id: item.id }, data: { amount } });
  } else {
    await tx.salaryStructureItem.create({ data: { salary_structure_id: active.id, salary_component_id: basicComp.id, amount } });
  }
}
