import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { auditLog } from '../middleware/audit.middleware';
import { encrypt, decrypt, maskData } from '../utils/crypto';
import { sendError, badRequest, notFound, parseDateOnly, parsePositiveNumber, optionalString, todayIST, isUuid } from '../utils/http';
import { getScopedBranchIds, branchScopeWhere, getEmployeeInScope } from '../utils/access';
import {
  employeeDtoInclude, toEmployeeDTO, resolveShiftId, validateOrgStructure, nextEmpId, setDailyWage,
  ACTIVE_EMPLOYMENT_STATUSES, EMPLOYMENT_STATUSES
} from '../services/employee.service';

const router = Router();

// GET /api/v1/employees/me — the authenticated user's own profile (self-service).
// Registered before /:id so "me" is never treated as an ID.
router.get('/me', async (req: Request, res: Response) => {
  try {
    const emp = await prisma.employee.findFirst({
      where: { user_id: req.authContext!.userId, organization_id: req.authContext!.organizationId },
      include: employeeDtoInclude
    });
    res.json({ data: emp ? toEmployeeDTO(emp) : null });
  } catch (e) {
    sendError(res, e, 'Load own profile');
  }
});

// GET /api/v1/employees?status=active|inactive|all
router.get('/', requirePermission('employee:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = Math.min(1000, Math.max(1, parseInt(req.query.limit as string) || 500));
    const statusFilter = String(req.query.status || 'active');

    const branchIds = await getScopedBranchIds(req.authContext!.userId, orgId);
    const where: any = { organization_id: orgId, ...branchScopeWhere(branchIds) };
    if (statusFilter === 'active') where.employment = { status: { in: ACTIVE_EMPLOYMENT_STATUSES } };
    else if (statusFilter === 'inactive') where.employment = { status: { notIn: ACTIVE_EMPLOYMENT_STATUSES } };
    else if (statusFilter !== 'all') throw badRequest('status must be active, inactive or all');

    const [employees, total] = await Promise.all([
      prisma.employee.findMany({
        where,
        include: employeeDtoInclude,
        orderBy: [{ first_name: 'asc' }, { last_name: 'asc' }],
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.employee.count({ where })
    ]);

    res.json({ data: employees.map(toEmployeeDTO), meta: { total, page, limit } });
  } catch (error) {
    sendError(res, error, 'List employees');
  }
});

// GET /api/v1/employees/:id
router.get('/:id', requirePermission('employee:view'), async (req: Request, res: Response) => {
  try {
    const id = String(req.params.id);
    if (!isUuid(id)) throw notFound('Employee not found');
    await getEmployeeInScope(req.authContext!.userId, req.authContext!.organizationId, id);
    const emp = await prisma.employee.findUnique({ where: { id }, include: employeeDtoInclude });
    res.json({ data: toEmployeeDTO(emp) });
  } catch (e) {
    sendError(res, e, 'Load employee');
  }
});

// POST /api/v1/employees
router.post('/', requirePermission('employee:create'), auditLog('CREATE', 'Employee'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const body = req.body || {};

    const first_name = optionalString(body.first_name, 'first_name', 100);
    if (!first_name) throw badRequest('first_name is required');
    const last_name = optionalString(body.last_name, 'last_name', 100) ?? '';
    const phone = optionalString(body.phone, 'phone', 20) || null;
    const email = optionalString(body.email, 'email') || null;
    const gender = optionalString(body.gender, 'gender', 20) || null;
    const dob = body.dob ? parseDateOnly(body.dob, 'dob') : null;
    const joiningDate = body.joining_date ? parseDateOnly(body.joining_date, 'joining_date') : todayIST();
    const status = body.status ? String(body.status).toUpperCase() : 'ACTIVE';
    if (!EMPLOYMENT_STATUSES.includes(status)) throw badRequest(`status must be one of ${EMPLOYMENT_STATUSES.join(', ')}`);
    const dailyWage = body.daily_wage === undefined || body.daily_wage === null || body.daily_wage === ''
      ? null : parsePositiveNumber(body.daily_wage, 'daily_wage', { max: 1_000_000 });
    const requestedEmpId = optionalString(body.emp_id, 'emp_id', 50) || null;

    const created = await prisma.$transaction(async (tx: any) => {
      const structure = await validateOrgStructure(tx, orgId, body);

      // A branch-scoped manager must be able to see the worker they just created,
      // so an unspecified branch defaults to the creator's branch (or HQ).
      let branchId = structure.branch_id ?? null;
      if (!branchId) {
        const scoped = await getScopedBranchIds(userId, orgId);
        if (scoped.length === 1) branchId = scoped[0];
        else {
          const hq = await tx.branch.findFirst({ where: { organization_id: orgId, is_headquarters: true } });
          branchId = hq?.id ?? null;
        }
      } else {
        const scoped = await getScopedBranchIds(userId, orgId);
        if (scoped.length > 0 && !scoped.includes(branchId)) throw badRequest('You cannot create employees outside your branch');
      }

      const shiftId = await resolveShiftId(tx, orgId, body.default_shift_id ?? body.default_shift);
      const empCode = requestedEmpId || await nextEmpId(tx, orgId);

      const emp = await tx.employee.create({
        data: {
          organization_id: orgId,
          emp_id: empCode, first_name, last_name, email, phone, gender, dob,
          default_shift_id: shiftId ?? null,
          employment: { create: { joining_date: joiningDate, status, manager_id: structure.manager_id ?? null } },
          statusHistory: { create: { status, effective_from: joiningDate, reason: 'Initial joining' } },
          assignmentHistory: {
            create: {
              branch_id: branchId,
              department_id: structure.department_id ?? null,
              designation_id: structure.designation_id ?? null,
              effective_from: joiningDate
            }
          }
        }
      });

      if (dailyWage !== null) await setDailyWage(tx, orgId, emp.id, dailyWage, joiningDate);

      return tx.employee.findUnique({ where: { id: emp.id }, include: employeeDtoInclude });
    });

    res.json({ data: toEmployeeDTO(created) });
  } catch (error: any) {
    if (error?.code === 'P2002') return res.status(409).json({ error: 'An employee with this employee code already exists' });
    sendError(res, error, 'Create employee');
  }
});

// PUT /api/v1/employees/:id
// Supported: first_name, last_name, phone, email, daily_wage, default_shift(_id), status, branch_id, manager_id
router.put('/:id', requirePermission('employee:update'), auditLog('UPDATE', 'Employee'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const userId = req.authContext!.userId;
    const id = String(req.params.id);
    if (!isUuid(id)) throw notFound('Employee not found');
    const existing = await getEmployeeInScope(userId, orgId, id);
    const body = req.body || {};

    const data: any = {};
    const first_name = optionalString(body.first_name, 'first_name', 100);
    if (first_name !== undefined) { if (!first_name) throw badRequest('first_name cannot be empty'); data.first_name = first_name; }
    const last_name = optionalString(body.last_name, 'last_name', 100);
    if (last_name !== undefined) data.last_name = last_name;
    const phone = optionalString(body.phone, 'phone', 20);
    if (phone !== undefined) data.phone = phone || null;
    const email = optionalString(body.email, 'email');
    if (email !== undefined) data.email = email || null;

    const dailyWage = body.daily_wage === undefined || body.daily_wage === null || body.daily_wage === ''
      ? undefined : parsePositiveNumber(body.daily_wage, 'daily_wage', { max: 1_000_000 });
    const newStatus = body.status === undefined ? undefined : String(body.status).toUpperCase();
    if (newStatus !== undefined && !EMPLOYMENT_STATUSES.includes(newStatus)) {
      throw badRequest(`status must be one of ${EMPLOYMENT_STATUSES.join(', ')}`);
    }

    const updated = await prisma.$transaction(async (tx: any) => {
      const structure = await validateOrgStructure(tx, orgId, { branch_id: body.branch_id, manager_id: body.manager_id }, id);

      const shiftInput = body.default_shift_id !== undefined ? body.default_shift_id : body.default_shift;
      const shiftId = await resolveShiftId(tx, orgId, shiftInput);
      if (shiftId !== undefined) data.default_shift_id = shiftId;

      if (Object.keys(data).length) await tx.employee.update({ where: { id }, data });

      if (dailyWage !== undefined) await setDailyWage(tx, orgId, id, dailyWage, todayIST());

      if (structure.manager_id !== undefined && existing.employment) {
        await tx.employment.update({ where: { employee_id: id }, data: { manager_id: structure.manager_id } });
      }

      if (newStatus !== undefined && existing.employment && existing.employment.status !== newStatus) {
        await changeEmploymentStatus(tx, id, existing.user_id, newStatus, 'Updated from directory');
      }

      if (structure.branch_id !== undefined) {
        const scoped = await getScopedBranchIds(userId, orgId);
        if (structure.branch_id && scoped.length > 0 && !scoped.includes(structure.branch_id)) {
          throw badRequest('You cannot move employees outside your branch');
        }
        const current = await tx.employeeAssignmentHistory.findFirst({
          where: { employee_id: id, effective_to: null }, orderBy: { effective_from: 'desc' }
        });
        if ((current?.branch_id ?? null) !== structure.branch_id) {
          const today = todayIST();
          if (current) await tx.employeeAssignmentHistory.update({ where: { id: current.id }, data: { effective_to: today } });
          await tx.employeeAssignmentHistory.create({
            data: {
              employee_id: id,
              branch_id: structure.branch_id,
              // department/designation belong to a branch; they do not carry over on a branch move
              department_id: current && current.branch_id === structure.branch_id ? current.department_id : null,
              designation_id: current && current.branch_id === structure.branch_id ? current.designation_id : null,
              effective_from: today
            }
          });
        }
      }

      return tx.employee.findUnique({ where: { id }, include: employeeDtoInclude });
    });

    res.json({ data: toEmployeeDTO(updated) });
  } catch (e) {
    sendError(res, e, 'Update employee');
  }
});

// DELETE /api/v1/employees/:id
// Deactivates — never hard-deletes. A hard delete would cascade through
// attendance, leave, loans and finalized payroll items (all onDelete: Cascade).
router.delete('/:id', requirePermission('employee:delete'), auditLog('DELETE', 'Employee'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const id = String(req.params.id);
    if (!isUuid(id)) throw notFound('Employee not found');
    const emp = await getEmployeeInScope(req.authContext!.userId, orgId, id);
    const self = await prisma.employee.findFirst({ where: { user_id: req.authContext!.userId, organization_id: orgId } });
    if (self && self.id === emp.id) throw badRequest('You cannot deactivate your own profile');

    await prisma.$transaction(async (tx: any) => {
      if (!emp.employment) throw badRequest('Employee has no employment record');
      if (emp.employment.status !== 'INACTIVE' && emp.employment.status !== 'TERMINATED') {
        await changeEmploymentStatus(tx, emp.id, emp.user_id, 'INACTIVE', 'Deactivated from directory');
      }
    });
    res.json({ data: { success: true, status: 'INACTIVE' } });
  } catch (e) {
    sendError(res, e, 'Deactivate employee');
  }
});

/** Record a status change in history and keep the login account in sync. */
async function changeEmploymentStatus(tx: any, employeeId: string, userId: string | null, status: string, reason: string) {
  const today = todayIST();
  await tx.employment.update({ where: { employee_id: employeeId }, data: { status } });
  await tx.employeeStatusHistory.updateMany({ where: { employee_id: employeeId, effective_to: null }, data: { effective_to: today } });
  await tx.employeeStatusHistory.create({ data: { employee_id: employeeId, status, effective_from: today, reason } });
  if (userId) {
    await tx.user.update({ where: { id: userId }, data: { is_active: ['ACTIVE', 'PROBATION'].includes(status) } });
  }
}

// GET /api/v1/employees/:id/bank
router.get('/:id/bank', requirePermission('employee:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employeeId = req.params.id as string;

    // Ensure employee belongs to org
    if (!isUuid(employeeId)) return res.status(404).json({ error: 'Employee not found' });
    await getEmployeeInScope(req.authContext!.userId, orgId, employeeId);

    const bankAccount = await prisma.employeeBankAccount.findFirst({ where: { employee_id: employeeId } });
    if (!bankAccount) return res.json({ data: null });

    // Check if user has permission to view unmasked banking data
    const userRoles = await prisma.userRole.findMany({
      where: { user_id: req.authContext!.userId, scope_organization_id: orgId },
      include: { role: { include: { rolePermissions: { include: { permission: true } } } } }
    });
    
    const canViewUnmasked = userRoles.some((ur: any) => ur.role.rolePermissions.some((rp: any) => rp.permission.code === 'employee:bank:view'));
    
    const decryptedAccount = decrypt(bankAccount.account_number_enc);
    
    res.json({
      data: {
        ...bankAccount,
        account_number: canViewUnmasked ? decryptedAccount : maskData(decryptedAccount),
        account_number_enc: undefined // do not leak encrypted hash
      }
    });
  } catch (error) {
    sendError(res, error, 'Load bank details');
  }
});

// POST /api/v1/employees/:id/bank
router.post('/:id/bank', requirePermission('employee:bank:update'), auditLog('UPDATE', 'EmployeeBankAccount'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employeeId = req.params.id as string;
    const { bank_name, branch_name, account_number, ifsc_code, account_type } = req.body || {};
    if (!bank_name || !branch_name || !account_number || !ifsc_code || !account_type) {
      return res.status(400).json({ error: 'bank_name, branch_name, account_number, ifsc_code and account_type are required' });
    }

    if (!isUuid(employeeId)) return res.status(404).json({ error: 'Employee not found' });
    await getEmployeeInScope(req.authContext!.userId, orgId, employeeId);

    const encryptedAccount = encrypt(account_number);

    const bank = await prisma.employeeBankAccount.create({
      data: {
        employee_id: employeeId,
        bank_name,
        branch_name,
        account_number_enc: encryptedAccount,
        ifsc_code,
        account_type,
      }
    });

    res.json({ data: { id: bank.id, message: 'Bank details saved successfully' } });
  } catch (error) {
    sendError(res, error, 'Save bank details');
  }
});

export default router;
