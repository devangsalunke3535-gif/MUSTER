const dotenv = require('dotenv');

// Load the TEST environment before anything else, overriding any shell values.
dotenv.config({ path: '.env.test', override: true });
process.env.NODE_ENV = 'test';

module.exports = {
  // Equivalent to preset: 'ts-jest' (which Jest 30's preset resolver can fail to locate).
  transform: { '^.+\.tsx?$': 'ts-jest' },
  testEnvironment: 'node',
  testMatch: ['**/__tests__/**/*.test.ts'],
  // Runs in every test worker before any test file is loaded.
  setupFiles: ['<rootDir>/jest.db-guard.js'],
  // Tests share one database and wipe it in beforeAll: never run files in parallel.
  maxWorkers: 1,
};
