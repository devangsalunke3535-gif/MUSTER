import { CORS_ORIGIN, JWT_SECRET, PORT, isProd, isTest } from './config/env'; // must be first: loads .env
import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import csurf from 'csurf';
import * as argon2 from 'argon2';
import jwt from 'jsonwebtoken';
import { prisma } from './config/db';
import { authenticate, SESSION_COOKIE, isSessionValid } from './middleware/auth.middleware';
import { isolateTenant } from './middleware/tenant.middleware';
import { requirePermission, requireActiveUser } from './middleware/rbac.middleware';
import { auditLog } from './middleware/audit.middleware';
import { sendError, badRequest, optionalString } from './utils/http';

import employeeRoutes from './routes/employee.routes';
import shiftRoutes from './routes/shift.routes';
import attendanceRoutes from './routes/attendance.routes';
import holidayRoutes from './routes/holiday.routes';
import leaveRoutes from './routes/leave.routes';
import salaryRoutes from './routes/salary.routes';
import loanRoutes from './routes/loan.routes';
import payrollRoutes from './routes/payroll.routes';
import dashboardRoutes from './routes/dashboard.routes';

const app = express();

app.use(helmet());
app.use(cors({ origin: CORS_ORIGIN, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

const csrfProtection = csurf({
  cookie: { httpOnly: true, secure: isProd, sameSite: isProd ? 'strict' : 'lax' }
});

const sessionCookieOptions = {
  httpOnly: true,
  secure: isProd,
  sameSite: (isProd ? 'strict' : 'lax') as 'strict' | 'lax',
  path: '/',
};

app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 1000 }));

// Brute-force protection. Production is strict; dev is relaxed for iteration.
const loginLimiter = rateLimit({
  windowMs: isProd ? 15 * 60 * 1000 : 60 * 1000,
  max: isProd ? 5 : 50,
  message: { error: `Too many login attempts, please try again after ${isProd ? '15 minutes' : '1 minute'}` }
});

app.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

app.get('/api/v1/auth/csrf', csrfProtection, (req: Request, res: Response) => {
  res.json({ csrfToken: req.csrfToken() });
});

/**
 * Single source of truth for the authenticated-user payload. Both /auth/login
 * and /auth/me return exactly this shape, so the frontend never sees two
 * different contracts.
 *
 *  - permissions: flat, de-duplicated permission codes (what the UI should use)
 *  - roles:       role codes (e.g. SUPER_ADMIN, SITE_MANAGER, WORKER)
 *  - userRoles:   legacy nested shape, kept for backward compatibility. Each role
 *                 carries BOTH `permissions` and `rolePermissions` (same data).
 */
async function buildUserPayload(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      organization: true,
      employee: true,
      userRoles: { include: { role: { include: { rolePermissions: { include: { permission: true } } } } } }
    }
  });
  if (!user || !user.is_active) return null;

  const userRoles = user.userRoles.filter((ur: any) => ur.role.organization_id === user.organization_id);
  const permissions = new Set<string>();
  for (const ur of userRoles) for (const rp of ur.role.rolePermissions) permissions.add(rp.permission.code);

  return {
    id: user.id,
    email: user.email,
    is_super_admin: user.is_super_admin,
    organization: { id: user.organization.id, name: user.organization.name, code: user.organization.code },
    employee: user.employee
      ? { id: user.employee.id, emp_id: user.employee.emp_id, first_name: user.employee.first_name, last_name: user.employee.last_name }
      : null,
    roles: Array.from(new Set(userRoles.map((ur: any) => ur.role.code as string))),
    permissions: Array.from(permissions).sort(),
    userRoles: userRoles.map((ur: any) => ({
      id: ur.id,
      role_id: ur.role_id,
      scope_organization_id: ur.scope_organization_id,
      scope_branch_id: ur.scope_branch_id,
      scope_department_id: ur.scope_department_id,
      role: {
        id: ur.role.id,
        name: ur.role.name,
        code: ur.role.code,
        permissions: ur.role.rolePermissions,
        rolePermissions: ur.role.rolePermissions,
      }
    })),
  };
}

// Multi-tenant aware login: the same email may exist in several organizations.
// If the password matches accounts in more than one org we refuse with 409
// rather than guess which org the user meant.
app.post('/api/v1/auth/login', loginLimiter, csrfProtection, async (req: Request, res: Response) => {
  try {
    const email = typeof req.body?.email === 'string' ? req.body.email.trim() : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const users = await prisma.user.findMany({
      where: { email: { equals: email, mode: 'insensitive' }, is_active: true },
    });

    const authenticated: any[] = [];
    for (const candidate of users) {
      try {
        if (await argon2.verify(candidate.password_hash, password)) authenticated.push(candidate);
      } catch {
        // Malformed hash — treat as non-matching. Never log the hash.
      }
    }

    if (authenticated.length === 0) return res.status(401).json({ error: 'Invalid credentials' });
    if (authenticated.length > 1) {
      return res.status(409).json({
        error: 'Multiple accounts found with this email. Please contact your administrator to log in with your organization code.'
      });
    }

    const user = authenticated[0];
    const token = jwt.sign({ userId: user.id, organizationId: user.organization_id, tv: user.token_version }, JWT_SECRET, { expiresIn: '8h' });
    res.cookie(SESSION_COOKIE, token, { ...sessionCookieOptions, maxAge: 8 * 60 * 60 * 1000 });

    await prisma.user.update({ where: { id: user.id }, data: { last_login_at: new Date() } });
    const payload = await buildUserPayload(user.id);
    res.json({ message: 'Login successful', user: payload });
  } catch (err) {
    sendError(res, err, 'Login');
  }
});

// Logout must work even when the session token has already expired, otherwise
// a stale cookie could never be cleared. CSRF still protects it.
// Logout also REVOKES the token server-side (token_version bump), so a copied
// token cannot be replayed after logout. Note: this ends the user's sessions on
// all devices, which is the conservative choice for a payroll system.
app.post('/api/v1/auth/logout', csrfProtection, async (req: Request, res: Response) => {
  try {
    const token = req.cookies?.[SESSION_COOKIE];
    if (token) {
      try {
        const decoded = jwt.verify(token, JWT_SECRET, { ignoreExpiration: true }) as { userId?: string; tv?: number };
        if (decoded?.userId) {
          await prisma.user.updateMany({
            where: { id: decoded.userId, token_version: decoded.tv ?? 0 },
            data: { token_version: { increment: 1 } }
          });
        }
      } catch {
        // Invalid signature: nothing to revoke; still clear the cookie.
      }
    }
    res.clearCookie(SESSION_COOKIE, sessionCookieOptions);
    res.json({ message: 'Logged out' });
  } catch (e) {
    res.clearCookie(SESSION_COOKIE, sessionCookieOptions);
    sendError(res, e, 'Logout');
  }
});

app.get('/api/v1/auth/me', csrfProtection, authenticate, async (req: Request, res: Response) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.authContext!.userId } });
    if (!isSessionValid(user, req.authContext)) {
      res.clearCookie(SESSION_COOKIE, sessionCookieOptions);
      return res.status(401).json({ error: 'Not authenticated' });
    }
    res.json({ user: await buildUserPayload(user!.id) });
  } catch (e) {
    sendError(res, e, 'Load current user');
  }
});

app.post('/api/v1/auth/change-password', loginLimiter, csrfProtection, authenticate, async (req: Request, res: Response) => {
  try {
    const { current_password, new_password } = req.body || {};
    if (typeof current_password !== 'string' || typeof new_password !== 'string') {
      throw badRequest('current_password and new_password are required');
    }
    if (new_password.length < 8) throw badRequest('New password must be at least 8 characters');

    const user = await prisma.user.findUnique({ where: { id: req.authContext!.userId } });
    if (!user || !isSessionValid(user, req.authContext)) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    let valid = false;
    try { valid = await argon2.verify(user.password_hash, current_password); } catch { valid = false; }
    if (!valid) return res.status(400).json({ error: 'Current password is incorrect' });

    // Revoke every existing session, then issue a fresh token for this browser.
    const updated = await prisma.user.update({
      where: { id: user.id },
      data: { password_hash: await argon2.hash(new_password), token_version: { increment: 1 } }
    });
    const token = jwt.sign({ userId: updated.id, organizationId: updated.organization_id, tv: updated.token_version }, JWT_SECRET, { expiresIn: '8h' });
    res.cookie(SESSION_COOKIE, token, { ...sessionCookieOptions, maxAge: 8 * 60 * 60 * 1000 });
    res.json({ message: 'Password changed. Other sessions have been signed out.' });
  } catch (e) {
    sendError(res, e, 'Change password');
  }
});

// ---------------------------------------------------------------------------
// Protected API — every route below is CSRF-protected, authenticated, and
// tenant-isolated. organization_id always comes from req.authContext.
// ---------------------------------------------------------------------------
const apiRouter = express.Router();
apiRouter.use(csrfProtection);
apiRouter.use(authenticate);
apiRouter.use(isolateTenant);

apiRouter.get('/organization', requirePermission('org:view'), async (req: Request, res: Response) => {
  try {
    const org = await prisma.organization.findUnique({ where: { id: req.authContext!.organizationId } });
    if (!org) return res.status(404).json({ error: 'Organization not found' });
    res.json({ data: org });
  } catch (e) {
    sendError(res, e, 'Load organization');
  }
});

apiRouter.put('/organization', requirePermission('org:update'), auditLog('UPDATE', 'Organization'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const name = optionalString(req.body?.name, 'name');
    const legal_name = optionalString(req.body?.legal_name, 'legal_name');
    const website = optionalString(req.body?.website, 'website');
    const pan = optionalString(req.body?.pan, 'pan', 10);
    const tan = optionalString(req.body?.tan, 'tan', 10);
    const gstin = optionalString(req.body?.gstin, 'gstin', 15);
    if (name !== undefined && !name) throw badRequest('name cannot be empty');
    if (legal_name !== undefined && !legal_name) throw badRequest('legal_name cannot be empty');

    const org = await prisma.organization.update({
      where: { id: orgId },
      data: {
        name, legal_name,
        website: website === '' ? null : website,
        pan: pan === '' ? null : pan,
        tan: tan === '' ? null : tan,
        gstin: gstin === '' ? null : gstin,
      }
    });
    res.json({ data: org });
  } catch (e) {
    sendError(res, e, 'Update organization');
  }
});

apiRouter.get('/branches', requirePermission('employee:view'), async (req: Request, res: Response) => {
  try {
    const branches = await prisma.branch.findMany({
      where: { organization_id: req.authContext!.organizationId },
      orderBy: { name: 'asc' },
      select: { id: true, name: true, code: true, city: true, is_headquarters: true }
    });
    res.json({ data: branches });
  } catch (e) {
    sendError(res, e, 'List branches');
  }
});

apiRouter.post('/branches', requirePermission('branch:create'), auditLog('CREATE', 'Branch'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId; // authoritative — never from body
    const { name, code, city, state, country, is_headquarters } = req.body || {};
    if (!name || !code || !city || !state || !country) throw badRequest('name, code, city, state and country are required');
    const branch = await prisma.branch.create({
      data: { organization_id: orgId, name, code, city, state, country, is_headquarters: !!is_headquarters }
    });
    res.json({ message: 'Branch created', branch });
  } catch (err) {
    sendError(res, err, 'Create branch');
  }
});

apiRouter.use(requireActiveUser());
apiRouter.use('/employees', employeeRoutes);
apiRouter.use('/shifts', shiftRoutes);
apiRouter.use('/attendance', attendanceRoutes);
apiRouter.use('/holidays', holidayRoutes);
apiRouter.use('/leaves', leaveRoutes);
apiRouter.use('/salary', salaryRoutes);
apiRouter.use('/loans', loanRoutes);
apiRouter.use('/payroll', payrollRoutes);
apiRouter.use('/dashboard', dashboardRoutes);

app.use('/api/v1', apiRouter);

// Unknown API route → JSON 404 (not an HTML page the frontend can't parse).
app.use('/api', (_req: Request, res: Response) => res.status(404).json({ error: 'Not found' }));

app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  if (err.code === 'EBADCSRFTOKEN') {
    return res.status(403).json({ error: 'Invalid or missing CSRF token' });
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Malformed JSON body' });
  }
  console.error('Unhandled Server Error:', err?.message || err);
  res.status(500).json({ error: isProd ? 'Internal server error' : (err?.message || 'Internal server error') });
});

export default app;

// Tests import `app` directly via supertest; they must not bind a port (several
// test files in one process would collide with EADDRINUSE).
if (!isTest) {
  app.listen(PORT, () => {
    console.log(`MUSTER Backend running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
  });
}
