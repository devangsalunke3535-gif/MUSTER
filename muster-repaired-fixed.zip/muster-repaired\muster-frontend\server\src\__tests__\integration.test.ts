import request from 'supertest';
import app from '../server';
import { prisma } from '../config/db';
import * as argon2 from 'argon2';

describe('Phase 1 Integration Tests', () => {
  let csrfToken: string;
  let csrfCookie: string;
  let authCookie: string;

  beforeAll(async () => {
    // Reset DB and seed test data
    await prisma.userRole.deleteMany();
    await prisma.rolePermission.deleteMany();
    await prisma.permission.deleteMany();
    await prisma.role.deleteMany();
    await prisma.auditLog.deleteMany();
    await prisma.branch.deleteMany();
    await prisma.shift.deleteMany();
    await prisma.user.deleteMany();
    await prisma.organization.deleteMany();

    const org = await prisma.organization.create({
      data: { name: 'Test Org A', code: 'ORG-A', legal_name: 'Test Org A Ltd' }
    });

    const orgB = await prisma.organization.create({
      data: { name: 'Test Org B', code: 'ORG-B', legal_name: 'Test Org B Ltd' }
    });

    const hash = await argon2.hash('testpass123');
    await prisma.user.create({
      data: {
        id: '11111111-1111-1111-1111-111111111111',
        organization_id: org.id,
        email: 'userA@test.com',
        password_hash: hash,
        is_active: true
      }
    });

    await prisma.user.create({
      data: {
        id: '22222222-2222-2222-2222-222222222222',
        organization_id: orgB.id,
        email: 'userB@test.com',
        password_hash: hash,
        is_active: true
      }
    });

    const perm = await prisma.permission.create({
      data: { module: 'branch', action: 'create', code: 'branch:create' }
    });

    const role = await prisma.role.create({
      data: { organization_id: org.id, name: 'Admin', code: 'admin' }
    });

    await prisma.rolePermission.create({
      data: { role_id: role.id, permission_id: perm.id }
    });

    await prisma.userRole.create({
      data: {
        user_id: '11111111-1111-1111-1111-111111111111',
        role_id: role.id,
        scope_organization_id: org.id
      }
    });
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('1. CSRF Verification - fetch token', async () => {
    const res = await request(app).get('/api/v1/auth/csrf');
    expect(res.status).toBe(200);
    expect(res.body.csrfToken).toBeDefined();
    csrfToken = res.body.csrfToken;
    csrfCookie = res.headers['set-cookie'][0];
  });

  it('2. Auth - Invalid Password', async () => {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .set('Cookie', csrfCookie)
      .set('CSRF-Token', csrfToken)
      .send({ email: 'userA@test.com', password: 'wrongpassword' });
    expect(res.status).toBe(401);
  });

  it('3. Auth - Valid Login', async () => {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .set('Cookie', csrfCookie)
      .set('CSRF-Token', csrfToken)
      .send({ email: 'userA@test.com', password: 'testpass123' });
    
    expect(res.status).toBe(200);
    const cookies = res.headers['set-cookie'];
    const cookiesArray = Array.isArray(cookies) ? cookies : [cookies];
    const sessionCookie = cookiesArray.find((c: any) => typeof c === 'string' && c.startsWith('muster_session'));
    expect(sessionCookie).toBeDefined();
    expect(sessionCookie).toContain('HttpOnly');
    
    authCookie = sessionCookie.split(';')[0];
  });

  it('4. CSRF - Missing token fails', async () => {
    const res = await request(app)
      .post('/api/v1/branches')
      .set('Cookie', [`${csrfCookie}`, `${authCookie}`])
      .send({ name: 'HQ', code: 'HQ', city: 'M', state: 'M', country: 'I', is_headquarters: true });
    
    expect(res.status).toBe(403);
    expect(res.body.error).toContain('Invalid CSRF token');
  });

  it('5. RBAC & Tenant Isolation - Allowed to create branch', async () => {
    const res = await request(app)
      .post('/api/v1/branches')
      .set('Cookie', [`${csrfCookie}`, `${authCookie}`])
      .set('CSRF-Token', csrfToken)
      .send({ name: 'HQ', code: 'HQ', city: 'M', state: 'M', country: 'I', is_headquarters: true });
    
    expect(res.status).toBe(200);

    // Verify tenant isolation forced the body to use UserA's organization_id
    const userA = await prisma.user.findFirst({ where: { email: 'userA@test.com' } });
    const branch = await prisma.branch.findFirst({ where: { code: 'HQ' } });
    expect(branch?.organization_id).toBe(userA?.organization_id);
  });

  it('6. Audit Logging Verification', async () => {
    // Branch creation should have triggered an audit log
    // Wait slightly for async logging
    await new Promise(r => setTimeout(r, 100));
    const logs = await prisma.auditLog.findMany();
    expect(logs.length).toBeGreaterThan(0);
    expect(logs[0].action).toBe('CREATE');
    expect(logs[0].entity_type).toBe('Branch');
  });
});
