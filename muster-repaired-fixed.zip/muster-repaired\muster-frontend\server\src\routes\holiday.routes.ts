import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { auditLog } from '../middleware/audit.middleware';
import { sendError, badRequest, notFound, parseDateOnly, isUuid, optionalString } from '../utils/http';

const router = Router();

/** A holiday's branch must belong to the caller's organization (null = all branches). */
async function assertBranch(orgId: string, branchId: unknown) {
  if (branchId === null || branchId === undefined || branchId === '') return;
  if (!isUuid(branchId)) throw badRequest('branch_id must be a valid UUID');
  const b = await prisma.branch.findFirst({ where: { id: branchId as string, organization_id: orgId } });
  if (!b) throw badRequest('Branch not found in your organization');
}

// GET /api/v1/holidays
router.get('/', requirePermission('holiday:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const holidays = await prisma.holiday.findMany({ where: { organization_id: orgId }, orderBy: { date: 'asc' } });
    res.json({ data: holidays });
  } catch (error) {
    sendError(res, error, 'holiday');
  }
});

// POST /api/v1/holidays
router.post('/', requirePermission('holiday:create'), auditLog('CREATE', 'Holiday'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const { name, date, branch_id, is_active } = req.body || {};
    if (!name) throw badRequest('name is required');
    const parsedDate = parseDateOnly(date, 'date');
    await assertBranch(orgId, branch_id);

    const holiday = await prisma.holiday.create({
      data: {
        organization_id: orgId,
        name,
        date: parsedDate,
        branch_id: branch_id || null,
        is_active: is_active ?? true
      }
    });

    res.json({ data: holiday });
  } catch (error) {
    sendError(res, error, 'holiday');
  }
});

// PUT /api/v1/holidays/:id
router.put('/:id', requirePermission('holiday:update'), auditLog('UPDATE', 'Holiday'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const holidayId = req.params.id as string;
    const { name, date, branch_id, is_active } = req.body || {};
    if (!isUuid(holidayId)) throw notFound('Holiday not found');
    if (branch_id !== undefined) await assertBranch(orgId, branch_id);

    // Verify ownership
    const existing = await prisma.holiday.findFirst({ where: { id: holidayId, organization_id: orgId } });
    if (!existing) return res.status(404).json({ error: 'Holiday not found' });

    const holiday = await prisma.holiday.update({
      where: { id: holidayId },
      data: {
        name,
        date: date ? parseDateOnly(date, 'date') : undefined,
        branch_id,
        is_active
      }
    });

    res.json({ data: holiday });
  } catch (error) {
    sendError(res, error, 'holiday');
  }
});

export default router;
