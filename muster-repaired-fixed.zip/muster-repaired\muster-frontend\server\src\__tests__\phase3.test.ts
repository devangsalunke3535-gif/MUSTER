import request from 'supertest';
import app from '../server';
import { prisma } from '../config/db';
import * as argon2 from 'argon2';

describe('Phase 3 Integration Tests (Shift & Attendance Domain)', () => {
  let csrfToken: string;
  let csrfCookie: string;
  let authCookieOrgA: string;
  let authCookieOrgB: string;
  let authCookieMgrA: string; // separate approver: self-approval is intentionally blocked
  
  let orgAId: string;
  let orgBId: string;
  let empAId: string;
  let shiftAId: string;
  let attendanceAId: string;
  let correctionAId: string;

  beforeAll(async () => {
    // Teardown
    await prisma.attendanceCorrection.deleteMany();
    await prisma.attendanceSession.deleteMany();
    await prisma.attendance.deleteMany();
    await prisma.shift.deleteMany();
    
    await prisma.approvalAction.deleteMany();
    await prisma.approvalStep.deleteMany();
    await prisma.approvalRequest.deleteMany();

    // From Phase 2 Teardown
    await prisma.employeeAssignmentHistory.deleteMany();
    await prisma.employeeStatusHistory.deleteMany();
    await prisma.employment.deleteMany();
    await prisma.employee.deleteMany();
    await prisma.userRole.deleteMany();
    await prisma.rolePermission.deleteMany();
    await prisma.permission.deleteMany();
    await prisma.role.deleteMany();
    await prisma.auditLog.deleteMany();
    await prisma.branch.deleteMany();
    await prisma.user.deleteMany();
    await prisma.organization.deleteMany();

    // Create Organizations
    const orgA = await prisma.organization.create({ data: { name: 'Org A', code: 'ORGA', legal_name: 'Org A Ltd' } });
    const orgB = await prisma.organization.create({ data: { name: 'Org B', code: 'ORGB', legal_name: 'Org B Ltd' } });
    orgAId = orgA.id;
    orgBId = orgB.id;

    // Create Permissions
    const p1 = await prisma.permission.create({ data: { module: 'attendance', action: 'create', code: 'attendance:create' } });
    const p2 = await prisma.permission.create({ data: { module: 'shift', action: 'create', code: 'shift:create' } });
    const p3 = await prisma.permission.create({ data: { module: 'shift', action: 'view', code: 'shift:view' } });
    const p4 = await prisma.permission.create({ data: { module: 'attendance', action: 'view', code: 'attendance:view' } });
    const p5 = await prisma.permission.create({ data: { module: 'correction', action: 'create', code: 'attendance:correction:create' } });
    const p6 = await prisma.permission.create({ data: { module: 'correction', action: 'approve', code: 'attendance:correction:approve' } });
    
    const roleA = await prisma.role.create({ data: { organization_id: orgA.id, name: 'HR', code: 'HR' } });
    const roleB = await prisma.role.create({ data: { organization_id: orgB.id, name: 'HR', code: 'HR' } });
    
    await prisma.rolePermission.createMany({
      data: [p1, p2, p3, p4, p5, p6].map(p => ({ role_id: roleA.id, permission_id: p.id }))
    });
    await prisma.rolePermission.createMany({
      data: [p1, p2, p3, p4, p5, p6].map(p => ({ role_id: roleB.id, permission_id: p.id }))
    });

    // Create Admins
    const hash = await argon2.hash('testpass123');
    const adminA = await prisma.user.create({ data: { organization_id: orgA.id, email: 'adminA@test.com', password_hash: hash, is_active: true } });
    const adminB = await prisma.user.create({ data: { organization_id: orgB.id, email: 'adminB@test.com', password_hash: hash, is_active: true } });
    
    await prisma.userRole.create({ data: { user_id: adminA.id, role_id: roleA.id, scope_organization_id: orgA.id } });
    await prisma.userRole.create({ data: { user_id: adminB.id, role_id: roleB.id, scope_organization_id: orgB.id } });

    // Create Employee A linked to Admin A
    const emp = await prisma.employee.create({
      data: {
        organization_id: orgA.id,
        user_id: adminA.id,
        emp_id: 'E01',
        first_name: 'Admin',
        last_name: 'A'
      }
    });
    empAId = emp.id;
    
    // Create Employment (Manager of self for testing approval)
    // Approver: a DIFFERENT employee in the same org (self-approval is blocked by design).
    const mgrUser = await prisma.user.create({ data: { organization_id: orgA.id, email: 'mgrA@test.com', password_hash: hash, is_active: true } });
    await prisma.userRole.create({ data: { user_id: mgrUser.id, role_id: roleA.id, scope_organization_id: orgA.id } });
    const mgrEmp = await prisma.employee.create({ data: { organization_id: orgA.id, user_id: mgrUser.id, emp_id: 'M01', first_name: 'Manager', last_name: 'A' } });
    await prisma.employment.create({ data: { employee_id: mgrEmp.id, joining_date: new Date(), status: 'ACTIVE' } });

    await prisma.employment.create({
      data: {
        employee_id: emp.id,
        joining_date: new Date(),
        status: 'ACTIVE',
        manager_id: mgrEmp.id
      }
    });
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('1. Setup Auth & CSRF', async () => {
    const res = await request(app).get('/api/v1/auth/csrf');
    csrfToken = res.body.csrfToken;
    csrfCookie = res.headers['set-cookie'][0];

    const loginA = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'adminA@test.com', password: 'testpass123' });
    const cookiesA = Array.isArray(loginA.headers['set-cookie']) ? loginA.headers['set-cookie'] : [loginA.headers['set-cookie']];
    authCookieOrgA = cookiesA.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];

    const loginB = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'adminB@test.com', password: 'testpass123' });
    const cookiesB = Array.isArray(loginB.headers['set-cookie']) ? loginB.headers['set-cookie'] : [loginB.headers['set-cookie']];
    authCookieOrgB = cookiesB.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];

    const loginM = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'mgrA@test.com', password: 'testpass123' });
    const cookiesM = Array.isArray(loginM.headers['set-cookie']) ? loginM.headers['set-cookie'] : [loginM.headers['set-cookie']];
    authCookieMgrA = cookiesM.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];
  });

  it('2. Create Shift (Org A)', async () => {
    const res = await request(app)
      .post('/api/v1/shifts')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        name: 'General Shift',
        start_time: '09:00:00',
        end_time: '18:00:00',
        grace_period_mins: 15,
        half_day_mins: 240,
        full_day_mins: 480
      });
    
    if (res.status !== 200) console.error(res.body);
    expect(res.status).toBe(200);
    expect(res.body.data.id).toBeDefined();
    shiftAId = res.body.data.id;
  });

  it('3. Shift Tenant Isolation - Org B cannot see Org A shift', async () => {
    const res = await request(app)
      .get('/api/v1/shifts')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgB}`]);
    
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(0);
  });

  it('4. Employee Check-in', async () => {
    const res = await request(app)
      .post('/api/v1/attendance/check-in')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken);
    
    if (res.status !== 200) console.error(res.body);
    expect(res.status).toBe(200);
    expect(res.body.data.attendance.id).toBeDefined();
    expect(res.body.data.session.id).toBeDefined();
    attendanceAId = res.body.data.attendance.id;
  });

  it('5. Duplicate Check-in Prevention', async () => {
    const res = await request(app)
      .post('/api/v1/attendance/check-in')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken);
    
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('You are already checked in');
  });

  it('6. Employee Check-out & Calculation', async () => {
    // Wait for 1 second so duration > 0 (wait, duration is in mins, we can just manipulate the check-out time but it uses server time `new Date()`)
    // If it's less than 1 min, duration will be 0.
    const res = await request(app)
      .post('/api/v1/attendance/check-out')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken);
    
    expect(res.status).toBe(200);
    expect(res.body.data.session.check_out_time).not.toBeNull();
  });

  it('7. Correction Request Creation', async () => {
    const res = await request(app)
      .post('/api/v1/attendance/corrections')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        attendance_id: attendanceAId,
        requested_status: 'PRESENT',
        requested_check_in: new Date(new Date().setHours(9,0,0,0)).toISOString(),
        requested_check_out: new Date(new Date().setHours(18,0,0,0)).toISOString(),
        reason: 'Forgot to check in'
      });
    
    if (res.status !== 200) console.error(res.body);
    expect(res.status).toBe(200);
    expect(res.body.data.id).toBeDefined();
    correctionAId = res.body.data.id;
  });

  it('8. Correction Approval (Overwrites History)', async () => {
    const res = await request(app)
      .post(`/api/v1/attendance/corrections/${correctionAId}/approve`)
      .set('Cookie', [`${csrfCookie}`, `${authCookieMgrA}`])
      .set('CSRF-Token', csrfToken);
    
    if (res.status !== 200) console.error(res.body);
    expect(res.status).toBe(200);

    // Verify Master Attendance is updated
    const att = await prisma.attendance.findUnique({ where: { id: attendanceAId } });
    expect(att?.total_worked_mins).toBeGreaterThan(0); // 9AM to 6PM is 540 mins
  });
});
