import { Prisma } from '@prisma/client';
import { prisma } from '../config/db';
import { badRequest } from '../utils/http';

export class LeaveService {
  /**
   * Leave duration in days: inclusive calendar days minus active holidays in
   * the range (org-wide holidays, plus branch holidays when a branch is given).
   * Weekly offs are not modelled in the schema, so they are not excluded.
   */
  static async calculateDurationDays(orgId: string, startDate: Date, endDate: Date, tx: Prisma.TransactionClient = prisma as any, branchId?: string | null): Promise<number> {
    const days = Math.round((endDate.getTime() - startDate.getTime()) / 86400000) + 1;
    const holidays = await tx.holiday.count({
      where: {
        organization_id: orgId,
        is_active: true,
        date: { gte: startDate, lte: endDate },
        OR: [{ branch_id: null }, ...(branchId ? [{ branch_id: branchId }] : [])]
      }
    });
    return Math.max(0, days - holidays);
  }

  /** Atomic, overdraft-proof deduction (conditional UPDATE — safe under concurrency). */
  static async deductBalance(tx: Prisma.TransactionClient, employeeId: string, leaveTypeId: string, year: number, durationDays: number) {
    const balance = await tx.leaveBalance.findUnique({
      where: { employee_id_leave_type_id_leave_year: { employee_id: employeeId, leave_type_id: leaveTypeId, leave_year: year } }
    });
    if (!balance) throw badRequest('Leave balance not allocated for this year.');

    const updatedRows = await tx.$executeRaw`
      UPDATE "LeaveBalance"
      SET used_balance = used_balance + ${durationDays},
          remaining_balance = remaining_balance - ${durationDays},
          updated_at = now()
      WHERE id = ${balance.id}::uuid AND remaining_balance >= ${durationDays}
    `;
    if (updatedRows === 0) throw badRequest('Insufficient leave balance');
  }

  static async restoreBalance(tx: Prisma.TransactionClient, employeeId: string, leaveTypeId: string, year: number, durationDays: number) {
    const balance = await tx.leaveBalance.findUnique({
      where: { employee_id_leave_type_id_leave_year: { employee_id: employeeId, leave_type_id: leaveTypeId, leave_year: year } }
    });
    if (!balance) throw badRequest('Leave balance record missing; cannot restore');
    await tx.leaveBalance.update({
      where: { id: balance.id },
      data: { used_balance: { decrement: durationDays }, remaining_balance: { increment: durationDays } }
    });
  }
}
