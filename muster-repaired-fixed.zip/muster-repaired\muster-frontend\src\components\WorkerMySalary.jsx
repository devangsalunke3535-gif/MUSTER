import { useState, useEffect } from 'react';
import api from '../api';
import { Calendar, Download, ChevronRight, FileText, AlertCircle } from 'lucide-react';
import { describeError } from '../api';

export default function WorkerMySalary() {
  const [statements, setStatements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSalary = async () => {
      try {
        const res = await api.get('/salary/statements/my-salary');
        setStatements(res.data?.data || res.data || []);
      } catch (err) {
        setError(describeError(err, 'Failed to load salary statements.'));
      } finally {
        setLoading(false);
      }
    };
    fetchSalary();
  }, []);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8 animate-pulse">
        <div className="h-8 w-48 bg-slate-200 rounded-lg mb-8"></div>
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 bg-slate-200 rounded-2xl"></div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8">
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm">
          <AlertCircle size={16} /> {error}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight">My Salary</h1>
        <p className="text-slate-500 mt-1">Review your past pay statements and deductions.</p>
      </div>

      {statements.length === 0 ? (
        <div className="text-center py-16 bg-slate-50 border border-slate-200 border-dashed rounded-3xl">
          <FileText size={48} className="mx-auto text-slate-300 mb-4" />
          <h3 className="text-lg font-bold text-slate-700">No statements yet</h3>
          <p className="text-slate-500 max-w-sm mx-auto mt-2 text-sm">
            You don't have any finalized salary statements yet. They will appear here once payroll is processed.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {statements.map((stmt) => (
            <div key={stmt.id} className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden group hover:shadow-md transition-shadow">
              
              {/* Header */}
              <div className="p-6 border-b border-slate-100 flex flex-wrap items-center justify-between gap-4 bg-slate-50/50">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary-50 text-primary-600 flex items-center justify-center shrink-0">
                    <Calendar size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-slate-800">
                      {stmt.run?.period?.name || 'Unknown Period'}
                    </h3>
                    <p className="text-sm text-slate-500 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      {stmt.run?.status || 'FINALIZED'}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-sm font-semibold text-slate-500 mb-1 uppercase tracking-wider">Net Pay</p>
                  <p className="text-3xl font-bold text-emerald-600 tracking-tight">
                    ₹{stmt.net_pay?.toLocaleString() || 0}
                  </p>
                </div>
              </div>

              {/* Details Breakdown */}
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Earnings */}
                <div>
                  <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center justify-between border-b border-slate-100 pb-2">
                    <span>Earnings</span>
                    <span className="text-slate-400 font-normal normal-case">{stmt.payable_days} Days / {stmt.payable_hours} Hrs</span>
                  </h4>
                  <ul className="space-y-3">
                    {stmt.components?.filter(c => c.component?.type === 'EARNING' || c.component?.type === 'OVERTIME').map(c => (
                      <li key={c.id} className="flex justify-between items-center text-sm">
                        <span className="text-slate-600">{c.component?.name || 'Basic'}</span>
                        <span className="font-semibold text-slate-800">₹{c.amount.toLocaleString()}</span>
                      </li>
                    ))}
                    <li className="flex justify-between items-center text-sm pt-3 mt-3 border-t border-slate-100 font-bold">
                      <span className="text-slate-800">Gross Earnings</span>
                      <span className="text-slate-800">₹{stmt.gross_earnings?.toLocaleString()}</span>
                    </li>
                  </ul>
                </div>

                {/* Deductions */}
                <div>
                  <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">
                    Deductions
                  </h4>
                  <ul className="space-y-3">
                    {stmt.components?.filter(c => c.component?.type === 'DEDUCTION' || c.component?.type === 'STATUTORY').map(c => (
                      <li key={c.id} className="flex justify-between items-center text-sm">
                        <span className="text-slate-600">{c.component?.name || 'PF'}</span>
                        <span className="font-semibold text-rose-600">-₹{c.amount.toLocaleString()}</span>
                      </li>
                    ))}
                    
                    {/* Loan Repayments */}
                    {stmt.loanRepayments?.map(r => (
                      <li key={r.id} className="flex justify-between items-center text-sm">
                        <span className="text-slate-600">Advance Recovery</span>
                        <span className="font-semibold text-rose-600">-₹{r.amount.toLocaleString()}</span>
                      </li>
                    ))}
                    
                    {stmt.total_deductions === 0 && stmt.loanRepayments?.length === 0 && (
                      <li className="text-sm text-slate-400 italic">No deductions</li>
                    )}

                    <li className="flex justify-between items-center text-sm pt-3 mt-3 border-t border-slate-100 font-bold">
                      <span className="text-slate-800">Total Deductions</span>
                      <span className="text-rose-600">-₹{stmt.total_deductions?.toLocaleString()}</span>
                    </li>
                  </ul>
                </div>

              </div>

              {/* Action Footer */}
              <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end">
                <button className="flex items-center gap-2 text-sm font-semibold text-primary-600 hover:text-primary-700 transition-colors">
                  <Download size={16} />
                  Download PDF
                </button>
              </div>

            </div>
          ))}
        </div>
      )}
    </div>
  );
}
