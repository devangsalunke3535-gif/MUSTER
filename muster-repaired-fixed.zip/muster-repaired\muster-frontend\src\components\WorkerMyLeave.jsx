import { useState, useEffect } from 'react';
import api from '../api';
import { Plus, X, Calendar as CalIcon, AlertCircle } from 'lucide-react';
import { useToast } from './Toast';
import { describeError } from '../api';

export default function WorkerMyLeave() {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ start_date: '', end_date: '', reason: '', leave_type_id: '' });
  const { addToast } = useToast();

  const [leaveTypes, setLeaveTypes] = useState([]);
  const [stats, setStats] = useState({ balance: 0, used: 0 });

  const load = async () => {
    try {
      const [reqRes, typeRes, balRes] = await Promise.all([
        api.get('/leaves/my-requests'),
        api.get('/leaves/types'),
        api.get('/leaves/balances'),
      ]);
      setLeaves(reqRes.data?.data || []);
      setLeaveTypes(typeRes.data?.data || []);
      const balances = balRes.data?.data || [];
      setStats({
        balance: balances.reduce((s, b) => s + b.remaining_balance, 0),
        used: balances.reduce((s, b) => s + b.used_balance, 0),
      });
      if (typeRes.data?.data?.length > 0) setForm(f => ({ ...f, leave_type_id: f.leave_type_id || typeRes.data.data[0].id }));
      setError(null);
    } catch (err) {
      setError(describeError(err, 'Failed to load leave data'));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  const getStatusBadge = (status) => {
    const maps = {
      APPROVED: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      PENDING: 'bg-amber-100 text-amber-700 border-amber-200',
      REJECTED: 'bg-rose-100 text-rose-700 border-rose-200',
      CANCELLED: 'bg-slate-100 text-slate-600 border-slate-200',
    };
    return `px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${maps[status] || maps.PENDING}`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post('/leaves/requests', {
        leave_type_id: form.leave_type_id,
        start_date: form.start_date,
        end_date: form.end_date,
        reason: form.reason,
      });
      setShowModal(false);
      setForm({ start_date: '', end_date: '', reason: '', leave_type_id: leaveTypes[0]?.id || '' });
      addToast('Leave request submitted successfully', 'success');
      await load();
    } catch (err) {
      addToast(describeError(err, 'Failed to submit request'), 'error');
    }
    setSubmitting(false);
  };

  const handleCancel = async (id) => {
    try {
      await api.post(`/leaves/requests/${id}/cancel`);
      addToast('Leave cancelled', 'success');
      await load();
    } catch (err) {
      addToast(describeError(err, 'Failed to cancel leave'), 'error');
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight">My Leave</h1>
          <p className="text-slate-500 mt-1">Manage your time off.</p>
        </div>
        <button onClick={() => setShowModal(true)} disabled={leaveTypes.length === 0}
          className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 text-white rounded-xl font-semibold shadow-lg shadow-primary-600/25 hover:bg-primary-700 active:scale-95 transition-all disabled:opacity-50">
          <Plus size={18} /> <span className="hidden sm:inline">Request Leave</span>
        </button>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm mb-6">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Balance</p>
          <p className="text-2xl font-bold text-slate-800">{stats.balance} <span className="text-sm font-normal text-slate-500">days</span></p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Used</p>
          <p className="text-2xl font-bold text-slate-800">{stats.used} <span className="text-sm font-normal text-slate-500">days</span></p>
        </div>
      </div>

      {loading ? (
        <div className="space-y-4 animate-pulse">
          <div className="h-24 bg-slate-200 rounded-2xl"></div>
          <div className="h-24 bg-slate-200 rounded-2xl"></div>
        </div>
      ) : leaves.length === 0 ? (
        <div className="text-center py-16 bg-slate-50 border border-slate-200 border-dashed rounded-3xl text-slate-500 text-sm">No leave requests yet.</div>
      ) : (
        <div className="space-y-4">
          {leaves.map((l) => (
            <div key={l.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm group hover:shadow-md transition-all">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 text-slate-400 flex items-center justify-center">
                    <CalIcon size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">{l.leaveType?.name || 'Leave'}</h3>
                    <p className="text-xs text-slate-500">
                      {new Date(l.start_date).toLocaleDateString('en-IN', { timeZone: 'UTC' })} — {new Date(l.end_date).toLocaleDateString('en-IN', { timeZone: 'UTC' })} · {l.duration_days} day(s)
                    </p>
                  </div>
                </div>
                <span className={getStatusBadge(l.status)}>{l.status}</span>
              </div>
              <p className="text-sm text-slate-600 mt-3 pl-13">{l.reason}</p>
              {l.status === 'PENDING' && (
                <button onClick={() => handleCancel(l.id)} className="mt-3 text-xs font-semibold text-rose-500 hover:text-rose-600">Cancel request</button>
              )}
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden animate-slide-up sm:animate-scale-in">
            <div className="flex items-center justify-between p-5 border-b border-slate-100">
              <h2 className="font-bold text-lg text-slate-800">Request Leave</h2>
              <button onClick={() => setShowModal(false)} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">Leave Type</label>
                <select value={form.leave_type_id} onChange={e => setForm({ ...form, leave_type_id: e.target.value })} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20">
                  {leaveTypes.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-2">Start Date</label>
                  <input type="date" required value={form.start_date} onChange={e => setForm({ ...form, start_date: e.target.value })} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-2">End Date</label>
                  <input type="date" required value={form.end_date} min={form.start_date || undefined} onChange={e => setForm({ ...form, end_date: e.target.value })} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">Reason</label>
                <textarea required value={form.reason} onChange={e => setForm({ ...form, reason: e.target.value })} rows="3" placeholder="I have to attend a family function..." className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20"></textarea>
              </div>
              <button type="submit" disabled={submitting} className="w-full py-3 bg-primary-600 text-white rounded-xl font-bold shadow-lg shadow-primary-600/25 hover:bg-primary-700 active:scale-95 transition-all mt-4 disabled:opacity-60">
                {submitting ? 'Submitting...' : 'Submit Request'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
