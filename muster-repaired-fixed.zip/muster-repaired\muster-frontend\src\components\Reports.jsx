import { useEffect, useState } from 'react';
import { getCompliance, getSummary } from '../api';
import { ShieldAlert, ShieldCheck, AlertTriangle, FileText, Calendar as CalendarIcon, Search, Download } from 'lucide-react';
import { describeError } from '../api';

export default function Reports() {
  const [activeReport, setActiveReport] = useState('compliance');
  const [compliance, setCompliance] = useState(null);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);
  const now = new Date();
  const today = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
  const [date, setDate] = useState(today);
  const [searchTerm, setSearchTerm] = useState('');

  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError(null);
      try {
        if (activeReport === 'compliance') {
          const data = await getCompliance();
          setCompliance(data);
        } else {
          const data = await getSummary(date);
          setSummary(data);
        }
      } catch (err) {
        setError(describeError(err, 'Failed to load report'));
      }
      setLoading(false);
    }
    load();
  }, [activeReport, date]);

  // Exports exactly the report currently on screen — no server round-trip,
  // no data beyond what's already loaded and visible.
  const downloadCsv = () => {
    let rows, filename;
    if (activeReport === 'compliance') {
      if (!compliance?.workers?.length) return;
      rows = [
        ['Worker ID', 'Name', 'Shift', 'UAN', 'ESI'],
        ...compliance.workers.map(w => [w.worker_id, w.name, w.shift_type, w.uan ? 'Active' : 'Missing', w.esi_ip ? 'Active' : 'Missing']),
      ];
      filename = `compliance-report-${new Date().toISOString().slice(0, 10)}.csv`;
    } else {
      if (!summary) return;
      rows = [
        ['Shift', 'Total', 'Present', 'Absent', 'Half Day', 'Not Marked'],
        ...['day', 'night'].map(s => [s, summary[s].total, summary[s].present, summary[s].absent, summary[s].half || 0, summary[s].not_marked || 0]),
      ];
      filename = `attendance-summary-${date}.csv`;
    }
    const csv = rows.map(r => r.map(cell => {
      const v = String(cell ?? '');
      return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
    }).join(',')).join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const canExport = activeReport === 'compliance' ? !!compliance?.workers?.length : !!summary;

  const filteredWorkers = compliance?.workers?.filter(w =>
    w.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    w.worker_id.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  // Use the server-computed, null-safe coverage percentages (never divides by zero client-side).
  const uanPercent = compliance?.uan_coverage;
  const esiPercent = compliance?.esi_coverage;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Reports</h1>
          <p className="text-slate-400 text-sm mt-1">Compliance and attendance reports</p>
        </div>
        <button onClick={downloadCsv} disabled={!canExport}
          className={canExport
            ? "flex items-center gap-2 bg-white border border-slate-200 text-slate-600 px-4 py-2.5 rounded-xl text-sm font-medium shadow-soft hover:bg-slate-50 transition-colors"
            : "flex items-center gap-2 bg-slate-50 border border-slate-200 text-slate-300 px-4 py-2.5 rounded-xl text-sm font-medium cursor-not-allowed"}>
          <Download size={15} />
          <span>Export CSV</span>
        </button>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm">
          <ShieldAlert size={16} /> {error}
        </div>
      )}

      {/* Report Tabs */}
      <div className="flex gap-2 bg-white p-1.5 rounded-xl border border-slate-100 shadow-soft w-max">
        <button
          onClick={() => setActiveReport('compliance')}
          className={activeReport === 'compliance'
            ? "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold bg-primary-600 text-white shadow-sm transition-all"
            : "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-slate-500 hover:text-slate-700 hover:bg-slate-50 transition-all"
          }
        >
          <ShieldAlert size={15} />
          <span>Compliance Gaps</span>
        </button>
        <button
          onClick={() => setActiveReport('attendance')}
          className={activeReport === 'attendance'
            ? "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold bg-primary-600 text-white shadow-sm transition-all"
            : "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-slate-500 hover:text-slate-700 hover:bg-slate-50 transition-all"
          }
        >
          <FileText size={15} />
          <span>Attendance Summary</span>
        </button>
      </div>

      {/* Compliance Report */}
      {activeReport === 'compliance' && (
        <div className="space-y-4 animate-fade-in">
          {/* Health Bars */}
          {compliance && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-soft">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold text-slate-700">UAN Coverage</h4>
                  <span className={"text-sm font-bold " + (uanPercent === null ? "text-slate-400" : uanPercent > 80 ? "text-emerald-600" : uanPercent > 50 ? "text-amber-600" : "text-rose-600")}>{uanPercent === null ? "—" : uanPercent + "%"}</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2.5">
                  <div className={"h-full rounded-full transition-all duration-700 " + (uanPercent === null ? "bg-slate-200" : uanPercent > 80 ? "bg-emerald-500" : uanPercent > 50 ? "bg-amber-500" : "bg-rose-500")} style={{ width: (uanPercent || 0) + '%' }} />
                </div>
                <p className="text-xs text-slate-400 mt-2">{compliance.missing_uan} of {compliance.total} workers missing UAN</p>
              </div>
              <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-soft">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold text-slate-700">ESI/IP Coverage</h4>
                  <span className={"text-sm font-bold " + (esiPercent === null ? "text-slate-400" : esiPercent > 80 ? "text-emerald-600" : esiPercent > 50 ? "text-amber-600" : "text-rose-600")}>{esiPercent === null ? "—" : esiPercent + "%"}</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2.5">
                  <div className={"h-full rounded-full transition-all duration-700 " + (esiPercent === null ? "bg-slate-200" : esiPercent > 80 ? "bg-emerald-500" : esiPercent > 50 ? "bg-amber-500" : "bg-rose-500")} style={{ width: (esiPercent || 0) + '%' }} />
                </div>
                <p className="text-xs text-slate-400 mt-2">{compliance.missing_esi} of {compliance.total} workers missing ESI</p>
              </div>
            </div>
          )}

          {/* Search */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-soft p-4">
            <div className="flex items-center gap-3">
              <Search size={16} className="text-slate-400" />
              <input
                type="text"
                placeholder="Search workers with compliance gaps..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="flex-1 text-sm text-slate-700 placeholder-slate-400 outline-none"
              />
              <span className="text-xs text-slate-400 font-medium">{filteredWorkers.length} results</span>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-2xl shadow-soft overflow-hidden border border-slate-100">
            {loading ? (
              <div className="p-16 text-center"><div className="h-8 w-8 border-2 border-slate-200 border-t-primary-500 rounded-full animate-spin mx-auto" /></div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/80 text-slate-400 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-100">
                      <th className="px-6 py-3.5">Worker</th>
                      <th className="px-6 py-3.5">Shift</th>
                      <th className="px-6 py-3.5">UAN Status</th>
                      <th className="px-6 py-3.5">ESI Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredWorkers.map(w => (
                      <tr key={w.worker_id} className="hover:bg-primary-50/20 transition-colors">
                        <td className="px-6 py-3.5">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center text-primary-700 font-bold text-xs">
                              {w.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                            </div>
                            <div>
                              <p className="text-sm font-semibold text-slate-800">{w.name}</p>
                              <p className="text-[11px] text-slate-400">{w.worker_id}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-3.5">
                          <span className={"text-xs font-semibold capitalize " + (w.shift_type === 'DAY' ? "text-amber-600" : w.shift_type === 'NIGHT' ? "text-indigo-600" : "text-slate-400")}>
                            {w.shift_type === 'DAY' ? 'Day' : w.shift_type === 'NIGHT' ? 'Night' : w.shift_type === 'OTHER' ? (w.shift_name || 'Other') : 'Unassigned'}
                          </span>
                        </td>
                        <td className="px-6 py-3.5">
                          <div className="flex items-center gap-1.5">
                            {w.uan ? <ShieldCheck size={14} className="text-emerald-500" /> : <ShieldAlert size={14} className="text-rose-400" />}
                            <span className={"text-xs font-semibold " + (w.uan ? "text-emerald-600" : "text-rose-500")}>{w.uan ? 'Active' : 'Missing'}</span>
                          </div>
                        </td>
                        <td className="px-6 py-3.5">
                          <div className="flex items-center gap-1.5">
                            {w.esi_ip ? <ShieldCheck size={14} className="text-emerald-500" /> : <ShieldAlert size={14} className="text-rose-400" />}
                            <span className={"text-xs font-semibold " + (w.esi_ip ? "text-emerald-600" : "text-rose-500")}>{w.esi_ip ? 'Active' : 'Missing'}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Attendance Summary Report */}
      {activeReport === 'attendance' && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex items-center gap-3 bg-white px-4 py-2.5 rounded-xl border border-slate-200 shadow-soft w-max">
            <CalendarIcon size={16} className="text-primary-500" />
            <input type="date" value={date} max={today} onChange={e => setDate(e.target.value)}
              className="bg-transparent text-sm font-medium text-slate-700 outline-none cursor-pointer" />
          </div>

          {loading ? (
            <div className="bg-white p-16 rounded-2xl shadow-soft text-center"><div className="h-8 w-8 border-2 border-slate-200 border-t-primary-500 rounded-full animate-spin mx-auto" /></div>
          ) : summary && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['day', 'night'].map(shift => {
                const d = summary[shift];
                return (
                  <div key={shift} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-soft">
                    <h4 className="text-lg font-bold text-slate-800 capitalize mb-4">{shift} Shift</h4>
                    <div className="space-y-3">
                      {[
                        { label: 'Total Workers', value: d.total, color: 'text-slate-700' },
                        { label: 'Present', value: d.present, color: 'text-emerald-600' },
                        { label: 'Absent', value: d.absent, color: 'text-rose-600' },
                        { label: 'Half Day', value: d.half || 0, color: 'text-amber-600' },
                        { label: 'Not Marked', value: d.not_marked || 0, color: 'text-slate-400' },
                      ].map(item => (
                        <div key={item.label} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                          <span className="text-sm text-slate-600">{item.label}</span>
                          <span className={"text-sm font-bold " + item.color}>{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
