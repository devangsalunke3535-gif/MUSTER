import { X, Phone, Briefcase, Calendar, Shield, ShieldCheck, ShieldAlert, Edit3, Save, Trash2, Mail } from 'lucide-react';
import { useState, useEffect } from 'react';
import { fmtDate, inr, SHIFT_LABEL } from '../api';

export default function WorkerDetail({ worker, shifts, onClose, onSave, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    phone: worker.phone || '',
    daily_wage: worker.daily_wage ?? '',
    default_shift_id: worker.shift?.id || '',
  });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    setForm({ phone: worker.phone || '', daily_wage: worker.daily_wage ?? '', default_shift_id: worker.shift?.id || '' });
  }, [worker]);

  const handleSave = async () => {
    setSaving(true);
    await onSave({
      id: worker.id,
      phone: form.phone,
      daily_wage: form.daily_wage === '' ? undefined : Number(form.daily_wage),
      default_shift_id: form.default_shift_id || 'unassigned',
    });
    setSaving(false);
    setEditing(false);
  };

  const initials = (worker.full_name || worker.name || 'U').trim().split(/\s+/).map(n => n[0]).join('').substring(0, 2).toUpperCase();

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-2xl shadow-elevated w-full max-w-lg overflow-hidden animate-scale-in border border-slate-100">
        <div className="relative bg-gradient-to-r from-primary-600 to-primary-700 px-6 py-8 text-white">
          <button onClick={onClose} className="absolute top-4 right-4 text-white/60 hover:text-white transition-colors p-1 hover:bg-white/10 rounded-lg">
            <X size={18} />
          </button>
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/15 backdrop-blur-sm flex items-center justify-center text-2xl font-bold border border-white/20">
              {initials}
            </div>
            <div>
              <h2 className="text-xl font-bold">{worker.full_name || worker.name}</h2>
              <p className="text-primary-200 text-sm font-medium">{worker.emp_id}</p>
              <p className="text-primary-200/70 text-xs mt-0.5">{worker.branch?.name || 'No branch assigned'}</p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
              <div className="flex items-center gap-2 mb-1">
                <Phone size={13} className="text-slate-400" />
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Phone</span>
              </div>
              {editing ? (
                <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })}
                  className="w-full text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary-500/30" />
              ) : (
                <p className="text-sm font-semibold text-slate-800">{worker.phone || 'Not provided'}</p>
              )}
            </div>

            <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
              <div className="flex items-center gap-2 mb-1">
                <Mail size={13} className="text-slate-400" />
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Email</span>
              </div>
              <p className="text-sm font-semibold text-slate-800 truncate">{worker.email || 'Not provided'}</p>
            </div>

            <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
              <div className="flex items-center gap-2 mb-1">
                <Briefcase size={13} className="text-slate-400" />
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Daily Wage</span>
              </div>
              {editing ? (
                <input type="number" min="0" value={form.daily_wage} onChange={e => setForm({ ...form, daily_wage: e.target.value })}
                  className="w-full text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary-500/30" />
              ) : (
                <p className="text-sm font-semibold text-slate-800">{worker.wage?.basis === 'DAILY' ? inr(worker.daily_wage) : (worker.wage ? `${worker.wage.basis} basis` : 'Not configured')}</p>
              )}
            </div>

            <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
              <div className="flex items-center gap-2 mb-1">
                <Calendar size={13} className="text-slate-400" />
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Default Shift</span>
              </div>
              {editing ? (
                <select value={form.default_shift_id} onChange={e => setForm({ ...form, default_shift_id: e.target.value })}
                  className="w-full text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary-500/30">
                  <option value="">Unassigned</option>
                  {shifts.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              ) : (
                <p className="text-sm font-semibold text-slate-800">{worker.shift?.name || 'Unassigned'}</p>
              )}
            </div>

            <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 col-span-2">
              <div className="flex items-center gap-2 mb-1">
                <Calendar size={13} className="text-slate-400" />
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Joined</span>
              </div>
              <p className="text-sm font-semibold text-slate-800">{fmtDate(worker.joining_date)} · {worker.status || 'Unknown status'}</p>
            </div>
          </div>

          <div className="border border-slate-100 rounded-xl p-4">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Shield size={13} /> Compliance Status
            </h4>
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {worker.has_uan ? <ShieldCheck size={15} className="text-emerald-500" /> : <ShieldAlert size={15} className="text-rose-400" />}
                  <span className="text-sm font-medium text-slate-700">UAN Number</span>
                </div>
                <span className={"text-xs font-semibold px-2 py-0.5 rounded-md " + (worker.has_uan ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600")}>
                  {worker.has_uan ? 'On file' : 'Missing'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {worker.has_esi ? <ShieldCheck size={15} className="text-emerald-500" /> : <ShieldAlert size={15} className="text-rose-400" />}
                  <span className="text-sm font-medium text-slate-700">ESI / IP Number</span>
                </div>
                <span className={"text-xs font-semibold px-2 py-0.5 rounded-md " + (worker.has_esi ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600")}>
                  {worker.has_esi ? 'On file' : 'Missing'}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/50">
          {confirmDelete ? (
            <div className="flex items-center gap-3 w-full">
              <p className="text-sm text-rose-600 font-medium flex-1">Deactivate this worker? Their history is kept.</p>
              <button onClick={() => setConfirmDelete(false)} className="px-3 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-lg transition-colors">
                Cancel
              </button>
              <button onClick={() => onDelete(worker.id)} className="px-3 py-1.5 text-sm font-semibold bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition-colors">
                Deactivate
              </button>
            </div>
          ) : (
            <>
              <button onClick={() => setConfirmDelete(true)} className="flex items-center gap-1.5 text-sm text-rose-500 hover:text-rose-600 font-medium transition-colors">
                <Trash2 size={14} /> Deactivate
              </button>
              <div className="flex gap-2">
                {editing ? (
                  <>
                    <button onClick={() => setEditing(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-xl transition-colors">
                      Cancel
                    </button>
                    <button onClick={handleSave} disabled={saving} className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors shadow-sm disabled:opacity-60">
                      <Save size={14} /> {saving ? 'Saving...' : 'Save'}
                    </button>
                  </>
                ) : (
                  <button onClick={() => setEditing(true)} className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors shadow-sm">
                    <Edit3 size={14} /> Edit Worker
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
