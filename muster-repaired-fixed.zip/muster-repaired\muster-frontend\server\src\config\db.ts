import { PrismaClient } from '@prisma/client';

const isProd = process.env.NODE_ENV === 'production';

// P0-7 FIX: Never log queries in production — they contain password_hash values
// and other sensitive column data in plaintext.
// In dev/test, only log warnings and errors (not 'query' or 'info').
export const prisma = new PrismaClient({
  log: isProd ? ['error'] : ['warn', 'error'],
});
