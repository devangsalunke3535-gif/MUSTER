import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from '../config/env';

export const SESSION_COOKIE = 'muster_session';

export function authenticate(req: Request, res: Response, next: NextFunction) {
  try {
    const token = req.cookies?.[SESSION_COOKIE] || req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ error: 'Unauthorized: Missing token' });
    }
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; organizationId: string; tv?: number };
    if (!decoded?.userId || !decoded?.organizationId) {
      return res.status(401).json({ error: 'Unauthorized: Invalid token' });
    }
    req.authContext = { userId: decoded.userId, organizationId: decoded.organizationId, tokenVersion: decoded.tv ?? 0 };
    next();
  } catch {
    return res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
}

/**
 * A user record is a valid session owner only if it is active, belongs to the
 * token's organization, and the token's version matches (not revoked by logout
 * or a password change).
 */
export function isSessionValid(user: { is_active: boolean; organization_id: string; token_version: number } | null,
  ctx: { organizationId: string; tokenVersion: number } | undefined): boolean {
  return !!user && !!ctx && user.is_active && user.organization_id === ctx.organizationId && user.token_version === ctx.tokenVersion;
}
