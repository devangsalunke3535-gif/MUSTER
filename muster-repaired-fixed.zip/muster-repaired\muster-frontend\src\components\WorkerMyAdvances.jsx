import { useState, useEffect } from 'react';
import api from '../api';
import { IndianRupee, Clock, Plus, X, AlertCircle } from 'lucide-react';
import { describeError, inr } from '../api';
import { useToast } from './Toast';

export default function WorkerMyAdvances() {
  const [loans, setLoans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ amount: '', reason: '' });
  const [maxAdvance, setMaxAdvance] = useState(10000);
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const { addToast } = useToast();

  const mapLoans = (data) => data.map(l => ({
    id: l.id,
    amount: l.amount,
    remaining: l.remaining_balance,
    reason: l.reason,
    status: l.status,
    requested_on: l.disbursed_date || l.created_at,
  }));

  const fetchLoans = async () => {
    try {
      const [loanRes, settingsRes] = await Promise.all([
        api.get('/loans/my-advances'),
        api.get('/loans/settings').catch(() => ({ data: { data: { max_advance_amount: 10000 } } })),
      ]);
      setLoans(mapLoans(loanRes.data?.data || []));
      setMaxAdvance(settingsRes.data?.data?.max_advance_amount ?? 10000);
      setError(null);
    } catch (err) {
      setError(describeError(err, 'Failed to load your advances'));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { fetchLoans(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post('/loans/request', { amount: Number(form.amount), reason: form.reason });
      setShowModal(false);
      setForm({ amount: '', reason: '' });
      await fetchLoans();
      addToast('Advance request submitted successfully', 'success');
    } catch (err) {
      addToast(describeError(err, 'Failed to submit request'), 'error');
    }
    setSubmitting(false);
  };

  const getStatusBadge = (status) => {
    const maps = {
      ACTIVE: 'bg-indigo-100 text-indigo-700 border-indigo-200',
      SETTLED: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      PENDING: 'bg-amber-100 text-amber-700 border-amber-200',
      REJECTED: 'bg-rose-100 text-rose-700 border-rose-200',
    };
    return `px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border ${maps[status] || maps.PENDING}`;
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight">My Advances</h1>
          <p className="text-slate-500 mt-1">Request and track your salary advances.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 text-white rounded-xl font-semibold shadow-lg shadow-primary-600/25 hover:bg-primary-700 active:scale-95 transition-all">
          <Plus size={18} /> <span className="hidden sm:inline">Request Advance</span>
        </button>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm mb-6">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-700 text-white p-5 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="absolute right-0 top-0 opacity-10 -translate-y-1/4 translate-x-1/4"><IndianRupee size={120} /></div>
          <p className="text-indigo-100 font-semibold uppercase tracking-wider text-xs mb-1">Active Balance</p>
          <p className="text-3xl font-bold relative z-10">{inr(loans.filter(l => l.status === 'ACTIVE').reduce((acc, curr) => acc + curr.remaining, 0))}</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm text-center flex flex-col justify-center">
          <p className="text-slate-400 font-semibold uppercase tracking-wider text-xs mb-1">Max Request</p>
          <p className="text-2xl font-bold text-slate-800">{inr(maxAdvance)}</p>
        </div>
      </div>

      {loading ? (
        <div className="space-y-4 animate-pulse">
          <div className="h-28 bg-slate-200 rounded-2xl"></div>
          <div className="h-28 bg-slate-200 rounded-2xl"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {loans.map(loan => (
            <div key={loan.id} className="bg-white p-5 md:p-6 rounded-2xl border border-slate-200 shadow-sm group hover:shadow-md transition-all flex flex-col md:flex-row justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center shrink-0">
                  <IndianRupee size={24} className="text-slate-400" />
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="font-bold text-lg text-slate-800">{inr(loan.amount)}</h3>
                    <span className={getStatusBadge(loan.status)}>{loan.status}</span>
                  </div>
                  <p className="text-sm text-slate-500 flex items-center gap-1">
                    <Clock size={14} /> Requested on {new Date(loan.requested_on).toLocaleDateString()}
                  </p>
                  {loan.reason && <p className="text-xs text-slate-400 mt-1">{loan.reason}</p>}
                </div>
              </div>

              {loan.status === 'ACTIVE' && (
                <div className="md:text-right border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-6 mt-2 md:mt-0">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Remaining</p>
                  <p className="text-xl font-bold text-rose-600">{inr(loan.remaining)}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden animate-slide-up sm:animate-scale-in">
            <div className="flex items-center justify-between p-5 border-b border-slate-100">
              <h2 className="font-bold text-lg text-slate-800">Request Advance</h2>
              <button onClick={() => setShowModal(false)} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">Amount Needed (₹)</label>
                <input type="number" required max={maxAdvance} value={form.amount} onChange={e => setForm({...form, amount: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-lg focus:outline-none focus:ring-2 focus:ring-primary-500/20" placeholder="e.g. 2000" />
                <p className="text-xs text-slate-400 mt-2">Max allowed: {inr(maxAdvance)}</p>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">Reason (Optional)</label>
                <textarea value={form.reason} onChange={e => setForm({...form, reason: e.target.value})} rows="2" placeholder="Medical emergency..." className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20"></textarea>
              </div>
              <button type="submit" disabled={submitting} className="w-full py-3 bg-primary-600 text-white rounded-xl font-bold shadow-lg shadow-primary-600/25 hover:bg-primary-700 active:scale-95 transition-all mt-4 disabled:opacity-60">
                {submitting ? 'Submitting...' : 'Submit Request'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
