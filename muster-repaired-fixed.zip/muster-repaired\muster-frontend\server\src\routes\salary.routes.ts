import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { auditLog } from '../middleware/audit.middleware';
import { sendError, badRequest, notFound, parseDateOnly, parsePositiveNumber, optionalString, isUuid, todayIST } from '../utils/http';
import { getEmployeeInScope, getSelfEmployee } from '../utils/access';

const router = Router();

// The SalaryComponent model has exactly these fields: name, code, type, is_active.
// (There is no value_type / default_value — amounts live on SalaryStructureItem.)
const COMPONENT_TYPES = ['EARNING', 'DEDUCTION', 'STATUTORY', 'OVERTIME'];
const WAGE_BASES = ['DAILY', 'MONTHLY', 'HOURLY'];

// ---------------------------------------------------------
// SALARY COMPONENTS
// ---------------------------------------------------------

router.get('/components', requirePermission('salary:manage'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const components = await prisma.salaryComponent.findMany({
      where: { organization_id: orgId },
      include: { _count: { select: { structureItems: { where: { structure: { status: 'ACTIVE' } } } } } },
      orderBy: [{ type: 'asc' }, { name: 'asc' }]
    });
    res.json({
      data: components.map((c: any) => {
        const { _count, ...rest } = c;
        return { ...rest, active_structure_count: _count.structureItems };
      })
    });
  } catch (error) {
    sendError(res, error, 'List salary components');
  }
});

router.post('/components', requirePermission('salary:manage'), auditLog('CREATE', 'SalaryComponent'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const name = optionalString(req.body?.name, 'name', 100);
    const code = optionalString(req.body?.code, 'code', 50)?.toUpperCase().replace(/\s+/g, '_');
    const type = String(req.body?.type || '').toUpperCase();
    if (!name) throw badRequest('name is required');
    if (!code || !/^[A-Z0-9_]+$/.test(code)) throw badRequest('code is required and may contain only letters, digits and underscores');
    if (!COMPONENT_TYPES.includes(type)) throw badRequest(`type must be one of ${COMPONENT_TYPES.join(', ')}`);

    const dup = await prisma.salaryComponent.findFirst({ where: { organization_id: orgId, code } });
    if (dup) return res.status(409).json({ error: `A component with code ${code} already exists` });

    const component = await prisma.salaryComponent.create({
      data: { organization_id: orgId, name, code, type, is_active: req.body?.is_active ?? true }
    });
    res.json({ data: component });
  } catch (error) {
    sendError(res, error, 'Create salary component');
  }
});

// PUT /salary/components/:id — rename and activate/deactivate. Code and type are
// immutable because existing structures and payroll snapshots reference them.
router.put('/components/:id', requirePermission('salary:manage'), auditLog('UPDATE', 'SalaryComponent'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const id = String(req.params.id);
    if (!isUuid(id)) throw notFound('Component not found');
    const existing = await prisma.salaryComponent.findFirst({ where: { id, organization_id: orgId } });
    if (!existing) throw notFound('Component not found');

    const data: any = {};
    const name = optionalString(req.body?.name, 'name', 100);
    if (name !== undefined) { if (!name) throw badRequest('name cannot be empty'); data.name = name; }
    if (req.body?.is_active !== undefined) {
      if (typeof req.body.is_active !== 'boolean') throw badRequest('is_active must be true or false');
      if (existing.code === 'BASIC' && req.body.is_active === false) {
        throw badRequest('BASIC cannot be deactivated: it carries every worker\'s daily wage');
      }
      data.is_active = req.body.is_active;
    }
    if (req.body?.code !== undefined && req.body.code !== existing.code) throw badRequest('code cannot be changed');
    if (req.body?.type !== undefined && req.body.type !== existing.type) throw badRequest('type cannot be changed');

    const component = await prisma.salaryComponent.update({ where: { id }, data });
    res.json({ data: component });
  } catch (error) {
    sendError(res, error, 'Update salary component');
  }
});

// ---------------------------------------------------------
// SALARY STRUCTURES
// ---------------------------------------------------------

router.get('/structures', requirePermission('salary:manage'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const employeeId = req.query.employee_id as string | undefined;
    if (!employeeId || !isUuid(employeeId)) throw badRequest('employee_id is required');
    await getEmployeeInScope(req.authContext!.userId, orgId, employeeId);
    const structures = await prisma.salaryStructure.findMany({
      where: { organization_id: orgId, employee_id: employeeId },
      include: { items: { include: { component: true } } },
      orderBy: { effective_from: 'desc' }
    });
    res.json({ data: structures });
  } catch (error) {
    sendError(res, error, 'List salary structures');
  }
});

router.post('/structures', requirePermission('salary:manage'), auditLog('CREATE', 'SalaryStructure'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const { employee_id, items } = req.body || {};

    if (!isUuid(employee_id)) return res.status(404).json({ error: 'Employee not found in your organization' });
    const employee = await prisma.employee.findFirst({ where: { id: employee_id, organization_id: orgId } });
    if (!employee) return res.status(404).json({ error: 'Employee not found in your organization' });

    const wage_basis = String(req.body?.wage_basis || '').toUpperCase();
    if (!WAGE_BASES.includes(wage_basis)) throw badRequest(`wage_basis must be one of ${WAGE_BASES.join(', ')}`);
    const effectiveFrom = req.body?.effective_from ? parseDateOnly(req.body.effective_from, 'effective_from') : todayIST();
    if (!Array.isArray(items) || items.length === 0) throw badRequest('items must be a non-empty array');

    const componentIds = items.map((i: any) => i?.component_id);
    if (componentIds.some((id: any) => !isUuid(id))) throw badRequest('Each item needs a valid component_id');
    if (new Set(componentIds).size !== componentIds.length) throw badRequest('A component may appear only once per structure');

    // Tenant check: every component must belong to THIS organization.
    const comps = await prisma.salaryComponent.findMany({ where: { id: { in: componentIds }, organization_id: orgId } });
    if (comps.length !== componentIds.length) throw badRequest('One or more salary components were not found in your organization');
    const inactive = comps.filter((c: any) => !c.is_active);
    if (inactive.length) throw badRequest(`Inactive components cannot be used: ${inactive.map((c: any) => c.name).join(', ')}`);
    if (!comps.some((c: any) => c.type === 'EARNING')) throw badRequest('A salary structure needs at least one EARNING component');

    const parsedItems = items.map((i: any) => ({
      salary_component_id: i.component_id,
      amount: parsePositiveNumber(i.amount, 'amount', { allowZero: true, max: 10_000_000 })
    }));

    const structure = await prisma.$transaction(async (tx: any) => {
      await tx.salaryStructure.updateMany({
        where: { employee_id, organization_id: orgId, status: 'ACTIVE' },
        data: { status: 'INACTIVE', effective_to: effectiveFrom }
      });
      return tx.salaryStructure.create({
        data: { organization_id: orgId, employee_id, wage_basis, effective_from: effectiveFrom, items: { create: parsedItems } },
        include: { items: true }
      });
    });
    res.json({ data: structure });
  } catch (error) {
    sendError(res, error, 'Create salary structure');
  }
});

// ---------------------------------------------------------
// WORKER SELF-SERVICE
// ---------------------------------------------------------

// Finalized payslips only — drafts can still change and must not be shown as pay.
router.get('/statements/my-salary', requirePermission('salary_statement:view'), async (req: Request, res: Response) => {
  try {
    const emp = await getSelfEmployee(req.authContext!.userId, req.authContext!.organizationId);
    if (!emp) return res.status(404).json({ error: 'Employee not found' });
    const statements = await prisma.payrollItem.findMany({
      where: { employee_id: emp.id, run: { organization_id: req.authContext!.organizationId, status: { in: ['FINALIZED', 'DISBURSED', 'LOCKED'] } } },
      include: {
        run: { include: { period: true } },
        components: { include: { component: true } },
        loanRepayments: true
      },
      orderBy: { created_at: 'desc' }
    });
    res.json({ data: statements });
  } catch (error) {
    sendError(res, error, 'My salary statements');
  }
});

export default router;
