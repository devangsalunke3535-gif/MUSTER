import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api, { fetchCsrfToken, describeError } from '../api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bootError, setBootError] = useState(null);

  const loadUser = useCallback(async () => {
    setLoading(true);
    setBootError(null);
    try {
      await fetchCsrfToken();
    } catch (err) {
      // Backend down: say so, instead of silently showing the login page.
      setBootError(describeError(err));
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const res = await api.get('/auth/me');
      setUser(res.data.user);
    } catch (err) {
      if (err.response?.status !== 401) setBootError(describeError(err));
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadUser(); }, [loadUser]);

  const login = async (email, password) => {
    try {
      await fetchCsrfToken();
      const res = await api.post('/auth/login', { email, password });
      setUser(res.data.user);
      setBootError(null);
      return { success: true, user: res.data.user };
    } catch (err) {
      const status = err.response?.status;
      const serverMessage = err.response?.data?.error;
      let error;
      if (!err.response) error = 'Cannot reach the MUSTER server. Please try again.';
      else if ([502, 503, 504].includes(status)) error = 'The MUSTER server is unavailable. Please try again shortly.';
      else if (status === 401) error = 'Invalid email or password';
      else if (status === 403) {
        try { await fetchCsrfToken(); } catch { /* reported on next attempt */ }
        error = 'Your session token expired. Please try again.';
      }
      else if (status === 409) error = serverMessage || 'Multiple accounts found. Please contact your administrator.';
      else if (status === 429) error = serverMessage || 'Too many login attempts. Please try again later.';
      else if (status === 400) error = serverMessage || 'Please provide both email and password.';
      else if (status >= 500) error = 'Server error. Please try again.';
      else error = serverMessage || 'An unexpected error occurred.';
      return { success: false, error };
    }
  };

  const logout = async () => {
    try {
      await api.post('/auth/logout');
    } catch {
      // Even if the server is unreachable, drop the local session.
    } finally {
      setUser(null);
      window.location.href = '/login';
    }
  };

  const permissions = new Set(user?.permissions || []);
  const hasPermission = (code) => !!user && (user.is_super_admin || permissions.has(code));
  // A "worker" is anyone whose only role is WORKER (not a super admin).
  const isWorker = !!user && !user.is_super_admin && (user.roles || []).length > 0 && user.roles.every((r) => r === 'WORKER');
  const displayName = user?.employee
    ? `${user.employee.first_name} ${user.employee.last_name}`.trim()
    : (user?.email || '');
  const roleLabel = user?.is_super_admin ? 'Super Admin'
    : (user?.userRoles || []).map((ur) => ur.role?.name).filter(Boolean).join(', ') || 'No role';

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, bootError, refetchUser: loadUser, hasPermission, isWorker, displayName, roleLabel }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
