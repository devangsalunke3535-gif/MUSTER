import request from 'supertest';
import app from '../server';
import { prisma } from '../config/db';
import * as argon2 from 'argon2';

describe('Phase 5 Integration Tests (Labour / Worker Payroll Engine)', () => {
  let csrfToken: string;
  let csrfCookie: string;
  let authCookieOrgA: string;
  
  let orgAId: string;
  let empDailyId: string;
  let empMonthlyId: string;
  
  let basicComponentId: string;
  let pfComponentId: string;
  let periodId: string;
  let runId: string;
  let loanId: string;

  beforeAll(async () => {
    // Teardown everything
    await prisma.payrollItemComponent.deleteMany();
    await prisma.loanRepayment.deleteMany();
    await prisma.payrollItem.deleteMany();
    await prisma.payrollRun.deleteMany();
    await prisma.payrollPeriod.deleteMany();
    
    await prisma.loan.deleteMany();
    await prisma.salaryStructureItem.deleteMany();
    await prisma.salaryStructure.deleteMany();
    await prisma.salaryComponent.deleteMany();
    
    await prisma.attendance.deleteMany();
    await prisma.holiday.deleteMany();
    
    await prisma.userRole.deleteMany();
    await prisma.rolePermission.deleteMany();
    await prisma.permission.deleteMany();
    await prisma.role.deleteMany();
    await prisma.employment.deleteMany();
    await prisma.employee.deleteMany();
    await prisma.shift.deleteMany();
    await prisma.user.deleteMany();
    await prisma.organization.deleteMany();

    // Create Organization
    const orgA = await prisma.organization.create({ data: { name: 'Factory Org A', code: 'FA', legal_name: 'Factory Org A Ltd' } });
    orgAId = orgA.id;

    // Create Permissions & Admin
    const p1 = await prisma.permission.create({ data: { module: 'salary', action: 'manage', code: 'salary:manage' } });
    const p2 = await prisma.permission.create({ data: { module: 'payroll', action: 'manage', code: 'payroll:manage' } });
    const p3 = await prisma.permission.create({ data: { module: 'payroll', action: 'create', code: 'payroll:create' } });
    const p4 = await prisma.permission.create({ data: { module: 'payroll', action: 'calculate', code: 'payroll:calculate' } });
    const p5 = await prisma.permission.create({ data: { module: 'payroll', action: 'finalize', code: 'payroll:finalize' } });
    const p6 = await prisma.permission.create({ data: { module: 'loan', action: 'manage', code: 'loan:manage' } });
    const p7 = await prisma.permission.create({ data: { module: 'salary_statement', action: 'view', code: 'salary_statement:view' } });

    const roleA = await prisma.role.create({ data: { organization_id: orgA.id, name: 'Payroll Admin', code: 'PAYROLL' } });
    await prisma.rolePermission.createMany({
      data: [p1, p2, p3, p4, p5, p6, p7].map(p => ({ role_id: roleA.id, permission_id: p.id }))
    });

    const hash = await argon2.hash('testpass123');
    const adminA = await prisma.user.create({ data: { organization_id: orgA.id, email: 'admin@factory.com', password_hash: hash, is_active: true } });
    await prisma.userRole.create({ data: { user_id: adminA.id, role_id: roleA.id, scope_organization_id: orgA.id } });

    const empAdmin = await prisma.employee.create({ data: { organization_id: orgA.id, user_id: adminA.id, emp_id: 'E00', first_name: 'Admin', last_name: 'A' } });

    // Create 2 Workers (Daily and Monthly)
    const workerDailyUser = await prisma.user.create({ data: { organization_id: orgA.id, email: 'w1@factory.com', password_hash: hash, is_active: true } });
    await prisma.userRole.create({ data: { user_id: workerDailyUser.id, role_id: roleA.id, scope_organization_id: orgA.id } });
    const workerDaily = await prisma.employee.create({ data: { organization_id: orgA.id, user_id: workerDailyUser.id, emp_id: 'W01', first_name: 'Daily', last_name: 'Worker' } });
    await prisma.employment.create({ data: { employee_id: workerDaily.id, joining_date: new Date(), status: 'ACTIVE' } });
    empDailyId = workerDaily.id;

    const workerMonthlyUser = await prisma.user.create({ data: { organization_id: orgA.id, email: 'w2@factory.com', password_hash: hash, is_active: true } });
    await prisma.userRole.create({ data: { user_id: workerMonthlyUser.id, role_id: roleA.id, scope_organization_id: orgA.id } });
    const workerMonthly = await prisma.employee.create({ data: { organization_id: orgA.id, user_id: workerMonthlyUser.id, emp_id: 'W02', first_name: 'Monthly', last_name: 'Worker' } });
    await prisma.employment.create({ data: { employee_id: workerMonthly.id, joining_date: new Date(), status: 'ACTIVE' } });
    empMonthlyId = workerMonthly.id;
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('1. Setup Auth & CSRF', async () => {
    const res = await request(app).get('/api/v1/auth/csrf');
    csrfToken = res.body.csrfToken;
    csrfCookie = res.headers['set-cookie'][0];

    const loginA = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'admin@factory.com', password: 'testpass123' });
    const cookiesA = Array.isArray(loginA.headers['set-cookie']) ? loginA.headers['set-cookie'] : [loginA.headers['set-cookie']];
    authCookieOrgA = cookiesA.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];
  });

  it('2. Create Salary Components (Base & PF)', async () => {
    const r1 = await request(app).post('/api/v1/salary/components').set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken)
      .send({ name: 'Basic Wage', code: 'BASIC', type: 'EARNING' });
    
    const r2 = await request(app).post('/api/v1/salary/components').set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken)
      .send({ name: 'Provident Fund', code: 'PF', type: 'STATUTORY' });

    expect(r1.status).toBe(200);
    basicComponentId = r1.body.data.id;
    pfComponentId = r2.body.data.id;
  });

  it('3. Configure Salary Structures (Daily vs Monthly)', async () => {
    // W1: Daily ₹700 + Fixed 50 PF
    const req1 = await request(app).post('/api/v1/salary/structures').set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken)
      .send({
        employee_id: empDailyId, wage_basis: 'DAILY', effective_from: new Date().toISOString(),
        items: [{ component_id: basicComponentId, amount: 700 }, { component_id: pfComponentId, amount: 50 }]
      });
      
    // W2: Monthly ₹18000 + Fixed 100 PF
    const req2 = await request(app).post('/api/v1/salary/structures').set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken)
      .send({
        employee_id: empMonthlyId, wage_basis: 'MONTHLY', effective_from: new Date().toISOString(),
        items: [{ component_id: basicComponentId, amount: 18000 }, { component_id: pfComponentId, amount: 100 }]
      });

    expect(req1.status).toBe(200);
    expect(req2.status).toBe(200);
  });

  it('4. Issue Loan / Advance to Daily Worker', async () => {
    const req = await request(app).post('/api/v1/loans').set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken)
      .send({ employee_id: empDailyId, amount: 2000, disbursed_date: new Date().toISOString() });
    
    expect(req.status).toBe(200);
    loanId = req.body.data.id;
  });

  it('5. Seed Attendance Data (1.5 days for Daily, 2 days for Monthly)', async () => {
    const d1 = new Date(new Date().getFullYear(), new Date().getMonth(), 10);
    const d2 = new Date(new Date().getFullYear(), new Date().getMonth(), 11);

    // W1: 1 Present, 1 Half-Day => 1.5 days payable
    await prisma.attendance.createMany({
      data: [
        { organization_id: orgAId, employee_id: empDailyId, date: d1, status: 'PRESENT', total_worked_mins: 480 },
        { organization_id: orgAId, employee_id: empDailyId, date: d2, status: 'HALF_DAY', total_worked_mins: 240 }
      ]
    });

    // W2: 2 Present => 2 days payable (prorated out of 30)
    await prisma.attendance.createMany({
      data: [
        { organization_id: orgAId, employee_id: empMonthlyId, date: d1, status: 'PRESENT', total_worked_mins: 480 },
        { organization_id: orgAId, employee_id: empMonthlyId, date: d2, status: 'PRESENT', total_worked_mins: 480 }
      ]
    });
  });

  it('6. Create Payroll Period & Run', async () => {
    const dStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const dEnd = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);

    const r1 = await request(app).post('/api/v1/payroll/periods').set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken)
      .send({ name: 'Current Month', start_date: dStart.toISOString(), end_date: dEnd.toISOString() });
    expect(r1.status).toBe(200);
    periodId = r1.body.data.id;

    const r2 = await request(app).post('/api/v1/payroll/runs').set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken)
      .send({ payroll_period_id: periodId });
    expect(r2.status).toBe(200);
    runId = r2.body.data.id;
  });

  it('7. Run Payroll Calculation Engine', async () => {
    const res = await request(app).post(`/api/v1/payroll/runs/${runId}/calculate`).set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken);
    expect(res.status).toBe(200);
    
    // Validate Snapshot outputs!
    const dailyItem = await prisma.payrollItem.findFirst({ where: { employee_id: empDailyId, payroll_run_id: runId } });
    const monthlyItem = await prisma.payrollItem.findFirst({ where: { employee_id: empMonthlyId, payroll_run_id: runId } });

    // W1 (Daily): 1.5 Days * 700 = 1050 Gross. PF = 50. Loan Recovery = 1050 * 0.1 = 105. 
    // Net = 1050 - 50 - 105 = 895
    expect(dailyItem?.payable_days).toBe(1.5);
    expect(dailyItem?.gross_earnings).toBe(1050);
    expect(dailyItem?.total_deductions).toBe(155);
    expect(dailyItem?.net_pay).toBe(895);

    // W2 (Monthly): 2 Days * (18000/30 = 600) = 1200 Gross. PF = 100.
    // Net = 1200 - 100 = 1100
    expect(monthlyItem?.payable_days).toBe(2);
    expect(monthlyItem?.gross_earnings).toBe(1200);
    expect(monthlyItem?.total_deductions).toBe(100);
    expect(monthlyItem?.net_pay).toBe(1100);

    // Validate Loan Repayment was generated and balance adjusted
    const loan = await prisma.loan.findUnique({ where: { id: loanId } });
    expect(loan?.remaining_balance).toBe(2000 - 105);
  });

  it('8. Finalize Payroll Run (Immutability Lock)', async () => {
    const res = await request(app).post(`/api/v1/payroll/runs/${runId}/finalize`).set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]).set('CSRF-Token', csrfToken);
    expect(res.status).toBe(200);
    expect(res.body.data.status).toBe('FINALIZED');
  });

  it('9. Verify Worker Self-Service Salary Statement', async () => {
    // Switch auth context to W1
    const loginW1 = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'w1@factory.com', password: 'testpass123' });
    const cookiesW1 = Array.isArray(loginW1.headers['set-cookie']) ? loginW1.headers['set-cookie'] : [loginW1.headers['set-cookie']];
    const authW1 = cookiesW1.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];

    const res = await request(app).get('/api/v1/salary/statements/my-salary').set('Cookie', [`${csrfCookie}`, `${authW1}`]).set('CSRF-Token', csrfToken);
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(1);
    expect(res.body.data[0].net_pay).toBe(895);
    expect(res.body.data[0].loanRepayments.length).toBe(1);
  });
});
