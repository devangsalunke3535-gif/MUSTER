import { Response } from 'express';

/** An error whose message is safe to show to the client, with an HTTP status. */
export class AppError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export const badRequest = (m: string) => new AppError(400, m);
export const forbidden = (m: string) => new AppError(403, m);
export const notFound = (m: string) => new AppError(404, m);
export const conflict = (m: string) => new AppError(409, m);

/**
 * Send an error response. AppErrors carry their own status/message. Known
 * Prisma errors are mapped to safe messages. Anything else is a 500 with a
 * generic message (the detail is logged server-side, never sent to the client).
 */
export function sendError(res: Response, err: any, context = 'Request') {
  if (err instanceof AppError) {
    return res.status(err.status).json({ error: err.message });
  }
  if (err?.code === 'P2002') {
    return res.status(409).json({ error: 'A record with these unique values already exists.' });
  }
  if (err?.code === 'P2025') {
    return res.status(404).json({ error: 'Record not found.' });
  }
  if (err?.code === 'P2023' || err?.code === 'P2007') {
    return res.status(400).json({ error: 'Malformed identifier or value.' });
  }
  console.error(`${context} failed:`, err?.message || err);
  return res.status(500).json({ error: 'Internal server error' });
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const isUuid = (v: unknown): boolean => typeof v === 'string' && UUID_RE.test(v);

export function requireUuid(v: unknown, field: string): string {
  if (!isUuid(v)) throw badRequest(`${field} must be a valid UUID`);
  return v as string;
}

/**
 * Parse a calendar date. Accepts "YYYY-MM-DD" or an ISO datetime string, and
 * returns midnight UTC of the leading date part — the same value Prisma stores
 * in a @db.Date column. Throws a 400 on anything else.
 */
export function parseDateOnly(v: unknown, field: string): Date {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}/.test(v)) {
    throw badRequest(`${field} must be a date in YYYY-MM-DD format`);
  }
  const d = new Date(`${v.slice(0, 10)}T00:00:00.000Z`);
  if (isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v.slice(0, 10)) {
    throw badRequest(`${field} is not a valid calendar date`);
  }
  return d;
}

export const toDateKey = (d: Date) => d.toISOString().slice(0, 10);

/** Today's calendar date in India (Asia/Kolkata), as midnight UTC. */
export function todayIST(): Date {
  const s = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
  return new Date(`${s}T00:00:00.000Z`);
}

export function addDaysUTC(d: Date, days: number): Date {
  const r = new Date(d.getTime());
  r.setUTCDate(r.getUTCDate() + days);
  return r;
}

export function parsePositiveNumber(v: unknown, field: string, opts: { allowZero?: boolean; max?: number } = {}): number {
  const n = typeof v === 'string' && v.trim() !== '' ? Number(v) : typeof v === 'number' ? v : NaN;
  if (!Number.isFinite(n) || n < 0 || (!opts.allowZero && n === 0)) {
    throw badRequest(`${field} must be a ${opts.allowZero ? 'non-negative' : 'positive'} number`);
  }
  if (opts.max !== undefined && n > opts.max) throw badRequest(`${field} cannot exceed ${opts.max}`);
  return n;
}

/** Round money to paise to avoid floating-point drift in stored values. */
export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export function optionalString(v: unknown, field: string, max = 255): string | undefined {
  if (v === undefined || v === null) return undefined;
  if (typeof v !== 'string') throw badRequest(`${field} must be a string`);
  const t = v.trim();
  if (t.length > max) throw badRequest(`${field} is too long (max ${max})`);
  return t;
}
