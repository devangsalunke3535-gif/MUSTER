import request from 'supertest';
import app from '../server';
import { prisma } from '../config/db';
import * as argon2 from 'argon2';

describe('Phase 2 Integration Tests (Employee Domain)', () => {
  let csrfToken: string;
  let csrfCookie: string;
  let authCookieOrgA: string;
  let authCookieOrgB: string;
  
  let orgAId: string;
  let orgBId: string;
  let empAId: string;

  beforeAll(async () => {
    // Teardown
    await prisma.employeeBankAccount.deleteMany();
    await prisma.employeeAssignmentHistory.deleteMany();
    await prisma.employeeStatusHistory.deleteMany();
    await prisma.employment.deleteMany();
    await prisma.employee.deleteMany();
    await prisma.userRole.deleteMany();
    await prisma.rolePermission.deleteMany();
    await prisma.permission.deleteMany();
    await prisma.role.deleteMany();
    await prisma.auditLog.deleteMany();
    await prisma.branch.deleteMany();
    await prisma.shift.deleteMany();
    await prisma.user.deleteMany();
    await prisma.organization.deleteMany();

    // Create Organizations
    const orgA = await prisma.organization.create({ data: { name: 'Org A', code: 'ORGA', legal_name: 'Org A Ltd' } });
    const orgB = await prisma.organization.create({ data: { name: 'Org B', code: 'ORGB', legal_name: 'Org B Ltd' } });
    orgAId = orgA.id;
    orgBId = orgB.id;

    // Create Roles and Permissions
    const perm = await prisma.permission.create({ data: { module: 'employee', action: 'view_bank', code: 'employee:bank:view' } });
    const role = await prisma.role.create({ data: { organization_id: orgA.id, name: 'HR', code: 'HR' } });
    await prisma.rolePermission.create({ data: { role_id: role.id, permission_id: perm.id } });

    // Create Super Admins for both orgs
    const hash = await argon2.hash('testpass123');
    const adminA = await prisma.user.create({ data: { organization_id: orgA.id, email: 'adminA@test.com', password_hash: hash, is_active: true, is_super_admin: true } });
    await prisma.user.create({ data: { organization_id: orgB.id, email: 'adminB@test.com', password_hash: hash, is_active: true, is_super_admin: true } });
    
    await prisma.userRole.create({ data: { user_id: adminA.id, role_id: role.id, scope_organization_id: orgA.id } });
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('1. Setup Auth & CSRF for Org A & Org B', async () => {
    const res = await request(app).get('/api/v1/auth/csrf');
    csrfToken = res.body.csrfToken;
    csrfCookie = res.headers['set-cookie'][0];

    const loginA = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'adminA@test.com', password: 'testpass123' });
    const cookiesA = Array.isArray(loginA.headers['set-cookie']) ? loginA.headers['set-cookie'] : [loginA.headers['set-cookie']];
    authCookieOrgA = cookiesA.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];

    const loginB = await request(app).post('/api/v1/auth/login').set('Cookie', csrfCookie).set('CSRF-Token', csrfToken).send({ email: 'adminB@test.com', password: 'testpass123' });
    const cookiesB = Array.isArray(loginB.headers['set-cookie']) ? loginB.headers['set-cookie'] : [loginB.headers['set-cookie']];
    authCookieOrgB = cookiesB.find((c: any) => typeof c === 'string' && c.startsWith('muster_session')).split(';')[0];
  });

  it('2. Create Employee with Transactional Ledgers (Org A)', async () => {
    const res = await request(app)
      .post('/api/v1/employees')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        emp_id: 'EMP001',
        first_name: 'John',
        last_name: 'Doe',
        email: 'john.doe@test.com',
        joining_date: '2024-01-01',
        status: 'ACTIVE'
      });
    
    expect(res.status).toBe(200);
    expect(res.body.data.id).toBeDefined();
    empAId = res.body.data.id;

    // Verify ledgers created
    const statusHist = await prisma.employeeStatusHistory.findFirst({ where: { employee_id: empAId } });
    expect(statusHist).toBeDefined();
    expect(statusHist?.status).toBe('ACTIVE');

    const assignHist = await prisma.employeeAssignmentHistory.findFirst({ where: { employee_id: empAId } });
    expect(assignHist).toBeDefined();
  });

  it('3. Tenant Isolation - Org B cannot GET Org A Employee', async () => {
    const res = await request(app)
      .get('/api/v1/employees')
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgB}`]);
    if (res.status !== 200) console.error('Tenant Isolation 500 error:', res.body);
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(0); // Org B has no employees
  });

  it('4. Bank Account Creation & Audit Logging Masking', async () => {
    const res = await request(app)
      .post(`/api/v1/employees/${empAId}/bank`)
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`])
      .set('CSRF-Token', csrfToken)
      .send({
        bank_name: 'HDFC',
        branch_name: 'Mumbai',
        account_number: '1234567890',
        ifsc_code: 'HDFC0001234',
        account_type: 'SAVINGS'
      });
    
    expect(res.status).toBe(200);

    // Verify DB encrypted
    const bank = await prisma.employeeBankAccount.findFirst({ where: { employee_id: empAId } });
    expect(bank?.account_number_enc).toContain(':'); // IV:AuthTag:Cipher format
    expect(bank?.account_number_enc).not.toContain('1234567890');

    // Verify Audit log doesn't contain raw account number
    await new Promise(r => setTimeout(r, 100)); // allow async audit
    const logs = await prisma.auditLog.findFirst({ where: { entity_type: 'EmployeeBankAccount' }, orderBy: { timestamp: 'desc' } });
    const oldVals = logs?.old_values as any;
    expect(oldVals.account_number).toBe('[REDACTED]');
  });

  it('5. Bank Account Decryption (Requires employee:bank:view)', async () => {
    // Org A Admin has implicit access via is_super_admin = true
    const res = await request(app)
      .get(`/api/v1/employees/${empAId}/bank`)
      .set('Cookie', [`${csrfCookie}`, `${authCookieOrgA}`]);
    
    expect(res.status).toBe(200);
    expect(res.body.data.account_number).toBe('1234567890'); // Unmasked since super admin
  });
});
