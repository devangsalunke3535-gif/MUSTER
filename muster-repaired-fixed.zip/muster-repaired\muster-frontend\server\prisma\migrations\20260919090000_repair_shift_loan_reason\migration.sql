-- Repair migration (idempotent).
--
-- Employee.default_shift_id existed in schema.prisma but NO previous migration
-- created it: a database built with `prisma migrate deploy` was missing the
-- column, while one built with `prisma db push` already has it. Every statement
-- below is guarded so this is safe to apply to either. It never drops data.

-- 1. Employee.default_shift_id (+ FK, + index)
ALTER TABLE "Employee" ADD COLUMN IF NOT EXISTS "default_shift_id" UUID;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'Employee_default_shift_id_fkey') THEN
    ALTER TABLE "Employee"
      ADD CONSTRAINT "Employee_default_shift_id_fkey"
      FOREIGN KEY ("default_shift_id") REFERENCES "Shift"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS "Employee_default_shift_id_idx" ON "Employee"("default_shift_id");

-- 2. Loan.reason (the advance-request form collected a reason that was silently discarded)
ALTER TABLE "Loan" ADD COLUMN IF NOT EXISTS "reason" TEXT;

-- 3. A payroll item may deduct a given loan at most once (defence in depth for idempotent recalculation).
--    If historical duplicates exist the index is skipped with a NOTICE instead of failing the deploy;
--    investigate with:  SELECT loan_id, payroll_item_id, count(*) FROM "LoanRepayment" GROUP BY 1,2 HAVING count(*) > 1;
DO $$
BEGIN
  CREATE UNIQUE INDEX IF NOT EXISTS "LoanRepayment_loan_id_payroll_item_id_key" ON "LoanRepayment"("loan_id", "payroll_item_id");
EXCEPTION WHEN unique_violation THEN
  RAISE NOTICE 'Duplicate LoanRepayment rows exist; unique index not created. Clean up duplicates and re-run.';
END $$;

-- 4. Server-side session revocation: JWTs carry the user's token_version; logout and
--    password change increment it so previously issued tokens stop working immediately.
--    Existing tokens (no version claim) are treated as version 0, so deploying this logs nobody out.
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "token_version" INTEGER NOT NULL DEFAULT 0;
