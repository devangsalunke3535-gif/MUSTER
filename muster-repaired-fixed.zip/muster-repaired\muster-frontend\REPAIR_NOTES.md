# MUSTER Repair — Status, Runbook, and What's Left

This package is a **partial** repair of the audit checklist: the backend is
finished and typechecks/tests clean; the frontend has 15 of ~21 pages rewired
to match the new API. Everything below is stated plainly — nothing here is
claimed "done" unless it was actually executed in the sandbox that produced
this package (no Postgres, no network, no matching-OS native binaries — see
"What could and couldn't be verified here").

## 1. What's actually verified here

- **Backend `tsc --noEmit`** against the real `tsconfig.json`, with a freshly
  regenerated Prisma client (from the updated schema) and the project's real
  `node_modules` — **0 errors**, across `src/`, `prisma/seed.ts`, and every
  `__tests__/*.ts` file.
- **27 executable unit tests actually run and passing** (not just written):
  - `server/src/__tests__/payroll_engine.unit.test.ts` (12 tests) — runs the
    real `PayrollService` against an in-memory Prisma stand-in: idempotent
    recalculation, the multi-loan TOTAL cap, net pay never negative, paid
    leave, MONTHLY-vs-DAILY holiday handling, FINALIZED immutability, and the
    "no salary structure → warning, not silent skip" rule.
  - `server/src/__tests__/logic.unit.test.ts` (15 tests) — the real
    `recordDecision` approval-authorization logic, real IST/night-shift
    attendance timing, shift classification, date parsing.
- **11 live-server smoke checks**, booting the actual `server.ts` Express app
  in-process (no DB) via supertest: CSRF enforcement, 400 vs 401 vs 403
  contract, forged-JWT rejection, logout-without-session still clearing the
  cookie, unknown API routes returning JSON not HTML, malformed-JSON handling.
- **Frontend**: every `.jsx`/`.js` file under `src/` parses with a real JS
  parser (`@babel/parser`, JSX plugin) — 0 syntax errors across 27 files,
  re-confirmed after every edit including the final pass — and every relative
  import (`./x`, `../y`) resolves to a file that exists. Every bare package
  import (`react`, `lucide-react`, etc.) is confirmed present in
  `package.json`. This check catches syntax errors and broken imports; it
  does **not** catch runtime-only bugs (wrong prop names, undefined browser
  globals) — one such bug (`process.env.NODE_ENV` used in a Vite bundle,
  where it doesn't exist) was caught by manual code review instead, in
  `ErrorBoundary.jsx`, and fixed. There is no guarantee no others remain
  outside what an actual `npm run build` + browser session would catch.

## 2. What could NOT be verified here, and why

This sandbox is Linux x86_64 with no network access. It has no Postgres
server, and the checked-in `node_modules` contain **macOS ARM64** native
binaries (Prisma's query engine, Jest's native resolver, Vite/Rolldown's
bundler). None of those will load on this machine. Concretely, NOT run here:

- `npm run build` (Vite) — cannot confirm the production bundle actually
  compiles, only that every file parses and every import resolves.
- The full Jest suite against a real database — `payroll_engine.unit.test.ts`
  and `logic.unit.test.ts` don't need one and did run; every `*.test.ts` file
  that touches Prisma (the original `phase*.test.ts`, `auth_regression.test.ts`,
  `p0_security.test.ts`, `p1_functional.test.ts`, and the new
  `repair_regression.test.ts`) needs `muster_test` and has not been executed.
- `prisma migrate deploy` against a real database.
- Any actual browser session — no click was ever tested in a real browser.

**You must run the commands in Section 4 yourself** before trusting this is
correct end-to-end. Section 5 is the manual browser checklist for what's left
after that.

## 3. Root causes found and fixed (backend — complete)

1. **Wage displayed as "—"**: `api.js` read `item.salaryComponent?.code`; the
   API returns the relation as `component`. Fixed by returning a
   server-computed DTO (`daily_wage`, `wage`, `shift`, `shift_type`, `status`,
   `branch`, `has_uan`, `has_esi`) so the frontend never re-derives it wrong.
2. **Shift schema drift**: `Employee.default_shift_id` was declared in
   `schema.prisma` but no migration created the column. Fixed with an
   idempotent repair migration (`20260919090000_repair_shift_loan_reason`)
   safe to run whether the DB was built with `migrate` or `db push`.
3. **Seed created no permissions and no role→permission mappings** — manager
   and worker got 403 on almost everything; the previous "fix" was an ad-hoc
   script (`restore_permissions.ts`) run by hand. Replaced with one
   idempotent `prisma/seed.ts` driven by `src/config/permissions.ts` (a single
   source of truth also usable by tests), safe to run repeatedly.
4. **RBAC holes**: workers held `attendance:create`/`attendance:view`, which
   gated the org-wide `/attendance/mark`, `/attendance/date/:date` and
   `/dashboard/*` routes — a worker could mark anyone's attendance and see
   the whole roster. Split into `attendance:create` (self only) vs
   `attendance:manage` (others). Also fixed: `/loans/request` had no
   permission check; salary structures and payroll periods accepted
   cross-tenant IDs (P0 IDOR).
5. **Approval races**: leave/loan approval checked `status === 'PENDING'`
   outside the transaction, so concurrent approvals could double-spend a
   leave balance or double-approve a loan. Loan approval never touched
   `ApprovalRequest`/`ApprovalStep`/`ApprovalAction` at all. Fixed with a
   shared `services/approval.service.ts`: the PENDING→decided transition is
   claimed with a conditional `updateMany` inside the same transaction as the
   workflow records, for both leave and loans.
6. **Payroll**: the loan cap was 10% *per loan* (two loans = 20% deducted);
   fixed to a single TOTAL cap across all of an employee's loans, oldest
   first. Recalculating a run is now provably idempotent (see the unit
   tests). A run is claimed via `PROCESSING` status before any calculation
   runs, so concurrent `calculate` calls on the same run cannot corrupt it.
7. **`DELETE /employees/:id` hard-deleted** — this cascades through
   attendance, leave, loans and finalized payroll items (schema uses
   `onDelete: Cascade` throughout). Changed to a safe deactivation that keeps
   every historical record.
8. **Night-shift attendance broke at midnight**: check-out looked up
   `today`'s row only, so an 11pm check-in couldn't be checked out after
   midnight. Fixed with IST-aware, shift-crossing-midnight-aware timing
   (`services/attendance.service.ts`, unit-tested).
9. **Check-in used "the first active shift in the org"** instead of the
   worker's own persisted shift. Fixed.
10. **Logout required a valid token** and JWTs were never revoked
    server-side — a copied cookie kept working forever, and an
    already-expired session could never even be cleared. Added
    `User.token_version`; logout and password-change bump it, and every
    request re-checks it.
11. **`server.ts` never loaded `dotenv`**, and called `app.listen()` at
    import time — the latter breaks multiple Jest test files sharing one
    process (`EADDRINUSE`). Both fixed; `NODE_ENV=test` skips `listen()`.

Full per-domain detail (attendance, leave, loans, payroll, salary, dashboard,
security) is in the code comments at the top of each rewritten
`server/src/routes/*.ts` and `server/src/services/*.ts` file.

## 4. Setup — run these yourself

```bash
# 1. Install
cd server && npm install
cd .. && npm install

# 2. Configure secrets (never commit .env)
cd server
cp .env.example .env
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"   # → JWT_SECRET
node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"   # → ENCRYPTION_KEY (must be exactly 32 chars)
# edit .env: paste those in, set DATABASE_URL to your local Postgres

cp .env.test.example .env.test
# edit .env.test: DATABASE_URL must end in a database name that ends with "_test"
#   (jest.db-guard.js refuses to run otherwise — the test suites TRUNCATE every table)

# 3. Database
createdb muster            # if it doesn't exist
createdb muster_test       # if it doesn't exist
npx prisma migrate deploy  # applies the repair migration too
npx prisma generate
npm run seed                # idempotent — safe to re-run, never destructive

# 4. Run the backend test suite for real (needs muster_test)
npm test
# Expect: payroll_engine.unit.test.ts and logic.unit.test.ts pass (verified
# here already). The DB-backed suites — phase2/3/4/5, auth_regression,
# p0_security, p1_functional, and the new repair_regression.test.ts — have
# NOT been run in this sandbox; check their output carefully.
# Two of the original fixtures were changed to add a real (non-self) approver
# — see the diff in phase3.test.ts / phase4.test.ts — because self-approval
# is now intentionally blocked (P0 fix: you can no longer approve your own
# request just by holding the permission).

# 5. Start the app
cd server && npm run dev      # http://localhost:3000
cd .. && npm run dev           # http://localhost:5173 (Vite proxies /api to :3000)
```

Demo logins after seeding (password `admin123`):
`admin@muster.com`, `manager@muster.com`, `worker@muster.com`.

## 5. Frontend — every file is now rewired

All 23 `.jsx`/`.js` files under `src/` have been updated to match the new
backend contract (server-computed DTOs, real UUIDs, honest empty/error
states, no fabricated data). In addition to what was listed in the previous
pass (`api.js`, `AuthContext.jsx`, `ProtectedRoute.jsx`, `App.jsx`,
`Sidebar.jsx`, `Topbar.jsx`, `Workers.jsx`, `WorkerDetail.jsx`,
`Attendance.jsx`, `Dashboard.jsx`, `WorkerHome.jsx`,
`WorkerMyAttendance.jsx`, `WorkerMyLeave.jsx`, `SalaryConfig.jsx`,
`PayrollAdmin.jsx`, `Approvals.jsx` [new]), this pass finished:

- **`Login.jsx`** — removed the hardcoded "200+ Workers Managed / 99.2%
  Uptime" marketing numbers (nothing on the login screen is fabricated now).
  "Forgot password?" no longer does nothing — it shows an honest message
  ("not self-service yet, contact your administrator") since there is no
  password-reset flow in this system. Removed the "Remember me" checkbox,
  which never did anything (the session length was always a fixed 8h
  regardless of its state).
- **`Settings.jsx`** — Company Profile now really persists, via the
  `PUT /organization` endpoint (edit fields locked behind the `org:update`
  permission, same as the backend enforces). Security tab now really changes
  the password via `POST /auth/change-password` (revokes every other
  session, matching the backend's token-revocation design). Notifications
  tab is explicitly labeled and disabled — MUSTER has no email/SMS provider
  wired up anywhere in this codebase, so the toggles are shown as an
  honestly-unavailable preview instead of a fake "Saved!" button.
- **`Reports.jsx`** — "Export CSV" now really exports the report currently
  on screen (client-side CSV of already-loaded data — no server round-trip
  needed). Also fixed a real NaN bug: the UAN/ESI coverage percentages
  divided by `compliance.total` with no zero-guard, so an org with zero
  active workers would render "NaN%"; now uses the server's null-safe
  `uan_coverage`/`esi_coverage` fields and shows "—" when there's nothing to
  measure.
- **`LeaveAdmin.jsx`, `AdvancesAdmin.jsx`** — now read the `can_decide` field
  the API returns and hide the Approve/Reject buttons (showing "Not your
  step" instead) when the signed-in manager isn't the assigned approver for
  that request, instead of showing buttons that would just 403. Refetch
  after every decision rather than optimistically assuming the write
  matched what was sent. `AdvancesAdmin.jsx` also now shows the real
  `reason` text the worker submitted.
- **`WorkerMySalary.jsx`, `WorkerMyAdvances.jsx`** — consistent error
  handling via the shared `describeError` helper. `WorkerMyAdvances.jsx` now
  fetches the real server-configured advance cap (`GET /loans/settings`,
  defaults to ₹10,000, an actual `OrganizationSetting` row seeded by
  `prisma/seed.ts`) instead of a hardcoded ₹10,000 in the form, and shows the
  worker's own submitted reason on each advance card. The EMI field, which
  was already an honest "—" placeholder rather than a fabricated number
  (there is no EMI-schedule field in the data model), was removed entirely
  rather than kept as a permanent placeholder.
- **`ErrorBoundary.jsx`** — found and fixed a real, separate bug while
  reviewing it: it read `process.env.NODE_ENV`, which does not exist in a
  Vite browser bundle (this project's `vite.config.js` has no `define` shim
  for it) — so the error boundary would throw its own `ReferenceError` at
  exactly the moment a user hits a real error and needs the fallback UI to
  work. Changed to Vite's own `import.meta.env.DEV`.
- **`Toast.jsx`, `Layout.jsx`** — read in full and confirmed to have no
  backend dependency and no bug; left as-is.

## 6. Manual browser checklist (do this after Section 4 runs clean)

Follow the ADMIN → ATTENDANCE → WORKER → MANAGER → PAYROLL sequence from the
original audit brief:
1. Login as admin → Directory → Add Worker (₹800/day, Night shift) → **hard
   refresh the browser** → confirm ₹800 and Night are still shown.
2. Edit that worker (wage → 900, phone changed) → save → refresh → confirm
   both persist.
3. Attendance → mark them Present → change the date and back → confirm it's
   still Present.
4. Logout. Login as worker@muster.com. Check In → refresh → Check Out →
   confirm the shift shown is the worker's own (Day Shift, from seed).
   Submit a leave request. Submit an advance request.
5. Logout. Login as manager@muster.com → Approvals → approve/reject the
   leave and the advance → refresh → confirm the decision persisted.
6. Payroll → New Run → Calculate → note gross/deductions/net → Calculate
   again on the same run → confirm the numbers are identical (this is
   exactly what `payroll_engine.unit.test.ts` already proved in isolation;
   this step confirms it through the real HTTP + DB + UI path).
