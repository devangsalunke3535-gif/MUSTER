/**
 * Pure-logic unit tests (no database): approval authorization rules,
 * attendance timing (IST + night shifts), shift classification and date parsing.
 */
jest.mock('../config/db', () => ({ get prisma() { return {}; } }));

import { recordDecision } from '../services/approval.service';
import { AttendanceService, istInstant } from '../services/attendance.service';
import { classifyShift } from '../services/employee.service';
import { parseDateOnly, round2 } from '../utils/http';

function approvalTx(approval: any) {
  const calls: any = { steps: [], request: [], actions: [], created: [] };
  const tx: any = {
    approvalRequest: {
      findFirst: async () => approval,
      create: async ({ data }: any) => { const a = { id: 'ar-new', status: 'PENDING', steps: [], ...data }; calls.created.push(a); return a; },
      update: async ({ data }: any) => { calls.request.push(data.status); },
    },
    approvalStep: { updateMany: async ({ where, data }: any) => { calls.steps.push({ ids: where.id.in, status: data.status }); } },
    approvalAction: { create: async ({ data }: any) => { calls.actions.push(data); } },
  };
  return { tx, calls };
}
const base = { orgId: 'o', approvalRequestId: 'ar', entityType: 'LeaveRequest', entityId: 'lr', requesterEmployeeId: 'worker', decision: 'APPROVED' as const };
const pendingWithStep = () => ({ id: 'ar', status: 'PENDING', steps: [{ id: 's1', approver_user_id: 'manager', status: 'PENDING' }] });

describe('Approval authorization', () => {
  it('assigned approver can approve; step, request and action are all updated', async () => {
    const { tx, calls } = approvalTx(pendingWithStep());
    await recordDecision(tx, { ...base, actorEmployeeId: 'manager', actorIsSuperAdmin: false });
    expect(calls.steps).toEqual([{ ids: ['s1'], status: 'APPROVED' }]);
    expect(calls.request).toEqual(['APPROVED']);
    expect(calls.actions).toEqual([expect.objectContaining({ actor_user_id: 'manager', action: 'APPROVED' })]);
  });

  it('a user holding the permission but NOT assigned to the step is rejected (403)', async () => {
    const { tx, calls } = approvalTx(pendingWithStep());
    await expect(recordDecision(tx, { ...base, actorEmployeeId: 'other-manager', actorIsSuperAdmin: false }))
      .rejects.toMatchObject({ status: 403 });
    expect(calls.request).toEqual([]);
  });

  it('self-approval is rejected for non-super-admins', async () => {
    const { tx } = approvalTx({ id: 'ar', status: 'PENDING', steps: [] });
    await expect(recordDecision(tx, { ...base, actorEmployeeId: 'worker', actorIsSuperAdmin: false }))
      .rejects.toMatchObject({ status: 403 });
  });

  it('actor without an employee profile is rejected (actions are recorded against employees)', async () => {
    const { tx } = approvalTx(pendingWithStep());
    await expect(recordDecision(tx, { ...base, actorEmployeeId: null, actorIsSuperAdmin: true }))
      .rejects.toMatchObject({ status: 403 });
  });

  it('super admin may override an assigned step; the open step is closed and the action recorded', async () => {
    const { tx, calls } = approvalTx(pendingWithStep());
    await recordDecision(tx, { ...base, actorEmployeeId: 'admin', actorIsSuperAdmin: true, decision: 'REJECTED' });
    expect(calls.steps).toEqual([{ ids: ['s1'], status: 'REJECTED' }]);
    expect(calls.request).toEqual(['REJECTED']);
  });

  it('request with no steps (no manager) can be decided by any permission holder', async () => {
    const { tx, calls } = approvalTx({ id: 'ar', status: 'PENDING', steps: [] });
    await recordDecision(tx, { ...base, actorEmployeeId: 'hr', actorIsSuperAdmin: false });
    expect(calls.request).toEqual(['APPROVED']);
  });

  it('legacy request with no ApprovalRequest gets one created in the same transaction', async () => {
    const { tx, calls } = approvalTx(null);
    await recordDecision(tx, { ...base, approvalRequestId: null, actorEmployeeId: 'manager', actorIsSuperAdmin: false });
    expect(calls.created).toHaveLength(1);
    expect(calls.request).toEqual(['APPROVED']);
    expect(calls.actions).toHaveLength(1);
  });

  it('an already-decided approval cannot be decided again (409)', async () => {
    const { tx } = approvalTx({ id: 'ar', status: 'APPROVED', steps: [] });
    await expect(recordDecision(tx, { ...base, actorEmployeeId: 'manager', actorIsSuperAdmin: false }))
      .rejects.toMatchObject({ status: 409 });
  });
});

function attendanceTx(att: any) {
  return {
    attendance: {
      findUnique: async () => att,
      update: async ({ data }: any) => Object.assign(att, data),
    },
  } as any;
}
const NIGHT = { start_time: '21:00', end_time: '06:00', grace_period_mins: 15, half_day_mins: 240, full_day_mins: 480 };
const DAY = { start_time: '09:00', end_time: '18:00', grace_period_mins: 15, half_day_mins: 240, full_day_mins: 480 };

describe('Attendance timing (IST, independent of server timezone)', () => {
  it('istInstant converts IST wall-clock to the correct UTC instant', () => {
    expect(istInstant(new Date('2026-09-19T00:00:00Z'), '09:00').toISOString()).toBe('2026-09-19T03:30:00.000Z');
    expect(istInstant(new Date('2026-09-19T00:00:00Z'), '06:00', 1).toISOString()).toBe('2026-09-20T00:30:00.000Z');
  });

  it('night shift 21:00→06:00 worked in full is PRESENT, on time, not an early departure', async () => {
    const att: any = {
      id: 'a', date: new Date('2026-09-19T00:00:00Z'), status: 'PRESENT', is_late: false, is_early_departure: false, shift: NIGHT,
      first_check_in: new Date('2026-09-19T15:30:00Z'),   // 21:00 IST
      last_check_out: new Date('2026-09-20T00:30:00Z'),   // 06:00 IST next day
      sessions: [{ check_out_time: new Date('2026-09-20T00:30:00Z'), duration_mins: 540 }],
    };
    await AttendanceService.recalculateAttendance('a', attendanceTx(att));
    expect(att).toMatchObject({ status: 'PRESENT', total_worked_mins: 540, is_late: false, is_early_departure: false });
  });

  it('day shift: late beyond grace, early departure and half day are detected', async () => {
    const att: any = {
      id: 'a', date: new Date('2026-09-19T00:00:00Z'), status: 'PRESENT', is_late: false, is_early_departure: false, shift: DAY,
      first_check_in: new Date('2026-09-19T04:00:00Z'),   // 09:30 IST (grace 15)
      last_check_out: new Date('2026-09-19T09:30:00Z'),   // 15:00 IST
      sessions: [{ check_out_time: new Date(), duration_mins: 330 }],
    };
    await AttendanceService.recalculateAttendance('a', attendanceTx(att));
    expect(att).toMatchObject({ status: 'HALF_DAY', is_late: true, is_early_departure: true });
  });

  it('open (not checked-out) sessions are not counted', async () => {
    const att: any = { id: 'a', date: new Date('2026-09-19T00:00:00Z'), status: 'PRESENT', shift: DAY, sessions: [{ check_out_time: null, duration_mins: 0 }] };
    await AttendanceService.recalculateAttendance('a', attendanceTx(att));
    expect(att.total_worked_mins).toBe(0);
    expect(att.status).toBe('PRESENT');
  });
});

describe('Shift classification & parsing helpers', () => {
  it('classifies by the persisted shift, never defaults to DAY', () => {
    expect(classifyShift(null)).toBe('UNASSIGNED');
    expect(classifyShift({ name: 'Night Shift' })).toBe('NIGHT');
    expect(classifyShift({ name: 'Day Shift' })).toBe('DAY');
    expect(classifyShift({ name: 'General' })).toBe('OTHER');
  });

  it('parseDateOnly accepts YYYY-MM-DD and ISO strings, rejects junk and impossible dates', () => {
    expect(parseDateOnly('2026-09-19', 'd').toISOString()).toBe('2026-09-19T00:00:00.000Z');
    expect(parseDateOnly('2026-09-19T18:30:00.000Z', 'd').toISOString()).toBe('2026-09-19T00:00:00.000Z');
    expect(() => parseDateOnly('19/09/2026', 'd')).toThrow('YYYY-MM-DD');
    expect(() => parseDateOnly('2026-02-30', 'd')).toThrow('not a valid calendar date');
    expect(() => parseDateOnly(undefined, 'd')).toThrow();
  });

  it('round2 removes float drift', () => {
    expect(round2(0.1 + 0.2)).toBe(0.3);
    expect(round2(1894.9999999)).toBe(1895);
  });
});
