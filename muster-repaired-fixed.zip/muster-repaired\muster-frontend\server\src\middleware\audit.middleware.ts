import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/db';

const SENSITIVE_FIELDS = ['password', 'password_hash', 'account_number', 'pan', 'aadhaar', 'uan', 'pf_number', 'esi_number', 'account_number_enc', 'pan_enc', 'aadhaar_enc', 'uan_enc', 'pf_number_enc', 'esi_number_enc'];

function sanitizePayload(payload: any): any {
  if (!payload || typeof payload !== 'object') return payload;
  
  if (Array.isArray(payload)) {
    return payload.map(sanitizePayload);
  }

  const sanitized = { ...payload };
  for (const key of Object.keys(sanitized)) {
    if (SENSITIVE_FIELDS.includes(key) || SENSITIVE_FIELDS.some(f => key.includes(f))) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof sanitized[key] === 'object') {
      sanitized[key] = sanitizePayload(sanitized[key]);
    }
  }
  return sanitized;
}

export function auditLog(action: string, entityType: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const originalSend = res.send;
    
    res.send = function (body: any) {
      if (res.statusCode >= 200 && res.statusCode < 300) {
        const { userId, organizationId } = req.authContext || {};
        if (organizationId) {
          
          let parsedBody = null;
          try {
             parsedBody = typeof body === 'string' ? JSON.parse(body) : body;
          } catch (e) {
             // not json
          }
          
          const safeBody = sanitizePayload(parsedBody);
          const safeReqBody = sanitizePayload(req.body);

          prisma.auditLog.create({
            data: {
              organization_id: organizationId,
              actor_user_id: userId || null,
              action,
              entity_type: entityType,
              entity_id: typeof req.params.id === 'string' ? req.params.id : '00000000-0000-0000-0000-000000000000',
              ip_address: req.ip,
              new_values: action !== 'DELETE' ? safeBody : null,
              old_values: action !== 'CREATE' ? safeReqBody : null, // Assuming req.body contains the update payload
            }
          }).catch(console.error);
        }
      }
      return originalSend.call(this, body);
    };
    
    next();
  };
}
