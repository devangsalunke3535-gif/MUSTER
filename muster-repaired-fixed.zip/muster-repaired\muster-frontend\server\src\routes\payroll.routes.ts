import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { auditLog } from '../middleware/audit.middleware';
import { PayrollService } from '../services/payroll.service';
import { sendError, badRequest, notFound, conflict, parseDateOnly, optionalString, isUuid, round2 } from '../utils/http';

const router = Router();

const LOCKED_STATUSES = ['FINALIZED', 'DISBURSED', 'LOCKED'];
// A run stuck in PROCESSING (e.g. the server crashed mid-calculation) may be
// re-claimed after this long. Real calculations finish within the tx timeout.
const STALE_PROCESSING_MS = 10 * 60 * 1000;

function monthName(d: Date) {
  return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric', timeZone: 'UTC' });
}

async function createPeriod(orgId: string, body: any) {
  const start = parseDateOnly(body?.start_date, 'start_date');
  const end = parseDateOnly(body?.end_date, 'end_date');
  if (end < start) throw badRequest('end_date must be on or after start_date');
  const days = Math.round((end.getTime() - start.getTime()) / 86400000) + 1;
  if (days > 62) throw badRequest('A payroll period cannot be longer than 62 days');
  const name = optionalString(body?.name, 'name', 100) || monthName(start);

  // Overlapping periods would pay the same attendance twice.
  const overlap = await prisma.payrollPeriod.findFirst({
    where: { organization_id: orgId, start_date: { lte: end }, end_date: { gte: start } }
  });
  if (overlap) throw conflict(`This period overlaps the existing period "${overlap.name}"`);

  return prisma.payrollPeriod.create({ data: { organization_id: orgId, name, start_date: start, end_date: end } });
}

// ---------------------------------------------------------
// PERIODS
// ---------------------------------------------------------

router.get('/periods', requirePermission('payroll:view'), async (req: Request, res: Response) => {
  try {
    const periods = await prisma.payrollPeriod.findMany({
      where: { organization_id: req.authContext!.organizationId },
      include: { runs: { select: { id: true, status: true } } },
      orderBy: { start_date: 'desc' }
    });
    res.json({ data: periods });
  } catch (error) {
    sendError(res, error, 'List payroll periods');
  }
});

router.post('/periods', requirePermission('payroll:manage'), auditLog('CREATE', 'PayrollPeriod'), async (req: Request, res: Response) => {
  try {
    res.json({ data: await createPeriod(req.authContext!.organizationId, req.body) });
  } catch (error) {
    sendError(res, error, 'Create payroll period');
  }
});

// ---------------------------------------------------------
// RUNS
// ---------------------------------------------------------

// POST /payroll/runs { payroll_period_id } or { start_date, end_date, name? }
router.post('/runs', requirePermission('payroll:create'), auditLog('CREATE', 'PayrollRun'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    let periodId = req.body?.payroll_period_id;

    if (periodId) {
      if (!isUuid(periodId)) throw notFound('Payroll period not found');
      // Tenant check: a period from another organization must not be usable here.
      const period = await prisma.payrollPeriod.findFirst({ where: { id: periodId, organization_id: orgId } });
      if (!period) throw notFound('Payroll period not found');
    } else {
      periodId = (await createPeriod(orgId, req.body)).id;
    }

    const existing = await prisma.payrollRun.findFirst({ where: { organization_id: orgId, payroll_period_id: periodId } });
    if (existing) return res.status(400).json({ error: 'A payroll run already exists for this period' });

    const run = await prisma.payrollRun.create({
      data: { organization_id: orgId, payroll_period_id: periodId, status: 'DRAFT' },
      include: { period: true }
    });
    res.json({ data: run });
  } catch (error) {
    sendError(res, error, 'Create payroll run');
  }
});

router.post('/runs/:id/calculate', requirePermission('payroll:calculate'), auditLog('UPDATE', 'PayrollRun'), async (req: Request, res: Response) => {
  const orgId = req.authContext!.organizationId;
  const runId = String(req.params.id);
  let claimed = false;
  try {
    if (!isUuid(runId)) return res.status(404).json({ error: 'Run not found' });
    const run = await prisma.payrollRun.findFirst({ where: { id: runId, organization_id: orgId }, include: { period: true } });
    if (!run) return res.status(404).json({ error: 'Run not found' });
    if (LOCKED_STATUSES.includes(run.status)) {
      return res.status(400).json({ error: 'Run is finalized and cannot be recalculated.' });
    }

    // Atomic claim: only one calculation of this run at a time.
    const claim = await prisma.payrollRun.updateMany({
      where: {
        id: run.id,
        organization_id: orgId,
        OR: [
          { status: { notIn: ['PROCESSING', ...LOCKED_STATUSES] } },
          { status: 'PROCESSING', updated_at: { lt: new Date(Date.now() - STALE_PROCESSING_MS) } }
        ]
      },
      data: { status: 'PROCESSING' }
    });
    if (claim.count === 0) {
      return res.status(409).json({ error: 'Run is currently processing or cannot be recalculated.' });
    }
    claimed = true;

    const { warnings, totals } = await PayrollService.calculatePayrollRun(run.id, orgId, run.period.start_date, run.period.end_date);
    res.json({
      message: 'Calculation completed successfully. State moved to REVIEW.',
      totals,
      warnings: warnings.length > 0 ? warnings : undefined
    });
  } catch (error: any) {
    if (claimed) {
      // Release our claim (scoped to this org and to the PROCESSING state we set).
      await prisma.payrollRun.updateMany({
        where: { id: runId, organization_id: orgId, status: 'PROCESSING' },
        data: { status: 'DRAFT' }
      }).catch(() => undefined);
    }
    sendError(res, error, 'Calculate payroll');
  }
});

router.post('/runs/:id/finalize', requirePermission('payroll:finalize'), auditLog('UPDATE', 'PayrollRun'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const runId = String(req.params.id);
    if (!isUuid(runId)) return res.status(404).json({ error: 'Run not found' });
    const run = await prisma.payrollRun.findFirst({ where: { id: runId, organization_id: orgId } });
    if (!run) return res.status(404).json({ error: 'Run not found' });

    const done = await prisma.payrollRun.updateMany({
      where: { id: run.id, organization_id: orgId, status: { in: ['REVIEW', 'APPROVED'] } },
      data: { status: 'FINALIZED' }
    });
    if (done.count === 0) return res.status(400).json({ error: 'Run must be in REVIEW or APPROVED state to finalize' });

    const finalized = await prisma.payrollRun.findUnique({ where: { id: run.id } });
    res.json({ data: finalized });
  } catch (error) {
    sendError(res, error, 'Finalize payroll');
  }
});

// GET /payroll/runs — runs with server-side totals (no client-side summing of stale data).
router.get('/runs', requirePermission('payroll:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const runs = await prisma.payrollRun.findMany({
      where: { organization_id: orgId },
      include: { period: true },
      orderBy: [{ period: { start_date: 'desc' } }]
    });
    const sums = await prisma.payrollItem.groupBy({
      by: ['payroll_run_id'],
      where: { run: { organization_id: orgId } },
      _sum: { gross_earnings: true, total_deductions: true, net_pay: true },
      _count: { _all: true }
    });
    const byRun = new Map(sums.map((s: any) => [s.payroll_run_id, s]));
    res.json({
      data: runs.map((r: any) => {
        const s: any = byRun.get(r.id);
        return {
          ...r,
          totals: {
            employees: s?._count?._all ?? 0,
            gross: round2(s?._sum?.gross_earnings ?? 0),
            deductions: round2(s?._sum?.total_deductions ?? 0),
            net: round2(s?._sum?.net_pay ?? 0),
          }
        };
      })
    });
  } catch (error) {
    sendError(res, error, 'List payroll runs');
  }
});

// GET /payroll/runs/:id — full breakdown for "View Details".
router.get('/runs/:id', requirePermission('payroll:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const runId = String(req.params.id);
    if (!isUuid(runId)) return res.status(404).json({ error: 'Run not found' });
    const run = await prisma.payrollRun.findFirst({
      where: { id: runId, organization_id: orgId },
      include: {
        period: true,
        items: {
          include: {
            employee: { select: { id: true, emp_id: true, first_name: true, last_name: true } },
            components: { include: { component: { select: { id: true, name: true, code: true, type: true } } } },
            loanRepayments: true
          },
          orderBy: { employee: { emp_id: 'asc' } }
        }
      }
    });
    if (!run) return res.status(404).json({ error: 'Run not found' });
    res.json({ data: run });
  } catch (error) {
    sendError(res, error, 'Payroll run details');
  }
});

export default router;
