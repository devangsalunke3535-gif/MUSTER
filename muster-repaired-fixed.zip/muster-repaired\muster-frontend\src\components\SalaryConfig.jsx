import { useState, useEffect } from 'react';
import api, { describeError } from '../api';
import { Settings, Plus, IndianRupee, Layers, X, AlertCircle, Power } from 'lucide-react';
import { useToast } from './Toast';

const TYPES = ['EARNING', 'DEDUCTION', 'STATUTORY', 'OVERTIME'];

export default function SalaryConfig() {
  const [components, setComponents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', code: '', type: 'EARNING' });
  const [saving, setSaving] = useState(false);
  const { addToast } = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get('/salary/components');
      setComponents(res.data?.data || []);
      setError(null);
    } catch (err) {
      setError(describeError(err, 'Failed to load salary components'));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  const getTypeBadge = (type) => {
    const maps = {
      EARNING: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      DEDUCTION: 'bg-rose-100 text-rose-700 border-rose-200',
      STATUTORY: 'bg-indigo-100 text-indigo-700 border-indigo-200',
      OVERTIME: 'bg-amber-100 text-amber-700 border-amber-200',
    };
    return `px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border ${maps[type] || maps.EARNING}`;
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/salary/components', form);
      addToast('Component created', 'success');
      setShowModal(false);
      setForm({ name: '', code: '', type: 'EARNING' });
      await load();
    } catch (err) {
      addToast(describeError(err, 'Failed to create component'), 'error');
    }
    setSaving(false);
  };

  const toggleActive = async (comp) => {
    try {
      await api.put(`/salary/components/${comp.id}`, { is_active: !comp.is_active });
      await load();
    } catch (err) {
      addToast(describeError(err, 'Failed to update component'), 'error');
    }
  };

  return (
    <div className="p-8 font-sans max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 tracking-tight">Salary Configuration</h1>
          <p className="text-slate-500 mt-1">Manage earning and deduction components. Amounts are set per worker in their salary structure.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="px-5 py-2.5 bg-primary-600 text-white rounded-xl font-semibold shadow-lg shadow-primary-600/25 hover:bg-primary-700 active:scale-95 transition-all flex items-center gap-2">
          <Plus size={18} /> New Component
        </button>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm mb-6">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex items-center gap-3">
              <Layers size={18} className="text-slate-400" />
              <h2 className="font-bold text-slate-700">Organization Components</h2>
            </div>

            {loading ? (
              <div className="p-8 animate-pulse space-y-4">
                {[1, 2, 3].map(i => <div key={i} className="h-16 bg-slate-200 rounded-xl"></div>)}
              </div>
            ) : components.length === 0 ? (
              <div className="p-12 text-center text-sm text-slate-400">No components yet.</div>
            ) : (
              <div className="divide-y divide-slate-100">
                {components.map(comp => (
                  <div key={comp.id} className="p-5 flex items-center justify-between group hover:bg-slate-50/50 transition-colors">
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="font-bold text-slate-800">{comp.name}</h3>
                        <span className={getTypeBadge(comp.type)}>{comp.type}</span>
                        {!comp.is_active && (
                          <span className="px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border bg-slate-100 text-slate-500 border-slate-200">INACTIVE</span>
                        )}
                      </div>
                      <p className="text-sm text-slate-500">Code: {comp.code} · Used in {comp.active_structure_count ?? 0} active salary structure(s)</p>
                    </div>

                    <button onClick={() => toggleActive(comp)} title={comp.is_active ? 'Deactivate' : 'Activate'}
                      className="opacity-0 group-hover:opacity-100 p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-all flex items-center gap-1 text-xs font-semibold">
                      <Power size={16} /> {comp.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-800 text-white p-6 rounded-3xl relative overflow-hidden">
            <div className="absolute -right-6 -top-6 text-white/5"><IndianRupee size={120} /></div>
            <h3 className="font-bold text-lg mb-2 relative z-10">How it works</h3>
            <p className="text-sm text-slate-300 leading-relaxed relative z-10 mb-4">
              Components define what earnings and deductions exist. Each worker's actual wage amount is set on their individual salary structure in the Directory, not here.
            </p>
            <div className="space-y-2 relative z-10">
              <div className="flex justify-between text-sm bg-white/10 p-3 rounded-xl border border-white/10">
                <span className="text-slate-300">Total Active</span>
                <span className="font-bold">{components.filter(c => c.is_active).length}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-elevated w-full max-w-md overflow-hidden border border-slate-100">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800">New Component</h3>
              <button onClick={() => setShowModal(false)} className="p-1 text-slate-400 hover:bg-slate-100 rounded-lg"><X size={18} /></button>
            </div>
            <form onSubmit={handleCreate} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5">Name</label>
                <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. House Rent Allowance" className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5">Code</label>
                <input required value={form.code} onChange={e => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="e.g. HRA" className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-1.5">Type</label>
                <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm">
                  {TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <button type="submit" disabled={saving} className="w-full py-3 bg-primary-600 text-white rounded-xl font-bold shadow-lg shadow-primary-600/25 hover:bg-primary-700 disabled:opacity-60">
                {saving ? 'Creating...' : 'Create Component'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
