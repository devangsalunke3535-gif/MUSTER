import { useState, useEffect } from 'react';
import api from '../api';
import { Calendar, AlertCircle } from 'lucide-react';
import { fmtDate, fmtTime, fmtMins, describeError, todayISO } from '../api';

export default function WorkerMyAttendance() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [month, setMonth] = useState(todayISO().slice(0, 7));

  useEffect(() => {
    const fetchAttendance = async () => {
      setLoading(true);
      try {
        const res = await api.get('/attendance/history', { params: { month } });
        setLogs(res.data?.data || []);
        setError(null);
      } catch (err) {
        setError(describeError(err, 'Failed to fetch attendance'));
      } finally {
        setLoading(false);
      }
    };
    fetchAttendance();
  }, [month]);

  const getStatusBadge = (status) => {
    const maps = {
      PRESENT: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      HALF_DAY: 'bg-amber-100 text-amber-700 border-amber-200',
      ABSENT: 'bg-rose-100 text-rose-700 border-rose-200',
      LATE: 'bg-orange-100 text-orange-700 border-orange-200',
    };
    return `px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border ${maps[status] || 'bg-slate-100 text-slate-600 border-slate-200'}`;
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight">My Attendance</h1>
        <p className="text-slate-500 mt-1">View your check-ins and attendance history.</p>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 mb-6">
        <div className="relative flex-1 max-w-xs">
          <Calendar size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input type="month" value={month} max={todayISO().slice(0, 7)} onChange={e => setMonth(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20" />
        </div>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-4 flex items-center gap-2 text-sm mb-6">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {loading ? (
        <div className="space-y-4 animate-pulse">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-24 bg-slate-200 rounded-2xl"></div>)}
        </div>
      ) : logs.length === 0 ? (
        <div className="text-center py-16 bg-slate-50 border border-slate-200 border-dashed rounded-3xl text-slate-500 text-sm">No attendance records for this month.</div>
      ) : (
        <div className="space-y-4">
          {logs.map((log) => (
            <div key={log.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 group hover:border-slate-300 hover:shadow-md transition-all">
              <div>
                <p className="text-sm font-bold text-slate-800">{new Date(log.date).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', timeZone: 'UTC' })}</p>
                <p className="text-xs text-slate-500 mt-1">{log.shift?.name || 'No shift assigned'}</p>
              </div>
              <div className="flex flex-wrap items-center gap-6">
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">In</span>
                  <span className="font-semibold text-slate-700">{fmtTime(log.first_check_in)}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Out</span>
                  <span className="font-semibold text-slate-700">{fmtTime(log.last_check_out)}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Worked</span>
                  <span className="font-semibold text-slate-700">{fmtMins(log.total_worked_mins)}</span>
                </div>
                <div className="flex-shrink-0 w-28 text-right">
                  <span className={getStatusBadge(log.status)}>{log.status.replace('_', ' ')}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
