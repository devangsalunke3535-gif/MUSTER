import { Prisma } from '@prisma/client';
import { prisma } from '../config/db';

const IST_OFFSET_MINS = 330; // Asia/Kolkata, UTC+05:30 (no DST)

/**
 * The instant at which "HH:MM[:SS]" on a given attendance date occurs, in IST.
 * `date` is the attendance date stored as midnight UTC.
 */
export function istInstant(date: Date, hhmm: string, addDays = 0): Date {
  const [h, m] = hhmm.split(':').map(Number);
  const base = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + addDays, 0, 0, 0);
  return new Date(base + ((h || 0) * 60 + (m || 0) - IST_OFFSET_MINS) * 60000);
}

export class AttendanceService {
  static getDurationMins(start: Date, end: Date): number {
    return Math.max(0, Math.floor((end.getTime() - start.getTime()) / 60000));
  }

  /**
   * Recompute an attendance master record from its closed sessions and shift.
   *
   * Times are evaluated in IST regardless of the server's timezone, and a
   * shift whose end time is earlier than its start time (e.g. a night shift
   * 21:00–06:00) is treated as ending on the following day.
   *
   * Status rule (unchanged business rule): worked ≥ full_day_mins → PRESENT,
   * ≥ half_day_mins → HALF_DAY, any other positive time → PRESENT.
   */
  static async recalculateAttendance(attendanceId: string, tx: Prisma.TransactionClient = prisma as any) {
    const attendance = await tx.attendance.findUnique({
      where: { id: attendanceId },
      include: { sessions: true, shift: true }
    });
    if (!attendance) throw new Error('Attendance not found');

    let totalWorkedMins = 0;
    for (const s of attendance.sessions) if (s.check_out_time) totalWorkedMins += s.duration_mins;

    const shift = attendance.shift;
    let status = attendance.status;
    let isLate = attendance.is_late;
    let isEarlyDeparture = attendance.is_early_departure;

    if (totalWorkedMins > 0) {
      if (shift && totalWorkedMins < shift.full_day_mins && totalWorkedMins >= shift.half_day_mins) status = 'HALF_DAY';
      else status = 'PRESENT';
    }

    if (shift) {
      const shiftStart = istInstant(attendance.date, shift.start_time);
      const crossesMidnight = shift.end_time <= shift.start_time;
      const shiftEnd = istInstant(attendance.date, shift.end_time, crossesMidnight ? 1 : 0);
      if (attendance.first_check_in) {
        const lateMins = (new Date(attendance.first_check_in).getTime() - shiftStart.getTime()) / 60000;
        isLate = lateMins > shift.grace_period_mins;
      }
      if (attendance.last_check_out) {
        isEarlyDeparture = new Date(attendance.last_check_out).getTime() < shiftEnd.getTime();
      }
    }

    return tx.attendance.update({
      where: { id: attendanceId },
      data: { total_worked_mins: totalWorkedMins, status, is_late: isLate, is_early_departure: isEarlyDeparture }
    });
  }
}

/** True if the date falls inside a FINALIZED/DISBURSED/LOCKED payroll period. */
export async function isDateInFinalizedPayroll(orgId: string, date: Date, tx: Prisma.TransactionClient = prisma as any): Promise<boolean> {
  const count = await tx.payrollRun.count({
    where: {
      organization_id: orgId,
      status: { in: ['FINALIZED', 'DISBURSED', 'LOCKED'] },
      period: { start_date: { lte: date }, end_date: { gte: date } }
    }
  });
  return count > 0;
}
