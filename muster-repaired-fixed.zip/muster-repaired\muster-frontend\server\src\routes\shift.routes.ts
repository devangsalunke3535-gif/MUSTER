import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { requirePermission } from '../middleware/rbac.middleware';
import { auditLog } from '../middleware/audit.middleware';
import { sendError, badRequest, notFound, parseDateOnly, isUuid, optionalString } from '../utils/http';

const router = Router();

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/;
function validateShiftTimes(start: unknown, end: unknown) {
  if (typeof start !== 'string' || !TIME_RE.test(start)) throw badRequest('start_time must be HH:MM');
  if (typeof end !== 'string' || !TIME_RE.test(end)) throw badRequest('end_time must be HH:MM');
}

// GET /api/v1/shifts
router.get('/', requirePermission('shift:view'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const shifts = await prisma.shift.findMany({ where: { organization_id: orgId }, orderBy: { start_time: 'asc' } });
    res.json({ data: shifts });
  } catch (error) {
    sendError(res, error, 'shift');
  }
});

// POST /api/v1/shifts
router.post('/', requirePermission('shift:create'), auditLog('CREATE', 'Shift'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const { start_time, end_time, grace_period_mins, half_day_mins, full_day_mins, is_active } = req.body || {};
    const name = optionalString(req.body?.name, 'name', 100);
    if (!name) throw badRequest('name is required');
    validateShiftTimes(start_time, end_time);

    const shift = await prisma.shift.create({
      data: {
        organization_id: orgId,
        name,
        start_time,
        end_time,
        grace_period_mins: grace_period_mins || 0,
        half_day_mins: half_day_mins || 240,
        full_day_mins: full_day_mins || 480,
        is_active: is_active ?? true
      }
    });

    res.json({ data: shift });
  } catch (error) {
    sendError(res, error, 'shift');
  }
});

// PUT /api/v1/shifts/:id
router.put('/:id', requirePermission('shift:update'), auditLog('UPDATE', 'Shift'), async (req: Request, res: Response) => {
  try {
    const orgId = req.authContext!.organizationId;
    const shiftId = req.params.id as string;
    if (!isUuid(shiftId)) throw notFound('Shift not found');
    const updateData = req.body || {};
    if (updateData.start_time !== undefined || updateData.end_time !== undefined) {
      validateShiftTimes(updateData.start_time ?? '00:00', updateData.end_time ?? '00:00');
    }
    if (updateData.is_active === false) {
      const assigned = await prisma.employee.count({ where: { default_shift_id: shiftId, organization_id: orgId } });
      if (assigned > 0) throw badRequest(`${assigned} employee(s) are assigned to this shift; reassign them before deactivating it`);
    }

    // Verify ownership
    const existing = await prisma.shift.findFirst({ where: { id: shiftId, organization_id: orgId } });
    if (!existing) return res.status(404).json({ error: 'Shift not found' });

    const shift = await prisma.shift.update({
      where: { id: shiftId },
      data: {
        name: updateData.name,
        start_time: updateData.start_time,
        end_time: updateData.end_time,
        grace_period_mins: updateData.grace_period_mins,
        half_day_mins: updateData.half_day_mins,
        full_day_mins: updateData.full_day_mins,
        is_active: updateData.is_active
      }
    });

    res.json({ data: shift });
  } catch (error) {
    sendError(res, error, 'shift');
  }
});

export default router;
